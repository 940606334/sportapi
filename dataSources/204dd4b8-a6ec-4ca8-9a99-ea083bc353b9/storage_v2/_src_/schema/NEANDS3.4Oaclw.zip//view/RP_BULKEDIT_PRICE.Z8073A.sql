CREATE VIEW RP_BULKEDIT_PRICE AS
  select b.id,b.ad_client_id,b.ad_org_id,a.docno,a.billdate,a.description,a.statuserid,a.statustime,b.m_product_id,b.price_new,b.description as remak
from M_BULKEDIT_PRICE  a,M_BULKEDIT_PRICEitem b
where a.id=b.m_bulkedit_price_id
and a.status=2
WITH READ ONLY
/

