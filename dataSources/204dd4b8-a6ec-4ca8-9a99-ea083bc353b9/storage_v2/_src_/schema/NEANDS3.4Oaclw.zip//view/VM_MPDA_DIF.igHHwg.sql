CREATE VIEW VM_MPDA_DIF AS
  SELECT F."ID",F."M_PRODUCT_ID",F."NO",F."NAME",F."VALUE",F."FORCODE",F."VALUE1",F."VALUE1_CODE",F."VALUE2",F."VALUE2_CODE",F."PRICELIST",F."ISACTIVE",F."INTSCODE",F."T",F."BIND_PROALIAS01",F."BIND_PROALIAS02",1 RN
FROM (
Select b2a.*, 'm_pda' T
from ((Select * from m_pda) Minus (Select * From m_pda_tmp)) b2a
) F/* edit by Selina 2016/11/1 10:56:48 */

