CREATE VIEW RP_B_SO_CUSREBATE AS
  select a.c_customer_id as id, 37 as ad_client_id, 27 as ad_org_id,
       893 as ownerid, 893 as modifierid, sysdate as creationdate,
       sysdate as modifieddate, 'Y' isactive, a.c_dest_id, a.c_customer_id,
       a.id as b_so_id, a.docno, c.docno as rebatedocno, a.billdate,
       b.m_productalias_id, b.m_product_id, b.m_attributesetinstance_id, d.qty,
       b.pricelist, b.priceactual, d.priceactual1, d.priceactual2, d.discount,
       d.discount1, d.tot_amt_before, d.tot_amt_after, d.tot_amt_actual,
       b.qtyconsign,
       nvl(b.qtyconsign, 0) * (d.priceactual1 - d.priceactual2) as tot_rebate_actual,0 as close_amt
from b_so a, b_soitem b, b_so_cusrebate c, b_so_cusrebateitem d
where a.id = b.b_so_id and a.id = c.b_so_id and c.id = d.b_so_cusrebate_id and
      b.m_product_id = d.m_product_id and
      b.m_attributesetinstance_id = d.m_attributesetinstance_id and
      c.status = 2 and a.close_status = 1
union all
select a.c_customer_id as id, 37 as ad_client_id, 27 as ad_org_id,
       893 as ownerid, 893 as modifierid, sysdate as creationdate,
       sysdate as modifieddate, 'Y' isactive, a.c_dest_id, a.c_customer_id,
       a.id as b_so_id, a.docno, c.docno as rebatedocno, a.billdate,
       b.m_productalias_id, b.m_product_id, b.m_attributesetinstance_id, d.qty,
       b.pricelist, b.priceactual, d.priceactual1, d.priceactual2, d.discount,
       d.discount1, d.tot_amt_before, d.tot_amt_after,
       nvl(b.qty - b.qtyrem, 0) * (d.priceactual1 - d.priceactual2) as tot_amt_actual,
       b.qtyconsign,
       nvl(b.qtyconsign, 0) * (d.priceactual1 - d.priceactual2) as tot_rebate_actual,
       nvl(b.qtyrem, 0) * (d.priceactual1 - d.priceactual2)  as close_amt
from b_so a, b_soitem b, b_so_cusrebate c, b_so_cusrebateitem d
where a.id = b.b_so_id and a.id = c.b_so_id and c.id = d.b_so_cusrebate_id and
      b.m_product_id = d.m_product_id and
      b.m_attributesetinstance_id = d.m_attributesetinstance_id and
      c.status = 2 and a.close_status = 2 with read only
/

