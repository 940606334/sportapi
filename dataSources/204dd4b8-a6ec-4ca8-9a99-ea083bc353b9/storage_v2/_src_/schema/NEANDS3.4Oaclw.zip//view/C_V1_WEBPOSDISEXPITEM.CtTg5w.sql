CREATE VIEW C_V1_WEBPOSDISEXPITEM AS
  select a.id,a.c_webposdis_id,GET_FITLER_SQL(a.exproduct_filter) as exproduct_filter,a.qty,a.relationtype
from C_WEBPOSDIS t,C_WEBPOSDISEXPITEM a
where t.id=a.c_webposdis_id
and t.webtype=1
and t.isactive='Y'
/

