CREATE VIEW RP_B_PO001 AS
  select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,
a.BILLDATE,a.DOCNO,a.SALESREP_Id,a.C_STORE_ID,C_SUPPLIER_ID,a.DESCRIPTION,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,b.QTY,b.BOXQTYADJ,b.QTYOCCU,b.QTYCLO,b.QTYCONSIGN,b.QTYREM,b.PRICEACTUAL,
b.TOT_AMT_ACTUAL,b.QTYOCCU*b.PRICEACTUAL AS TOT_AMTOCCU_ACTUAL,
b.QTYCONSIGN*b.PRICEACTUAL AS TOT_AMTCONSIGN_ACTUAL,
b.QTYREM*b.PRICEACTUAL AS TOT_AMTREM_ACTUAL,
c.id as m_product_alias_id,
b.confirmdate,b.qty-nvl(b.qtymovein,0) as qtyinit,
nvl(b.qtymovein,0)-nvl(b.qtymoveout,0) as qtymove,
b.qty-nvl(b.qtymovein,0)-(nvl(b.qtymovein,0)-nvl(b.qtymoveout,0)) as qtyfinal,
b.qtymoveout,b.qtymovein,b.qty-nvl(b.qtymoveout,0) as zhddl
from B_PO a,B_POITEM b,m_product_alias c
where a.ID=b.B_PO_ID
and a.STATUS=2
and b.m_product_id=c.m_product_id
and b.m_attributesetinstance_id=c.m_attributesetinstance_id
with read only
/

