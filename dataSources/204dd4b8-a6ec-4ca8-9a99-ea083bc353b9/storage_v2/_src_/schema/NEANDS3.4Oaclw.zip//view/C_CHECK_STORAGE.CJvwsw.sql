CREATE VIEW C_CHECK_STORAGE AS
  select sum(nvl(bao1,0))  "M_INVENTORY",sum(nvl(bao2,0)) "M_PURCHASEIN",sum(nvl(bao3,0)) "M_RET_PUROUT",
sum(nvl(bao4,0)) "M_SALEOUT",sum(nvl(bao5,0)) "M_RET_SALEIN",sum(nvl(bao6,0)) "M_TRANSFEROUT",sum(nvl(bao7,0)) "M_RETAIL",sum(nvl(bao8,0)) "M_OTHER_INOUT",sum(nvl(bao9,0)) "M_TRANSFERIN",docno, changedate,billtype from (
select
       --t.m_attributesetinstance_id,
       max(decode(billtype,'M_INVENTORY',  qty )) bao1,
       max(decode(billtype,'M_PURCHASEIN',  qty )) bao2,
       max(decode(billtype,'M_RET_PUROUT',  qty )) bao3,
       max(decode(billtype,'M_SALEOUT',  qty )) bao4,
       max(decode(billtype,'M_RET_SALEIN', qty )) bao5,
       max(decode(billtype,'M_TRANSFEROUT',  qty)) bao6,
       max(decode(billtype,'M_RETAIL', qty)) bao7,
       max(decode(billtype,'M_TRANSFERIN',  qty)) bao9,
       max(decode(billtype,'M_OTHER_INOUT', qty)) bao8,t.docno, t.c_store_id,
        t.m_product_id, t.m_attributesetinstance_id,t.changedate,t.billtype
  from fa_storage_ftp  t
   group by
       t.ad_client_id,
       t.ad_org_id,
       t.c_store_id,
        t.m_product_id,
        t.m_attributesetinstance_id,
        t.billtype,
        t.changedate,
       t.docno
       order by changedate) k   group by docno,changedate,billtype  order by docno
/

