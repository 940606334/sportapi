CREATE VIEW TDEFOSKU AS
  select sku,Style, Pname,Size1,clr, Ifabo
from
(
  select  sku,Style, Pname,Size1,clr, Ifabo
  from (select to_char(a.NO) as sku,to_char(b.name) as Style,to_char(b.VALUE) as Pname,
               to_char(c.VALUE2_CODE) as Size1,to_char(c.VALUE1_CODE) as clr,
               0 as Ifabo,ROW_NUMBER()
               OVER(PARTITION BY  b.name, c.VALUE2_CODE, c.VALUE1_CODE
               ORDER BY  b.name, c.VALUE2_CODE, c.VALUE1_CODE ) AS code_id
         from M_PRODUCT_ALIAS a, M_PRODUCT b,M_ATTRIBUTESETINSTANCE c,B_FAIR m,B_FAIRITEM n
         where a.M_PRODUCT_ID=b.id and c.id=a.M_ATTRIBUTESETINSTANCE_id and b.id(+)=n.M_PRODUCT_ID and m.id(+)=n.b_fair_id
          and length (a.NO)<=20
        and  to_char(sysdate, 'yyyymmdd')> = to_char(to_date(m.DATESTART,'yyyymmdd'),'YYYYMMDD')
        and  to_char(sysdate, 'yyyymmdd') <= to_char(to_date(m.DATEEND,'yyyymmdd'),'YYYYMMDD')
) where code_id =1
)
group by sku,Style, Pname,Size1,clr, Ifabo
/

