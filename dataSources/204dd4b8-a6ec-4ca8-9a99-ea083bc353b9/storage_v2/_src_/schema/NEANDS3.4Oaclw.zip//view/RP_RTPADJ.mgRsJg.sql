CREATE VIEW RP_RTPADJ AS
  select
rownum as id,
37 as ad_client_id,
27 as ad_org_id,
893 as ownerid,
893 as modifierid,
sysdate as creationdate,
sysdate as modifieddate,
'Y' as isactive,
b.b_rtpadj_id,a.priority,a.begindate,a.closedate,b.c_pricearea_id,c.m_product_id,c.price,a.statustime
from B_RTPADJ a,B_RTPADJAREAITEM b,B_RTPADJPDTITEM c
where a.id=b.b_rtpadj_id
and a.status=2
and a.id=c.b_rtpadj_id
WITH READ ONLY
/

