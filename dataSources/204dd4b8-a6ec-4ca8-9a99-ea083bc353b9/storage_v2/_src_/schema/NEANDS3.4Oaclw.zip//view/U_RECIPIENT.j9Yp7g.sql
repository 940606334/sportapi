CREATE VIEW U_RECIPIENT AS
  SELECT u.id * 10 + 1 AS id, u.ad_client_id, u.ad_org_id, u.NAME || '(U)' AS no,
       u.truename AS NAME, u.description AS description, u.phone2 AS addr_phone,
       u.emailuser AS addr_email, u.id AS user_id, 'users' AS rtype,
       u.c_department_id AS c_department_id, u.c_store_id AS c_store_id,
       u.c_customer_id AS c_customer_id, u.id record_id, NULL AS age,
       NULL AS sex, NULL AS c_city_id, NULL AS integral, NULL AS c_viptype_id
FROM users u
WHERE isactive = 'Y' /*用户*/
UNION
SELECT h.id * 10 + 2 AS id, h.ad_client_id, h.ad_org_id, h.no || '(E)', h.NAME,
       h.NAME AS description, h.handset, h.email, ur.id, 'hr_employee',
       h.c_department_id, h.c_store_id, h.c_customer_id, h.id, NULL AS age,
       NULL AS sex, NULL AS c_city_id, NULL AS integral, NULL AS c_viptype_id
FROM hr_employee h, users ur
WHERE h.isactive = 'Y'
AND ur.hr_employee_id(+) = h.id /*员工*/
UNION
SELECT c.id * 10 + 3 AS id, c.ad_client_id, c.ad_org_id, c.NAME || '(C)', c.NAME,
       c.description, c.mobile, c.email, NULL, 'c_customer', c.c_department_id,
       NULL, c.id, c.id, NULL AS age, NULL AS sex, NULL AS c_city_id,
       NULL AS integral, NULL AS c_viptype_id
FROM c_customer c
WHERE c.isactive = 'Y' /*经销商*/
UNION
SELECT v.id * 10 + 4 AS id, v.ad_client_id, v.ad_org_id, v.NAME || '(V)', v.NAME,
       v.description, v.mobil, v.email, NULL, 'c_supplier', NULL, NULL, NULL,
       v.id, NULL AS age, NULL AS sex, NULL AS c_city_id, NULL AS integral,
       NULL AS c_viptype_id
FROM c_supplier v
WHERE v.isactive = 'Y'
AND v.SUPTYPE = 'CLOSUPPLIER' /*供应商*/
UNION
SELECT v.id * 10 + 5 AS id, v.ad_client_id, v.ad_org_id, v.NAME || '(Y)', v.NAME,
       v.description, v.mobil, v.email, NULL, 'y_supplier', NULL, NULL, NULL,
       v.id, NULL AS age, NULL AS sex, NULL AS c_city_id, NULL AS integral,
       NULL AS c_viptype_id
FROM c_supplier v
WHERE v.isactive = 'Y'
AND v.SUPTYPE = 'SUPPLIER' /*原料供应商*/
UNION
SELECT v.id * 10 + 6 AS id, v.ad_client_id, v.ad_org_id, v.NAME || '(Z)', v.NAME,
       v.description, v.mobil, v.email, NULL, 'y_factory', NULL, NULL, NULL,
       v.id, NULL AS age, NULL AS sex, NULL AS c_city_id, NULL AS integral,
       NULL AS c_viptype_id
FROM c_supplier v
WHERE v.isactive = 'Y'
AND v.SUPTYPE = 'FACTORY' /*生产厂*/
UNION
SELECT id * 10 + 6, ad_client_id, ad_org_id, cardno || '(P)', vipname, vipname,
       mobil, email, NULL, 'c_vip', NULL, c_store_id, c_customer_id, id, age,
       sex, c_city_id, integral, c_viptype_id
FROM c_client_vip
WHERE (validdate IS NULL OR
      validdate >= to_number(to_char(SYSDATE, 'YYYYMMDD'))) /*VIP*/

