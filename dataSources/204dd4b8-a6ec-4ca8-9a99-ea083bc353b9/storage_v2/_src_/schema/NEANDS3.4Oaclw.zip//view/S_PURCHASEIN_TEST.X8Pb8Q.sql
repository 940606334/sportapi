CREATE VIEW S_PURCHASEIN_TEST AS
  select S_GET_C_SUPPLIER(t1.c_supplier_id,t2.c_supplier_id) as c_supplier_id,S_GET_C_SUPPLIER(t1.billdate,t2.billdate) as billdate,sum(t1.a_amt) as a_amt,sum(t1.totall) as totall,sum(t1.amt) as amt,
sum(t1.totpay) as totpay,sum(t1.p_price) as p_price,sum(t1.TOT_QIAN_AMT) as TOT_QIAN_AMT,sum(t1.C_AMT) as C_AMT,sum(t1.C_TOTAMT) as C_TOTAMT,sum(t1.CHARGEBACK) as CHARGEBACK,sum(t1.yufujin) as yufujin,
t2.id as s_plan_id,t2.s_material_id,
  t2.priceactual,sum(t2.qty) as qty,sum(t2.tot_amt) as tot_amt,sum(t2.qtyin) as qtyin,sum(t2.tot_amtin_actual) as tot_amtin_actual,sum(t2.dqty) as dqty,sum(t2.qtyout) as qtyout,
 sum(t2.dprice) as dprice from

(select c_supplier_id,billdate,sum(a_amt) as a_amt,sum(totall) as totall,sum(amt) as amt,sum(totpay) as totpay,sum(p_price) as p_price,
sum(TOT_QIAN_AMT) as TOT_QIAN_AMT,sum(C_AMT) as C_AMT,sum(C_TOTAMT) as C_TOTAMT,sum(CHARGEBACK) as CHARGEBACK,sum(yufujin) as yufujin
from
(
select c_supplier_id,billdate,0 as a_amt,0 as totall,0 as amt,0 as totpay,0 as p_price,0 as TOT_QIAN_AMT,
0 as C_AMT,0 as C_TOTAMT,0 as CHARGEBACK,sum(tot_amt_actual) as yufujin
from B_pay
where status=2  and C_FEETYPE_ID=2 group by c_supplier_id,billdate
union all
select c_supplier_id,billdate,sum(tot_amt_actual) as a_amt,0 as totall,0 as amt,0 as totpay,0 as p_price,0 as TOT_QIAN_AMT,
0 as C_AMT,0 as C_TOTAMT,0 as CHARGEBACK,0 as yufujin
from B_pay
where status=2   group by c_supplier_id,billdate
union all
select c_supplier_id,billdate,0 as a_amt,sum(tot_amt_actual) as totall,0 as amt,0 as totpay,0 as p_price,0 as TOT_QIAN_AMT,
0 as C_AMT,0 as C_TOTAMT,0 as CHARGEBACK,0 as yufujin
from B_pay
where status=2 group by c_supplier_id,billdate
union all
select c_supplier_id,billdate,0 as a_amt,0 as totall,nvl(sum(amt),0) as amt,0 as totpay,0 as p_price,0 as TOT_QIAN_AMT,
0 as C_AMT,0 as C_TOTAMT,0 as CHARGEBACK,0 as yufujin from
(select c_supplier_id,billdate ,nvl(sum(tot_actual),0) as amt from s_clearing where status=2 group by c_supplier_id,billdate
union all
select c_supplier_id,billdate ,-nvl(sum(tot_amt_actual),0) as amt from B_pay where status=2  group by c_supplier_id,billdate)
group by c_supplier_id,billdate

union all

select c_supplier_id,billdate,0 as a_amt,sum(a_amt) as totall,0 as amt,0 as totpay,0 as p_price,0 as TOT_QIAN_AMT,
0 as C_AMT,0 as C_TOTAMT,0 as CHARGEBACK,0 as yufujin from
(select c_supplier_id,billdate,sum(tot_amt) as a_amt from s_plan where status=2 group by c_supplier_id,billdate
union all
select c_supplier_id,billdate,nvl(-sum(tot_amt_actual),0) as a_amt from B_pay where status=2 group by c_supplier_id,billdate)
group by c_supplier_id,billdate

union all

select c_supplier_id,billdate,0 as a_amt,0 as totall,0 as amt,0 as totpay,0 as p_price,0 as TOT_QIAN_AMT,
0 as C_AMT,sum(TOT_AMT_ACTUAL) as c_totamt,0 as CHARGEBACK,0 as yufujin from B_SUPINVOICE where status=2
group by c_supplier_id,billdate

union all
select c_supplier_id,billdate,0 as a_amt,0 as totall,0 as amt,0 as totpay,0 as p_price,0 as TOT_QIAN_AMT,
sum(tot_amt) as c_amt,0 as c_totamt,0 as CHARGEBACK,0 as yufujin from s_plan  where status=2
group by c_supplier_id,billdate
union all
select t2.c_supplier_id,t2.billdate,0 as a_amt,0 as totall,0 as amt,0 as totpay,sum(t1.p_price) as p_price,0 as TOT_QIAN_AMT,
0 as c_amt,0 as c_totamt,0 as CHARGEBACK,0 as yufujin from s_clearingitem t1,s_clearing t2
where t1.s_clearing_id=t2.id and t2.status=2
group by t2.c_supplier_id,t2.billdate

union all
select b1.c_supplier_id,b1.billdate,0 as a_amt,0 as totall,0 as amt,0 as totpay,0 as p_price,0 as TOT_QIAN_AMT,
0 as c_amt,0 as c_totamt,nvl(sum(b1.tot_amt_actual),0) as Chargeback,0 as yufujin
from  B_PAYABLE b1,c_feetype b2
where b1.c_feetype_id=b2.id and b1.status=2 and b2.ISFEEMIN='Y' and ISSYSTEM='N'
group by b1.c_supplier_id,b1.billdate
 )
group by c_supplier_id,billdate) t1 full outer join

(select
b.c_supplier_id,b.id,b.billdate,a.s_material_id,
  a.priceactual,a.qty,a.tot_amt,a.qty-a.qtyres as qtyin ,(a.qty-a.qtyres)*a.priceactual as tot_amtin_actual,a.qtyres as dqty,a.qty-a.qtyres as qtyout,
  a.tot_amt-(a.qty-a.qtyres)*a.priceactual as dprice
   from s_planitem a,s_plan b where a.s_plan_id=b.id and
   b.status=2) t2
  on t1.c_supplier_id=t2.c_supplier_id and t1.billdate=t2.billdate group by S_GET_C_SUPPLIER(t1.c_supplier_id,t2.c_supplier_id),S_GET_C_SUPPLIER(t1.billdate,t2.billdate),
t2.id,t2.s_material_id,
  t2.priceactual
 order by S_GET_C_SUPPLIER(t1.c_supplier_id,t2.c_supplier_id)
/

