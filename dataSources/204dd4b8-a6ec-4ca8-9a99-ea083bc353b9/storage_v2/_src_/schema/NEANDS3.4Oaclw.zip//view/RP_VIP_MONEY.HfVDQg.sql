CREATE VIEW RP_VIP_MONEY AS
  select a.id || ascii('A') AS ID, a.AD_CLIENT_ID, a.AD_ORG_ID, a.ISACTIVE,
       a.MODIFIERID, a.CREATIONDATE, a.MODIFIEDDATE, a.ID as C_VIP_ID,
       a.C_VIPTYPE_ID, a.CARDNO, a.VIPNAME, a.C_STORE_ID, a.MOBIL, b.billdate,
       b.TOT_AMT_ACTUAL as AMT_ACTUAL_B,
       (select nvl(c.AMOUNT, 0) from fa_vipacc c where c.c_vip_id = a.id) AMOUNT,
       (select sum(TOT_AMT_ACTUAL) from B_VIPMONEY d where a.id = d.c_vip_id) AS TOT_AMT_ACTUAL_B,
       0 as AMT_ACTUAL, 0 AS TOT_AMT_ACTUAL
from C_client_VIP a, B_VIPMONEY b
where a.id = b.c_vip_id AND B.STATUS = 2
union all
select a.ID || ascii('B') AS ID, a.AD_CLIENT_ID, a.AD_ORG_ID, a.ISACTIVE,
       a.MODIFIERID, a.CREATIONDATE, a.MODIFIEDDATE, a.ID as C_VIP_ID,
       a.C_VIPTYPE_ID, a.CARDNO, a.VIPNAME, a.C_STORE_ID, a.MOBIL,b.CHANGDATE,
       0 AS TOT_AMT_ACTUAL_B, 0 AS AMOUNT, 0 AS TOT_AMT_ACTUAL_B,
       -b.vip_payamt AS AMT_ACTUAL,
       (SELECT SUM(-d.vip_payamt)
         from fa_vipintegral_ftp d
         where a.id = d.c_vip_id and d.description like '由零售单：%现金卡付款生成！') as TOT_AMT_ACTUAL
from C_client_VIP a, fa_vipintegral_ftp b
where a.id = b.c_vip_id and b.description like '由零售单：%现金卡付款生成！'
WITH READ only
/

