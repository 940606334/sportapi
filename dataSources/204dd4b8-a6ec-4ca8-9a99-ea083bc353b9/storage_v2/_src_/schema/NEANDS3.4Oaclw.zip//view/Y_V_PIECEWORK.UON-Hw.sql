CREATE VIEW Y_V_PIECEWORK AS
  select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.creationdate,a.modifierid,a.modifieddate,a.isactive,
a.id as y_inform_id,d.billdate,e.c_v_employee2_id as c_v_employee_id,g.y_workproce_id,g.fprice,b.qty
FROM Y_INFORM a,Y_INFORM_INVO_ITEM b,Y_COMPLETSER d,Y_COMPLETSER_INVO_ITEM e,Y_INFORM_PRO_ITEM g
where a.id=b.y_inform_id
and a.status=2
and d.status=2
and a.id=d.y_inform_id
and d.id=e.y_completser_id
and b.id=e.y_inform_invo_item_id
and a.id=g.y_inform_id
and g.y_workproce_id=b.y_workproce_id
/

