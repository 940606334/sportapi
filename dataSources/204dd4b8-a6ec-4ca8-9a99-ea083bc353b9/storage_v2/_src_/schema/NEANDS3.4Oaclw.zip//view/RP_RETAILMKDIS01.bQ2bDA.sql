CREATE VIEW RP_RETAILMKDIS01 AS
  select b.id,b.ad_client_id,a.docno,a.billdate,a.c_store_id,b.c_markbaltype_id,b.m_product_id,b.m_attributesetinstance_id,
b.qty,b.pricelist,b.priceactual,b.tot_amt_list,b.tot_amt_actual,d.markdis,b.tot_amt_actual*d.markdis as amt_mark,
b.tot_amt_actual - (b.tot_amt_actual*d.markdis) as amt_back,'Y' AS isactive,b.description ITEM_DESCRIPTION
from m_retail a,m_retailitem b,c_markbaltype c,c_markdis d
where a.id = b.m_retail_id
and c.id = d.c_markbaltype_id
and b.c_markbaltype_id = c.id
and a.c_store_id = d.c_store_id
and a.billdate between d.datebeg and d.dateend
and a.status = 2
union
select b.id,b.ad_client_id,a.docno,a.billdate,a.c_store_id,b.c_markbaltype_id,b.m_product_id,b.m_attributesetinstance_id,
b.qty,b.pricelist,b.priceactual,b.tot_amt_list,b.tot_amt_actual,d.markdis,b.tot_amt_actual*d.markdis as amt_mark,
b.tot_amt_actual - (b.tot_amt_actual*d.markdis) as amt_back,'Y' AS isactive,b.description ITEM_DESCRIPTION
from m_retail a,m_retailitem b,c_markbaltype c,c_store d
where a.id = b.m_retail_id
and b.c_markbaltype_id = c.id(+)
and a.c_store_id = d.id
and a.status = 2
and not exists (select 1 from m_retail aa,m_retailitem bb,c_markbaltype cc,c_markdis dd
where aa.id = bb.m_retail_id
and cc.id = dd.c_markbaltype_id
and bb.c_markbaltype_id = cc.id
and aa.c_store_id = dd.c_store_id
and aa.billdate between dd.datebeg and dd.dateend
and aa.status = 2
and bb.id=b.id)
with read only
/

