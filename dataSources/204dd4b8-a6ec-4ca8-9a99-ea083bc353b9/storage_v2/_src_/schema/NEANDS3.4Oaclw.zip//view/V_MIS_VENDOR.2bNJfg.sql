CREATE VIEW V_MIS_VENDOR AS
  SELECT id, code AS contactnum, NAME AS contactname_l,0 as IMPORTED
FROM c_supplier
WHERE modifieddate> sysdate-7
and isactive = 'Y'
/

