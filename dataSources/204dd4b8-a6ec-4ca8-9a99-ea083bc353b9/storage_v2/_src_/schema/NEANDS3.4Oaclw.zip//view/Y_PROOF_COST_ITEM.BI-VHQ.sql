CREATE VIEW Y_PROOF_COST_ITEM AS
  select Y_PROOF_ID as ID,max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,
max(OWNERID) as OWNERID,max(MODIFIERID) as MODIFIERID,SYSDATE as CREATIONDATE,SYSDATE as MODIFIEDDATE,'Y' as ISACTIVE,
Y_PROOF_ID,sum(FABCOST) AS FABCOST,SUM(ACCCOST) AS ACCCOST,SUM(PROCOST) AS PROCOST,SUM(FABCOST+ACCCOST+PROCOST) AS TOTALCOST
from
(
--计算面料成本
select max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,
max(OWNERID) as OWNERID,max(MODIFIERID) as MODIFIERID,
Y_PROOF_ID,sum(nvl(FOB,0)*nvl(per_num,0)) AS FABCOST,0 AS ACCCOST,0 AS PROCOST
FROM Y_PROOF_ITEM
where MATERIAL_TYPE = 'FAB'
group by Y_PROOF_ID
union all
--计算辅料成本
select max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,
max(OWNERID) as OWNERID,max(MODIFIERID) as MODIFIERID,
Y_PROOF_ID,0 AS FABCOST,sum(nvl(FOB,0)*nvl(per_num,0))  AS ACCCOST,0 AS PROCOST
FROM Y_PROOF_ITEM
where MATERIAL_TYPE = 'ACC'
group by Y_PROOF_ID
union all
--计算加工成本
select max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,
max(OWNERID) as OWNERID,max(MODIFIERID) as MODIFIERID,
Y_PROOF_ID,0 AS FABCOST,0 AS ACCCOST,SUM(nvl(FPRICE,0)) as PROCOST
from Y_PROOF_PRO_ITEM
group by Y_PROOF_ID
)
GROUP BY Y_PROOF_ID

/

