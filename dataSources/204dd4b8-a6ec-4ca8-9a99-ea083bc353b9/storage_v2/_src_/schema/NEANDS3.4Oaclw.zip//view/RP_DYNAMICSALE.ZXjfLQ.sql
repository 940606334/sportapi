CREATE VIEW RP_DYNAMICSALE AS
  SELECT t1.id,t1.ad_client_id,t1.ad_org_id,t1.c_store_id,t1.m_product_id,t1.m_attributesetinstance_id,
       avg(t1.priceactual) avgpriceactual,
       decode(SUM(t1.qtynow),0,0,MAX(t1.tot_amt_actual)/SUM(t1.qtynow)) priceactual,
       t1.percost,t1.marketdate,SUM(t1.qty3) sqty3,
       SUM(t1.qty7) sqty7,SUM(t1.qty15) sqty15,SUM(t1.qty30) sqty30,sum(t1.qtynow) sqtynow,
       t2.qty,t2.qtypreout,t2.qtyprein,(nvl(t2.qty, 0) - nvl(t2.qtypreout, 0) + nvl(t2.qtyprein, 0)) as qtyvalid,
       ((decode(SUM(t1.qtynow),0,0,MAX(t1.tot_amt_actual)/SUM(t1.qtynow)))-t1.percost)*SUM(t1.qtynow) AS profit,
       decode(MAX(t1.tot_amt_actual),0,0,(((decode(SUM(t1.qtynow),0,0,MAX(t1.tot_amt_actual)/SUM(t1.qtynow)))-t1.percost)*SUM(t1.qtynow))/(MAX(t1.tot_amt_actual))) grossrate,
       decode(sum(t2.qty),0,0,sum(t1.qtynow)/(t2.qty)) salerate
FROM
(select t.c_store_id AS ID,t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,avg(a.priceactual) priceactual,sum(a.tot_amt_actual) AS tot_amt_actual,nvl(q.percost,p.precost) percost,to_char(p.creationdate,'YYYYMMDD') marketdate,0 as qty3,0 AS qty7,0 AS qty15,0 AS qty30,sum(a.qty) qtynow
 from m_retail t,m_retailitem a,m_product p,fa_product_cost q,m_attributesetinstance s
 WHERE t.id=a.m_retail_id and a.m_product_id=p.id
       AND a.m_attributesetinstance_id=s.id AND p.id=q.m_product_id(+)
       AND t.status=2
 group BY t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,p.creationdate,p.precost,q.percost
 UNION ALL
 select t.c_store_id AS ID,t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,avg(a.priceactual) priceactual,sum(a.tot_amt_actual) AS tot_amt_actual,nvl(q.percost,p.precost) percost,to_char(p.creationdate,'YYYYMMDD') AS marketdate,sum(a.qty) as qty3,0 AS qty7,0 AS qty15,0 AS qty30,0 AS qtynow
 from m_retail t,m_retailitem a,m_product p,fa_product_cost q,m_attributesetinstance s
 WHERE t.id=a.m_retail_id and a.m_product_id=p.id
       AND a.m_attributesetinstance_id=s.id AND p.id=q.m_product_id(+)
       and t.statustime>sysdate-3 AND t.status=2
 group BY t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,p.creationdate,p.precost,q.percost
 UNION ALL
 select t.c_store_id AS ID,t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,avg(a.priceactual) priceactual,sum(a.tot_amt_actual) AS tot_amt_actual,nvl(q.percost,p.precost) percost,to_char(p.creationdate,'YYYYMMDD') marketdate,0 AS qty3,sum(a.qty) as qty7,0 AS qty15,0 AS qty30,0 AS qtynow
 from m_retail t,m_retailitem a,m_product p,fa_product_cost q,m_attributesetinstance s
 WHERE t.id=a.m_retail_id and a.m_product_id=p.id
       AND a.m_attributesetinstance_id=s.id AND p.id=q.m_product_id(+)
       and t.statustime>sysdate-7 AND t.status=2
--AND a.m_product_id=151798 AND a.m_attributesetinstance_id=67842
 group by t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,p.creationdate,p.precost,q.percost
 UNION ALL
 select t.c_store_id AS ID,t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,avg(a.priceactual) priceactual,sum(a.tot_amt_actual) AS tot_amt_actual,nvl(q.percost,p.precost) percost,to_char(p.creationdate,'YYYYMMDD') marketdate,0 AS qty3,0 AS qty7,sum(a.qty) as qty15,0 AS qty30,0 AS qtynow
 from m_retail t,m_retailitem a,m_product p,fa_product_cost q,m_attributesetinstance s
 WHERE t.id=a.m_retail_id and a.m_product_id=p.id
       AND a.m_attributesetinstance_id=s.id AND p.id=q.m_product_id(+)
       and t.statustime>sysdate-15 AND t.status=2
 group by t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,p.creationdate,p.precost,q.percost
 UNION ALL
 SELECT t.c_store_id AS ID,t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,avg(a.priceactual) priceactual,SUM(a.tot_amt_actual) AS tot_amt_actual,nvl(q.percost,p.precost) percost,to_char(p.creationdate,'YYYYMMDD') marketdate,0 AS qty3,0 AS qty7,0 AS qty15,sum(a.qty) as qty30,0 AS qtynow
 from m_retail t,m_retailitem a,m_product p,fa_product_cost q,m_attributesetinstance s
 WHERE t.id=a.m_retail_id and a.m_product_id=p.id
       AND a.m_attributesetinstance_id=s.id AND p.id=q.m_product_id(+)
       and t.statustime>sysdate-30 AND t.status=2
--AND a.m_product_id=151798 AND a.m_attributesetinstance_id=67842
 group by t.ad_client_id,t.ad_org_id,t.c_store_id,a.m_product_id,a.m_attributesetinstance_id,percost,p.creationdate,p.precost,q.percost
) t1,fa_storage  t2
WHERE t1.c_store_id=t2.c_store_id AND t1.m_product_id=t2.m_product_id AND t1.m_attributesetinstance_id=t2.m_attributesetinstance_id
--AND t1.m_product_id=151798 AND t1.m_attributesetinstance_id=67842
GROUP BY t1.id,t1.ad_client_id,t1.ad_org_id,t1.c_store_id,t1.m_product_id,t1.m_attributesetinstance_id,t1.percost,t1.marketdate,t2.qty,t2.qtypreout,t2.qtyprein
WITH READ ONLY
/

