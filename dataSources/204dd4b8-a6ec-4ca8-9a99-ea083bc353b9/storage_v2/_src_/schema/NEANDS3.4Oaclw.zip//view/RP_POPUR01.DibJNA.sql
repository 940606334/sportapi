CREATE VIEW RP_POPUR01 AS
  select a.id,a.billdate,a.docno,a.c_supplier_id,a.c_store_id,b.m_product_id,b.m_attributesetinstance_id,
b.qty as qtyso,e.qtypur,e.qtyin,e.qtydiff,f.qtyret,b.qty - nvl(e.qtyin,0) as qtyrem,
b.priceactual as so_price,e.pricecheck,b.tot_amt_actual,e.tot_amtpur_actual,e.tot_amtin_actual,
e.tot_amtdiff_actual,f.tot_amtret_actual,(b.qty - nvl(e.qtyin,0))*b.priceactual as tot_amtrem_actual
from b_po a inner join b_poitem b on a.id = b.b_po_id
left join (select c.b_po_id,d.m_product_id,d.m_attributesetinstance_id,avg(d.pricecheck) as pricecheck,
avg(d.priceactual) as pur_price,sum(d.qty) as qtypur,sum(d.qtyin) as qtyin,sum(d.qty)-sum(d.qtyin) as qtydiff,
avg(d.tot_amt_actual) as tot_amtpur_actual,avg(d.tot_amtin_actual) as tot_amtin_actual,
(sum(d.qty)-sum(d.qtyin))*avg(d.priceactual) as tot_amtdiff_actual
from m_purchase c, m_purchaseitem d
where c.id = d.m_purchase_id
and c.in_status = 2
group by c.b_po_id,d.m_product_id,d.m_attributesetinstance_id) e on a.id = e.b_po_id
and b.m_product_id = e.m_product_id
and b.m_attributesetinstance_id = e.m_attributesetinstance_id
left join (select c.b_po_id,d.m_product_id,d.m_attributesetinstance_id,
sum(d.qtyout) as qtyret,avg(d.priceactual) as ret_price,avg(d.tot_amtout_actual) as tot_amtret_actual
from m_ret_pur c, m_ret_puritem d
where c.id = d.m_ret_pur_id
and c.out_status = 2
group by c.b_po_id,d.m_product_id,d.m_attributesetinstance_id) f on a.id = f.b_po_id
and b.m_product_id = f.m_product_id
and b.m_attributesetinstance_id = f.m_attributesetinstance_id
where a.status = 2
with read only
/

