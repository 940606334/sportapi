CREATE VIEW USER_PURVIEW AS
  select g.id,
       g.ad_client_id,
       g.ad_org_id,
       g.truename,
       g.name,
       --g.description,
       g.email,
        e.description ,

       h.description as rwdesc,
        nvl(t.filterdesc,'所有') as filter,
       --t.sqlfilter,
       --t.ad_client_id,
       d.name as groupname,
       d.description as groupdesc,
       g.isactive,
       g.modifierid,
       g.modifieddate,
       g.ownerid,
       g.creationdate
  from groupperm t,
       users g,
       groups  d,
       groupuser f,
       directory e,
       AD_LIMITVALUE h
 where g.id = f.userid
       and f.groupid = d.id
       and d.id = t.groupid
       and t.directoryid=e.id and t.permission = h.value and h.ad_limitvalue_group_id=182
/

