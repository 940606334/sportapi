CREATE VIEW B_INVOICE_RECORD AS
  select b3.id AS ID,b3.ad_client_id,b3.ad_org_id,b3.ownerid,b3.modifierid,b3.creationdate,b3.modifieddate,b3.isactive,
b1.draw_invoice_empid as DRAW_INVOICE_EMPID ,b2.b_monthacc_id as B_MONTHACC_ID, b3.invoiceno,b3.js_invoiceno,b3.amt_invoice,
b3.draw_status as STATUS,b3.drawtime,b3.draw_invoice_empidactual
from B_MONTHACC b1,B_MARKINVOICE b2,B_MARKINVOICEITEM b3
where b1.id=b2.b_monthacc_id
and b2.id=b3.b_markinvoice_id
and b1.isactive='Y'
and b2.status=2
/

