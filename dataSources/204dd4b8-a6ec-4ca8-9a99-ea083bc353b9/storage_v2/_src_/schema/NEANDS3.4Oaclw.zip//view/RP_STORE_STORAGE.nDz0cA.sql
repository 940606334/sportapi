CREATE VIEW RP_STORE_STORAGE AS
  SELECT a.ID, a.AD_CLIENT_ID, a.AD_ORG_ID, a.OWNERID, a.MODIFIERID,
       a.CREATIONDATE, a.MODIFIEDDATE, a.ISACTIVE, a.c_store_id, a.qty,
       m.MIN_STORAGE, m.MAX_STORAGE, nvl(c.percost, 0) * a.qty AS AMT_PRICEQTY,
       nvl(c.percost, 0) * m.MIN_STORAGE AS min_AMT_PRICEQTY,
       nvl(c.percost, 0) * m.MAX_STORAGE AS MAX_AMT_PRICEQTY

FROM fa_storage a, m_product b, fa_product_cost c,
     c_store m, c_customer n, c_cusrank n1
WHERE a.m_product_id = b.id AND b.id = c.m_product_id(+) AND
      a.c_store_id = m.id AND m.c_customer_id = n.id AND n.c_cusrank_id = n1.id AND
      n1.NAME = '总部'
UNION ALL
SELECT a.ID, a.AD_CLIENT_ID, a.AD_ORG_ID, a.OWNERID, a.MODIFIERID,
       a.CREATIONDATE, a.MODIFIEDDATE, a.ISACTIVE, a.c_store_id, a.qty,
       m.MIN_STORAGE, m.MAX_STORAGE, nvl(c.percost, 0) * a.qty AS AMT_PRICEQTY,
       nvl(c.percost, 0) * m.MIN_STORAGE AS min_AMT_PRICEQTY,
       nvl(c.percost, 0) * m.MAX_STORAGE AS MAX_AMT_PRICEQTY

FROM fa_storage a, m_product b, FA_PRODUCT_CUSCOST c,
     c_store m, c_customer n, c_cusrank n1
WHERE a.m_product_id = b.id AND b.id = c.m_product_id(+) AND
      a.c_store_id = m.id AND c.c_customer_id = m.c_customer_id AND
      m.c_customer_id = n.id AND n.c_cusrank_id = n1.id AND n1.NAME <> '总部'
/

