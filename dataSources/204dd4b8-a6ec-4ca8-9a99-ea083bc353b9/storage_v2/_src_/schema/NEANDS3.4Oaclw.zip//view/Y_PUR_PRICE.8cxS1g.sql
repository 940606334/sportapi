CREATE VIEW Y_PUR_PRICE AS
  SELECT id, ad_client_id, ad_org_id, ownerid, modifierid, creationdate,
       modifieddate, isactive, docno, list_type, datasource, datein AS billdate,
       y_warehouse_id, y_supplier_id, remark, pck_status AS status, au_state,
       au_pi_id, tot_qty, tot_qtyin, tot_famount, tot_famountin,
       tot_famountin_pcheck, tot_famountin_dec, tot_famountin_fee,
       tot_famountin_pchecktax, datein, statuserid, statustime, inerid, intime,
       pcheckid, pchecktime, t.tax_dis, pricemodify, t.id AS y_pur_check_id,
       t.tot_tax_amt, t.tot_notax_amt
FROM y_purchase t
WHERE in_status = 2
/

