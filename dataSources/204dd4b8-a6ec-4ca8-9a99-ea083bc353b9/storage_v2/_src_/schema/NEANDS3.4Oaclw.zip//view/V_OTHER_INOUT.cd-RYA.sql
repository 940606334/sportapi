CREATE VIEW V_OTHER_INOUT AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.billdate,a.docno,a.doctype,a.c_store_id,a.description,a.status,a.statuserid,a.statustime,a.tot_lines,
a.tot_qty,a.c_period_id,a.c_customer_id,a.dateout,a.datein,a.inerid,a.intime,a.outerid,a.outtime,
a.c_other_inouttype_id,a.otherbilltype,
b.m_other_inout_id,b.orderno,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.pricelist,b.tot_amt_list,b.m_productalias_id
from m_other_inout a, m_other_inoutitem b
where a.id = b.m_other_inout_id
order by a.docno desc
--with read only
/

