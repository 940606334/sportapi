CREATE VIEW RP_SALE001 AS
  SELECT b.id,
       b.ad_client_id,
       b.ad_org_id,
       a.dateout                   AS billdate,
       a.docno,
       a.doctype,
       a.b_so_id,
       a.c_store_id,
       a.c_dest_id,
       a.c_customerup_id,
       a.c_customer_id,
       b.m_product_id,
       b.m_productalias_id,
       b.m_attributesetinstance_id,
       b.qtyout                    AS qtysaleout,
       0                           AS qtyretsalein,
       b.pricelist,
       b.priceactual,
       b.tot_amtout_actual         AS amtsaleout,
       0                           AS amtretsalein,
       b.discount                  AS discountsale,
       0                           AS discountretsale,
       a.description
FROM m_sale a, m_saleitem b
WHERE a.id = b.m_sale_id
AND a.out_status = 2
UNION ALL
SELECT b.id,
       b.ad_client_id,
       b.ad_org_id,
       a.datein,
       a.docno,
       a.doctype,
       a.b_so_id,
       a.c_store_id,
       a.c_orig_id,
       a.c_customerup_id,
       a.c_customer_id,
       b.m_product_id,
       b.m_productalias_id,
       b.m_attributesetinstance_id,
       0,
       b.qtyin,
       b.pricelist,
       b.priceactual,
       0,
       b.tot_amtin_actual,
       0,
       b.discount,
       a.description
FROM m_ret_sale a, m_ret_saleitem b
WHERE a.id = b.m_ret_sale_id
AND a.in_status = 2
WITH READ ONLY
/

