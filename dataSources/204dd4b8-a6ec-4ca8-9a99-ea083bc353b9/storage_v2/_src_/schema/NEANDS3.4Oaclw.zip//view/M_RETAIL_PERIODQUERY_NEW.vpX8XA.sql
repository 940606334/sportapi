CREATE VIEW M_RETAIL_PERIODQUERY_NEW AS
  select max(a.id) as id,a.billdate,a.c_store_id,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'000000','yyyymmddhh24miss') and
                             to_date(a.billdate||'005959','yyyymmddhh24miss')
       ) as AMT_ACTUAL1,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'010000','yyyymmddhh24miss') and
                             to_date(a.billdate||'015959','yyyymmddhh24miss')
       ) as AMT_ACTUAL2,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'020000','yyyymmddhh24miss') and
                             to_date(a.billdate||'025959','yyyymmddhh24miss')
       ) as AMT_ACTUAL3,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'030000','yyyymmddhh24miss') and
                             to_date(a.billdate||'035959','yyyymmddhh24miss')
       ) as AMT_ACTUAL4,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'040000','yyyymmddhh24miss') and
                             to_date(a.billdate||'045959','yyyymmddhh24miss')
       ) as AMT_ACTUAL5,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'050000','yyyymmddhh24miss') and
                             to_date(a.billdate||'055959','yyyymmddhh24miss')
       ) as AMT_ACTUAL6,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'060000','yyyymmddhh24miss') and
                             to_date(a.billdate||'065959','yyyymmddhh24miss')
       ) as AMT_ACTUAL7,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'070000','yyyymmddhh24miss') and
                             to_date(a.billdate||'075959','yyyymmddhh24miss')
       ) as AMT_ACTUAL8,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'080000','yyyymmddhh24miss') and
                             to_date(a.billdate||'085959','yyyymmddhh24miss')
       ) as AMT_ACTUAL9,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'090000','yyyymmddhh24miss') and
                             to_date(a.billdate||'095959','yyyymmddhh24miss')
       ) as AMT_ACTUAL10,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'100000','yyyymmddhh24miss') and
                             to_date(a.billdate||'105959','yyyymmddhh24miss')
       ) as AMT_ACTUAL11,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'110000','yyyymmddhh24miss') and
                             to_date(a.billdate||'115959','yyyymmddhh24miss')
       ) as AMT_ACTUAL12,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'120000','yyyymmddhh24miss') and
                             to_date(a.billdate||'125959','yyyymmddhh24miss')
       ) as AMT_ACTUAL13,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'130000','yyyymmddhh24miss') and
                             to_date(a.billdate||'135959','yyyymmddhh24miss')
       ) as AMT_ACTUAL14,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'140000','yyyymmddhh24miss') and
                             to_date(a.billdate||'145959','yyyymmddhh24miss')
       ) as AMT_ACTUAL15,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'150000','yyyymmddhh24miss') and
                             to_date(a.billdate||'155959','yyyymmddhh24miss')
       ) as AMT_ACTUAL16,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'160000','yyyymmddhh24miss') and
                             to_date(a.billdate||'165959','yyyymmddhh24miss')
       ) as AMT_ACTUAL17,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'170000','yyyymmddhh24miss') and
                             to_date(a.billdate||'175959','yyyymmddhh24miss')
       ) as AMT_ACTUAL18,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'180000','yyyymmddhh24miss') and
                             to_date(a.billdate||'185959','yyyymmddhh24miss')
       ) as AMT_ACTUAL19,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'190000','yyyymmddhh24miss') and
                             to_date(a.billdate||'195959','yyyymmddhh24miss')
       ) as AMT_ACTUAL20,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'200000','yyyymmddhh24miss') and
                             to_date(a.billdate||'205959','yyyymmddhh24miss')
       ) as AMT_ACTUAL21,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'210000','yyyymmddhh24miss') and
                             to_date(a.billdate||'215959','yyyymmddhh24miss')
       ) as AMT_ACTUAL22,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'220000','yyyymmddhh24miss') and
                             to_date(a.billdate||'225959','yyyymmddhh24miss')
       ) as AMT_ACTUAL23,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and
              b.creationdate between to_date(a.billdate||'230000','yyyymmddhh24miss') and
                             to_date(a.billdate||'235959','yyyymmddhh24miss')
       ) as AMT_ACTUAL24
from m_retail a
where a.status=2
group by a.billdate,a.c_store_id
/

