CREATE VIEW EB_EORDERSOVISIBLITEM AS
  select max(a.id) as id ,max(a.ad_client_id) as ad_client_id,max(a.ad_org_id) as ad_org_id,
       max(a.ownerid) as ownerid,max(a.modifierid) as modifierid,max(a.creationdate) as creationdate,
       max(a.modifieddate) as modifieddate,max(a.isactive) as isactive,
       1 as EB_EORDERSOVISIBL_ID,wm_concat(a.docno) as docno,a.doctype,a.BUYER_NICK,
       a.RECEIVER_NAME,a.RECEIVER_ADDRESS,a.C_STORE_ID,a.C_ORIG_ID
from EB_ORDERSO a
where a.status = 2
and a.VE_STATUS = 1
and a.SOURCE <> 'WEB'
and a.isactive = 'Y'
and a.mergdocno is null
and a.SPLIDOCNO is null
and a.doctype is not null
and a.doctype='NOR'
/*and a.BUYER_NICK is not null*/
/*and a.RECEIVER_NAME is not null*/
/*and a.RECEIVER_ADDRESS is not null*/
group by a.doctype,a.BUYER_NICK,a.RECEIVER_NAME,a.RECEIVER_ADDRESS,a.C_STORE_ID,a.C_ORIG_ID
having count(1)>1
/

