CREATE VIEW RP_STORERECVCHECK AS
  SELECT id,
       ad_client_id,
       ad_org_id,
       docno,
       billdate,
			 c_customer_id,
       c_store_id,
       description,
       tot_amt,
       lag(total, 1, NULL) over(PARTITION BY c_store_id ORDER BY billdate, docno, statustime) last_hire,
       in_amt,
       out_amt,
       total,
       c_storecosttype_id,
       c_payway_id,
       c_bankaccount_id,
       handler_id,
       statuserid AS modifierid,
			 statustime AS modifieddate,pick_status
FROM (SELECT k.*,
             SUM(k.tot_amt) over(PARTITION BY c_store_id ORDER BY billdate, docno, statustime rows 10000000 preceding) AS total
      FROM (
            --店铺费用
            SELECT g.id || 65 AS id,
                    g.ad_client_id,
                    g.ad_org_id,
                    g.docno,
                    g.billdate,
                    g.c_customer_id,
                    g.c_store_id,
                    g.amt AS tot_amt,
                    0 AS in_amt, --收款
                    g.amt AS out_amt, --费用
                    g.statustime,
                    g.statuserid,
                    g.c_storecosttype_id,
                    g.c_payway_id,
                    g.c_bankaccount_id,
                    g.handler_id,
                    g.description,g.pick_status
            FROM b_storebank g
            WHERE g.status = 2
            AND g.is_receipts = 1
            UNION ALL
            --店铺费用
            SELECT g.id || 66 AS id,
                   g.ad_client_id,
                   g.ad_org_id,
                   g.docno,
                   g.billdate,
                   g.c_customer_id,
                   g.c_store_id,
                   g.amt AS tot_amt,
                   g.amt AS in_amt, --收款
                   0 AS out_amt, --费用
                   g.statustime,
                   g.statuserid,
                   g.c_storecosttype_id,
                   g.c_payway_id,
                   g.c_bankaccount_id,
                   g.handler_id,
                   g.description,g.pick_status
            FROM b_storebank g
            WHERE g.status = 2
            AND g.is_receipts = 0) k
      WHERE EXISTS (SELECT 1 FROM dual WHERE k.c_store_id = c_store_id)) h
ORDER BY c_store_id, billdate, docno, statustime
WITH READ ONLY
/

