CREATE VIEW S_V_SAMPLING AS
  select  t1.M_PUR_PRICE_ID,t1.billdate,t2.M_PRODUCT_ID,t2.TOTIN_QTY,
  t2.S_SAMTYPE_ID,t2.TOT_QTY,t2.BAD_QTY,t2.REMARK,t2.S_SAMMETHED_ID,t2.TOT_QTY/t2.TOTIN_QTY  as samp_rate

  from s_sampling t1,s_samplingitem t2
  where t1.id=t2.s_sampling_id and t1.status=2
/

