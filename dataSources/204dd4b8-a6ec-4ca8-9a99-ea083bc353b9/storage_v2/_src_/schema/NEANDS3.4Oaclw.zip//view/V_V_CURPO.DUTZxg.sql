CREATE VIEW V_V_CURPO AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.doctype,a.billdate,a.description,a.salesrep_id,a.c_customerup_id,a.c_store_id,a.c_customer_id,
a.c_dest_id,a.status,a.statuserid,
a.statustime,a.c_period_id,a.close_status,a.closerid,a.closetime,
a.predateout,a.b_fair_id,
b.b_so_id,b.orderno,b.m_product_id,b.m_attributesetinstance_id,b.pricelist,b.priceactual,b.discount,b.qty,
b.qtyconsign,b.qtyoccu,b.qtyrem,
b.tot_amt_list,b.tot_amt_actual,b.M_PRODUCTALIAS_ID
from b_so a, b_soitem b
where a.id = b.b_so_id
order by docno desc
--with read only
/

