CREATE VIEW TC_STYLE AS
  select id,t.name as style, t.value as style_name,t.pricelist as price, t.unit,t.description as remark,
m_dim1_id as Attrib1, m_dim2_id as Attrib2, m_dim3_id as Attrib3, m_dim4_id as Attrib4, m_dim5_id as Attrib5,
m_dim6_id as Attrib6, m_dim7_id as Attrib7, m_dim8_id as Attrib8, m_dim9_id as Attrib9, m_dim10_id as Attrib10,
m_dim11_id as Attrib11, m_dim12_id as Attrib12, m_dim13_id as Attrib13, m_dim14_id as Attrib14,
m_dim15_id as Attrib15, m_dim16_id as Attrib16, m_dim17_id as Attrib17, m_dim18_id as Attrib18,
m_dim19_id as Attrib19, m_dim20_id as Attrib20
from m_product t
/

