CREATE VIEW TDEFOATTRIB AS
  select a.ATTRIBCODE, a.ATTRIBNAME as AttribDefName,to_number(substr(b.dimflag,4)) as AttribDefId from M_DIM a, M_DIMDEF b
where b.id=a.M_DIMDEF_ID and a.dimflag=b.dimflag
/

