CREATE VIEW TDEFOSIZEGROUP AS
  select  to_char(name) as sizegid, to_char(description) as description
from m_attribute
where clrsize=2
/

