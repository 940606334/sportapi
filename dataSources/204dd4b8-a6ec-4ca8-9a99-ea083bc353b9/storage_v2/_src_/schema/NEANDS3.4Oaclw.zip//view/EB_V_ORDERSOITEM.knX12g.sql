CREATE VIEW EB_V_ORDERSOITEM AS
  select t.id,t.ad_client_id,t.eb_orderso_id,t.m_productalias_id,t.m_product_id,t.m_attributesetinstance_id,t.qty,t.rqty,t.qtyout,
t.qtyin,t.orderno,t.adjust_fee,t.discount_fee,t.price,t.total_fee,t.payment,t.status,t.out_status,t.in_status,t.ve_status,
t.ownerid,t.modifierid,t.creationdate,t.modifieddate,t.isactive,t.qtyfcan,t.DIF_AMT
from EB_ORDERSOITEM t
/

