CREATE VIEW M_INITEM AS
  SELECT to_number(id || ascii('H')) AS id, id AS real_id, ad_client_id, ad_org_id,
       isactive, creationdate, ownerid, modifieddate, modifierid,
       to_number(m_sale_id || ascii('H')) AS m_in_id, orderno, m_product_id,
       m_attributesetinstance_id, qty, qtyout, qtyin, qtydiff, pricelist,
       priceactual, discount, description, tot_amt_list, tot_amt_actual,
       tot_amtout_list, tot_amtout_actual, tot_amtin_list, tot_amtin_actual,
       in_status AS status, precost, tot_amt_precost, tot_amtin_precost,
       m_productalias_id, 'H' AS billtype, 0 AS good_qty, 0 AS defect_qty,
       0 AS fgood_qty, NULL AS deladvice, NULL AS defectremark,
       NULL AS check_description
FROM m_saleitem
WHERE status = 2
AND out_status = 2 --and in_status <> 2
UNION ALL
SELECT to_number(id || ascii('I')) AS id, id AS real_id, ad_client_id, ad_org_id,
       isactive, creationdate, ownerid, modifieddate, modifierid,
       to_number(m_ret_sale_id || ascii('I')) AS m_in_id, orderno, m_product_id,
       m_attributesetinstance_id, qty, qtyout, qtyin, qtydiff, pricelist,
       priceactual, discount, description, tot_amt_list, tot_amt_actual,
       tot_amtout_list, tot_amtout_actual, tot_amtin_list, tot_amtin_actual,
       in_status AS status, precost, tot_amt_precost, tot_amtin_precost,
       m_productalias_id, 'I' AS billtype, 0 AS good_qty, 0 AS defect_qty,
       0 AS fgood_qty, NULL AS deladvice, NULL AS defectremark,
       NULL AS check_description
FROM m_ret_saleitem
WHERE status = 2
AND out_status = 2 --and in_status <> 2
UNION ALL
SELECT to_number(id || ascii('J')) AS id, id AS real_id, ad_client_id, ad_org_id,
       isactive, creationdate, ownerid, modifieddate, modifierid,
       to_number(m_transfer_id || ascii('J')) AS m_in_id, orderno, m_product_id,
       m_attributesetinstance_id, qty, qtyout, qtyin, qtydiff, pricelist,
       NULL AS priceactual, NULL AS discount, description,
       tot_amtqty_list AS tot_amt_list, NULL AS tot_amt_actual, tot_amtout_list,
       NULL AS tot_amtout_actual, tot_amtin_list, NULL AS tot_amtin_actual,
       in_status AS status, precost, tot_amt_precost, tot_amtin_precost,
       m_productalias_id, 'J' AS billtype, 0 AS good_qty, 0 AS defect_qty,
       0 AS fgood_qty, NULL AS deladvice, NULL AS defectremark,
       NULL AS check_description
FROM m_transferitem
WHERE status = 2
AND out_status = 2 --and in_status <> 2
UNION ALL
SELECT to_number(id || ascii('K')) AS id, id AS real_id, ad_client_id, ad_org_id,
       isactive, creationdate, ownerid, modifieddate, modifierid,
       to_number(m_sale_id || ascii('K')) AS m_in_id, orderno, m_product_id,
       m_attributesetinstance_id, qty, qtyout, qtyin, qtydiff, pricelist,
       priceactual, discount, description, tot_amt_list, tot_amt_actual,
       tot_amtout_list, tot_amtout_actual, tot_amtin_list, tot_amtin_actual,
       in_status AS status, precost, tot_amt_precost, tot_amtin_precost,
       m_productalias_id, 'K' AS billtype, 0 AS good_qty, 0 AS defect_qty,
       0 AS fgood_qty, NULL AS deladvice, NULL AS defectremark,
       NULL AS check_description
FROM m_saleitem
WHERE status = 2
AND out_status = 2 --and in_status <> 2
UNION ALL
SELECT to_number(id || ascii('L')) AS id, id AS real_id, ad_client_id, ad_org_id,
       isactive, creationdate, ownerid, modifieddate, modifierid,
       to_number(m_purchase_id || ascii('L')) AS m_in_id, orderno, m_product_id,
       m_attributesetinstance_id, qty, qty AS qtyout, qtyin, qtydiff, pricelist,
       priceactual, discount, description, tot_amt_list, tot_amt_actual,
       tot_amt_list AS tot_amtout_list, tot_amt_actual AS tot_amtout_actual,
       tot_amtin_list, tot_amtin_actual, in_status AS status, precost,
       tot_amt_precost, tot_amtin_precost, m_productalias_id, 'L' AS billtype,
       good_qty, defect_qty, fgood_qty, deladvice, defectremark,
       check_description
FROM m_purchaseitem
WHERE status = 2 --and in_status <> 2
UNION ALL
SELECT to_number(id || ascii('M')) AS id, id AS real_id, ad_client_id, ad_org_id,
       isactive, creationdate, ownerid, modifieddate, modifierid,
       to_number(m_cro_sale_id || ascii('M')) AS m_in_id, NULL AS orderno,
       m_product_id, m_attributesetinstance_id, qty, qtyout, qtyin,
       qtydiff AS qtydiff, pricelist, priceactual1 AS priceactual,
       discount1 AS discount, NULL AS description, tot_amt_list AS tot_amt_list,
       tot_amt_actual1 AS tot_amt_actual, tot_amtout_list AS tot_amtout_list,
       tot_amtout_actual1 AS tot_amtout_actual,
       tot_amtin_list AS tot_amtin_list, tot_amtin_actual1 AS tot_amtin_actual,
       NULL AS status, 0 AS precost, 0 AS tot_amt_precost,
       0 AS tot_amtin_precost, m_productalias_id, 'M' AS billtype,
       0 AS good_qty, 0 AS defect_qty, 0 AS fgood_qty, NULL AS deladvice,
       NULL AS defectremark, NULL AS check_description
FROM m_cro_saleitem
UNION ALL
SELECT to_number(id || ascii('N')) AS id, id AS real_id, ad_client_id, ad_org_id,
       isactive, creationdate, ownerid, modifieddate, modifierid,
       to_number(m_cro_retsale_id || ascii('N')) AS m_in_id, NULL AS orderno,
       m_product_id, m_attributesetinstance_id, qty, qtyout, qtyin,
       NULL AS qtydiff, pricelist, priceactual1 AS priceactual,
       discount1 AS discount, NULL AS description, tot_amt_list AS tot_amt_list,
       tot_amt_actual1 AS tot_amt_actual, tot_amtout_list AS tot_amtout_list,
       tot_amtout_actual1 AS tot_amtout_actual,
       tot_amtin_list AS tot_amtin_list, tot_amtin_actual1 AS tot_amtin_actual,
       NULL AS status, 0 AS precost, 0 AS tot_amt_precost,
       0 AS tot_amtin_precost, m_productalias_id, 'M' AS billtype,
       0 AS good_qty, 0 AS defect_qty, 0 AS fgood_qty, NULL AS deladvice,
       NULL AS defectremark, NULL AS check_description
FROM m_cro_retsaleitem
--and in_status <> 2
/

