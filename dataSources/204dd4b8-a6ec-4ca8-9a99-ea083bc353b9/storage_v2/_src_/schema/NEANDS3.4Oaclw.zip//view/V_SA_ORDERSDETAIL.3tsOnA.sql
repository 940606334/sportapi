CREATE VIEW V_SA_ORDERSDETAIL AS
  SELECT b.id,
       a.docno || '-' || b.id AS orderid,
       1 AS subid,
       d.name AS inventory_id,
       to_date(b.confirmdate, 'yyyy-MM-dd') AS duedate,
       b.qty * c.tot_qty AS qty,
       d.precost AS price,
       b.qty * c.tot_qty * d.precost AS amount,
       decode(e.rankno, 1, f.qty, 0) * c.tot_qty AS size1,
       decode(e.rankno, 2, f.qty, 0) * c.tot_qty AS size2,
       decode(e.rankno, 3, f.qty, 0) * c.tot_qty AS size3,
       decode(e.rankno, 4, f.qty, 0) * c.tot_qty AS size4,
       decode(e.rankno, 5, f.qty, 0) * c.tot_qty AS size5,
       decode(e.rankno, 6, f.qty, 0) * c.tot_qty AS size6,
       decode(e.rankno, 7, f.qty, 0) * c.tot_qty AS size7,
       decode(e.rankno, 8, f.qty, 0) * c.tot_qty AS size8,
       decode(e.rankno, 9, f.qty, 0) * c.tot_qty AS size9,
       decode(e.rankno, 10, f.qty, 0) * c.tot_qty AS size10,
       decode(e.rankno, 11, f.qty, 0) * c.tot_qty AS size11,
       decode(e.rankno, 12, f.qty, 0) * c.tot_qty AS size12,
       decode(e.rankno, 13, f.qty, 0) * c.tot_qty AS size13,
       decode(e.rankno, 14, f.qty, 0) * c.tot_qty AS size14,
       decode(e.rankno, 15, f.qty, 0) * c.tot_qty AS size15,
       decode(e.rankno, 16, f.qty, 0) * c.tot_qty AS size16,
       decode(e.rankno, 17, f.qty, 0) * c.tot_qty AS size17,
       decode(e.rankno, 18, f.qty, 0) * c.tot_qty AS size18,
       decode(e.rankno, 19, f.qty, 0) * c.tot_qty AS size19,
       decode(e.rankno, 20, f.qty, 0) * c.tot_qty AS size20,0 as IMPORTED
FROM b_po            a,
     b_poboxitem     b,
     m_matchsize     c,
     m_product       d,
     m_size          e,
     m_matchsizeitem f
WHERE a.id = b.b_po_id
AND b.m_matchsize_id = c.id
AND c.id = f.m_matchsize_id
AND b.m_product_id = d.id
AND f.m_size_id = e.id
AND a.status = 2
--and a.statustime>sysdate-7
/

