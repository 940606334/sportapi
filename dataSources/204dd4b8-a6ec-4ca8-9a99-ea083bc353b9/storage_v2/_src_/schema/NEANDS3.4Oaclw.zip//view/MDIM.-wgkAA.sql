CREATE VIEW MDIM AS
  select a.id,a.m_dimdef_id,a.attribcode,a.attribname,a.DIMFLAG from m_dim a/* edit by Selina 2016/11/1 11:25:20 */

