CREATE VIEW S_PURCHASE_A AS
  select c_supplier2_id,billdate as receiptdate,s_material_id,sum(qtyin) as qtyin,sum(in_qty) as in_qty,sum(out_qty) as out_qty from
 (select a.c_supplier2_id,a.receiptdate as billdate,b.s_material_id,b.qtyin,0 as in_qty,0 as out_qty
    from s_purchase a,s_purchaseitem b where a.id=b.s_purchase_id and a.status=2
    union all
  select  C_SUPPLIER2_ID,BILLDATE,s_material_id,0 as qtyin,sum(in_qty) as in_qty,sum(out_qty) as out_qty from
    (select t1.C_SUPPLIER2_ID as C_SUPPLIER2_ID,t1.BILLDATE,t2.s_material_id,0 as in_qty,t2.qty as out_qty from s_transfer t1,s_transferitem t2
    where t1.id=t2.s_transfer_id and t1.status=2
    union all
    select t1.c_supplier3_id as C_SUPPLIER2_ID,t1.billdate,t2.s_material_id,t2.qty as in_qty,0 as in_qty  from s_transfer t1,s_transferitem t2
    where t1.id=t2.s_transfer_id and t1.status=2) group by C_SUPPLIER2_ID,BILLDATE,s_material_id)
    group by  c_supplier2_id,billdate,s_material_id
  with read only
/

