CREATE VIEW M_PDTAREA_PRICE AS
  select t.id as c_pricearea_id,t.name as areaname,rtl_price_analysis(g.id,t.id) as pricelist,
g.id as m_product_id,g.name as pdtname from c_pricearea t,m_product g
where t.ad_client_id = g.ad_client_id
/

