CREATE VIEW V_RKDATA AS
  select barcode,0 as qty,0 as datetime,4-count(1) as cnt
from rkdata t
group by t.barcode
having 4-count(1)>0
/

