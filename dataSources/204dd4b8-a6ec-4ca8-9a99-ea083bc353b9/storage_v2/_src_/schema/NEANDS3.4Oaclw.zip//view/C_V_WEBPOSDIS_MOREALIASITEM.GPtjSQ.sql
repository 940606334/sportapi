CREATE VIEW C_V_WEBPOSDIS_MOREALIASITEM AS
  select a.id,a.c_webposdis_id,a.M_PRODUCTALIAS_ID,a.EXEC
from C_WEBPOSDIS t,C_WEBPOSDIS_MOREALIASITEM a
where t.id=a.c_webposdis_id
and t.isactive='Y'
and t.STATUS = 2 and t.close_status=1
and to_char(sysdate+1,'yyyymmdd')>=DATEBEGIN
and to_char(sysdate,'yyyymmdd')<=DATEEND/* edit by Selina 2017/2/24 15:17:36 */

