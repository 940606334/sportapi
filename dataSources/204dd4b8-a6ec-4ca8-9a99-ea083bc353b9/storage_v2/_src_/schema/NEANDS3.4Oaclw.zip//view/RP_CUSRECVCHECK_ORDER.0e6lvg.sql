CREATE VIEW RP_CUSRECVCHECK_ORDER AS
  select h."ID", h."AD_CLIENT_ID", h."AD_ORG_ID", h."MODIFIEDDATE", h."DOCNO",
       h."DOCTYPE", h."BILLDATE", h."C_CUSTOMER_ID", h."DESCRIPTION",
       h."M_SALE_ID", h."M_RET_SALE_ID", h."TOT_AMT_ACTUAL", h."C_FEETYPE_ID",
       LAG("TOTAL", 1, NULL) OVER(partition by c_customer_id ORDER BY billdate, h.MODIFIEDDATE, DOCNO) last_hire,
       h."COLLECT_AMT", h."DEDUCT_AMT", h."TOTAL",
       h."TOT_AMT_ORDER", LAG("TOTAL_ORDER",1,NULL)OVER(partition by c_customer_id order by h.billdate,h.modifieddate,docno) last_hire_order,
       h."COLLECT_AMT_ORDER",h."DEDUCT_AMT_ORDER",h."TOTAL_ORDER"
from (select k.*,  SUM(k.tot_amt_actual) OVER(partition by c_customer_id
ORDER BY billdate, MODIFIEDDATE, DOCNO ROWS 10000000 PRECEDING) as "TOTAL",
  sum(k.tot_AMT_ORDER)over(partition by c_customer_id order by billdate, MODIFIEDDATE, DOCNO ROWS 10000000 PRECEDING)
  as "TOTAL_ORDER"
       from (select g.id, g.ad_client_id, g.ad_org_id, g.docno, g.doctype,
                     g.billdate, g.c_customer_id, g.description, g.status,
                     null as m_sale_id, null as m_ret_sale_id, g.tot_amt_actual,
                     g.c_feetype_id, g.tot_amt_actual as collect_amt,
                     0 as deduct_amt, g.modifieddate, g.AMT_ORDER tot_AMT_ORDER ,g.AMT_ORDER as collect_amt_order,0 as deduct_amt_order
              from b_receive g
              where g.status = 2
              union
              select t.id, t.ad_client_id, t.ad_org_id, t.docno, t.doctype,
                     t.billdate, t.c_customer_id, t.description, t.status,
                     t.m_sale_id, t.m_ret_sale_id,
                     -t.tot_amt_actual as tot_amt_actual, t.c_feetype_id,
                     0 as collect_amt, t.tot_amt_actual as deduct_amt0,
                     t.modifieddate,-t.AMT_ORDER as tot_AMT_ORDER ,  0 as collect_amt_order,amt_order as deduct_amt_order
              from b_receivable t
              where t.status = 2) k
       where exists (select 1 from dual where k.c_customer_id = c_customer_id)) h
order by billdate, modifieddate, DOCNO
/

