CREATE VIEW M_V_AREAPICKSTORYITEM AS
  select  t.id,t.ad_client_id,t.ad_org_id, t.ownerid,t.modifierid,
t.creationdate,t.modifieddate,t.isactive,
t.m_areapick_id,t.boxno,t.M_PRODUCT_ID,t.m_productalias_id,t.M_ATTRIBUTESETINSTANCE_ID,t.c_store_location_id,t.qtyout
from M_AREAPICKSTORYITEM t
/

