CREATE VIEW M_PRODUCT_INC AS
  select name,value,M_DIM1_ID,M_DIM2_ID,M_DIM3_ID,M_DIM4_ID,M_DIM5_ID,M_DIM6_ID,M_DIM7_ID,M_DIM8_ID,M_DIM9_ID,
serialNO,unit,pricelist,documentnote,t.creationdate
from m_product t,m_dim d
where t.m_dim2_id=d.id
and d.attribcode=to_char(sysdate,'yyyy')

/

