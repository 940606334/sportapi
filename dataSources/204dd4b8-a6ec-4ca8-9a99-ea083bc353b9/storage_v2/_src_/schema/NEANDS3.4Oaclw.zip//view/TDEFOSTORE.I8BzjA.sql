CREATE VIEW TDEFOSTORE AS
  select  to_char(a.CODE)  as Store, to_char(a.name) as Storename ,to_char(b.code) as buyerid,
(select to_char(t.city1) from (select b.code,a.code as City1 from c_City a,  c_store  b where b.c_City_id=a.id)t
 where t.code= a.code) as city,
(select to_char(t.Province1) from (select b.code,a.code as Province1 from C_PROVINCE a, c_store  b where b.C_PROVINCE_id=a.id)t
where t.code= a.code) as Province,
(select to_char(t.AREA1) from (select b.code,a.code as AREA1 from C_AREA a, c_store  b where b.C_AREA_id=a.id)t
 where t.code= a.code) as AREA, TRUNC(0.00,2) as Targetfamount, 0 as Targetqty,'' as Empid,'' as Uporigstore
from c_store a,C_CUSTOMER b
where a.c_customer_id=b.id  and  a.ISSTOP='N' and b.code is not null and a.C_CUSTOMER_ID=b.id  and b.isstop='N'
      and a.isactive='Y' and  b.isactive='Y' and a.iforderstore='Y'
/

