CREATE VIEW V_STORAGE_SUM AS
  select max(id) id,ad_client_id, m_warehouse_id, m_product_id , sum(qtyonhand) qtyonhand, sum(qtyreserved) qtyreserved,
sum(qtyordered) qtyordered,
 sum(qtyonhand)+sum(qtyordered)-sum(qtyreserved) qtyavailable from m_storage group by ad_client_id, m_warehouse_id, m_product_id


/

