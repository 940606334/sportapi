CREATE VIEW V_WEBPOS_LOG AS
  SELECT A.ID, A.AD_CLIENT_ID, A.AD_ORG_ID, A.C_STORE_ID, A.UP_TIMES, A.OWNERID,
       TO_NUMBER(TO_CHAR(A.CREATIONDATE,'YYYYMMDD')) AS DATELOG, a.creationdate,
       a.iscreclear, a.isclear, a.modifierid, a.modifieddate, a.isactive,a.plan_num
  FROM WEBPOS_LOG A
/

