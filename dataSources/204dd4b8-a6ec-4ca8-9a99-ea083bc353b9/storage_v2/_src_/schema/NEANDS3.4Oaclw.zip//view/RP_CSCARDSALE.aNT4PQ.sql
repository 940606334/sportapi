CREATE VIEW RP_CSCARDSALE AS
  SELECT a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,
       a.C_CONSUMECARD_ID as cardno,b.c_store_id as c_store_id,
       b.c_client_consumecard_id as c_client_consumecard_id,a.amt as amt,a.parvalue as parvalue
FROM   C_CSCARD_SALEITEM a,C_CSCARD_SALE b
where a.c_cscard_sale_id=b.id
and b.status =2
/

