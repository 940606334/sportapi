CREATE VIEW RP_CUSINVCCHECK_QSN AS
  select h."ID",h."AD_CLIENT_ID",h."AD_ORG_ID",h."MODIFIEDDATE",h."DOCNO",h."DOCTYPE",h."BILLDATE",h."INVOICENO",
h."C_CUSTOMER_ID",h."EMPORIUM",h."DESCRIPTION",
h."TOT_AMT_ACTUAL",LAG("TOTAL",1,NULL)
  OVER (partition by c_customer_id,emporium
        ORDER BY billdate,MODIFIEDDATE) last_hire,
h."COLLECT_AMT",h."INVOICE_AMT",h."TOTAL"
from
(select k.*,

SUM(k.tot_amt_actual)
    OVER (partition by c_customer_id,emporium
          ORDER BY billdate,MODIFIEDDATE
          ROWS 10000000 PRECEDING) as "TOTAL"

from (select
       g.id,g.ad_client_id,g.ad_org_id,
       g.docno,
       g.doctype,
       g.billdate,
       null as invoiceno,
       g.c_customer_id,
       g.emporium,
       g.description,
       g.status,
       g.tot_amt_actual,
       --g.c_feetype_id,
       g.tot_amt_actual as collect_amt,
       0 as invoice_amt,
       g.modifieddate

     from  b_receive g, c_feetype w
     where g.c_feetype_id = w.id
     and w.iscash = 'N'
     and g.status =2

     union
     select
       t.id,t.ad_client_id,t.ad_org_id,
       t.docno,
       t.doctype,
       t.billdate,
       t.invoiceno,
       t.c_customer_id,
       t.emporium,
       t.description,
       t.status,
       -t.tot_amt_actual as tot_amt_actual,
       --t.c_feetype_id,
       0 as collect_amt,
       t.tot_amt_actual as invoice_amt,
       t.modifieddate
     from  b_cusinvoice t where t.status =2 )k
where exists (select 1 from dual where k.c_customer_id=c_customer_id and k.emporium=emporium)) h
order by  billdate,modifieddate
/

