CREATE VIEW M_IN_PRO_ITEM AS
  select max(ID||ascii('H')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_SALE_ID||ascii('H') as m_in_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout,sum(qtyin) as qtyin
from M_SALEITEM
where status=2 and out_status = 2
group by ad_client_id,ad_org_id,M_SALE_ID||ascii('H'),m_product_id
union all
select max(ID||ascii('I')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_RET_SALE_ID||ascii('I') as m_in_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout,sum(qtyin) as qtyin
from M_RET_SALEITEM
where status=2 and out_status = 2
group by ad_client_id,ad_org_id,M_RET_SALE_ID||ascii('I'),m_product_id
union all
select max(ID||ascii('J')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_TRANSFER_ID||ascii('J') as m_in_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout,sum(qtyin) as qtyin
from M_TRANSFERITEM
where status=2 and out_status = 2
group by ad_client_id,ad_org_id,M_TRANSFER_ID||ascii('J'),m_product_id
union all
select max(ID||ascii('K')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_SALE_ID||ascii('K') as m_in_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout,sum(qtyin) as qtyin
from M_SALEITEM
where status=2 and out_status = 2
group by ad_client_id,ad_org_id,M_SALE_ID||ascii('K'),m_product_id
union all
select max(ID||ascii('L')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_PURCHASE_ID||ascii('L') as m_in_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qty) as qtyout,sum(qtyin) as qtyin
from M_PURCHASEITEM
where status=2
group by ad_client_id,ad_org_id,M_PURCHASE_ID||ascii('L'),m_product_id
/

