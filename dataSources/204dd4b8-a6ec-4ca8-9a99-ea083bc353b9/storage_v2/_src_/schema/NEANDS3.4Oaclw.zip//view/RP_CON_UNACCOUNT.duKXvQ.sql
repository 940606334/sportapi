CREATE VIEW RP_CON_UNACCOUNT AS
  select ID, AD_CLIENT_ID, AD_ORG_ID, ISACTIVE, OWNERID, MODIFIERID, CREATIONDATE,
       MODIFIEDDATE, C_CUSTOMER_ID, M_PRODUCT_ID, M_PRODUCTALIAS_ID,
       sum(QTY_UNACCOUNT) QTY_UNACCOUNT, M_ATTRIBUTESETINSTANCE_ID
from (select a.id, a.ad_client_id, a.ad_org_id, a.isactive, a.ownerid,
              a.modifierid, a.creationdate, a.modifieddate,
              a.c_customer_id c_customer_id, b.m_product_id,
              b.m_productalias_id, sum(b.qtyout) QTY_UNACCOUNT,
              b.m_attributesetinstance_id
       from m_transfer a, m_transferitem b
       where a.id = b.m_transfer_id and a.status = 2 and a.out_status = 2 and
             a.isactive = 'Y' and a.transfertype = 'OUT'
       group by a.id, a.ad_client_id, a.ad_org_id, a.isactive, a.ownerid,
                a.modifierid, a.creationdate, a.modifieddate, a.c_customer_id,
                b.m_product_id, b.m_productalias_id, b.m_attributesetinstance_id
       union all
       select t.id, t.ad_client_id, t.ad_org_id, t.isactive, t.ownerid,
              t.modifierid, t.creationdate, t.modifieddate,
              t.C_CUSTOMERUP_ID c_customer_id, t1.m_product_id,
              t1.m_productalias_id, -sum(t1.qty_account) QTY_UNACCOUNT,
              t1.m_attributesetinstance_id
       from M_CONTRAN_ACCOUNT t, M_CONTRAN_ACCOUNTITEM t1
       where t.id = t1.M_CONTRAN_ACCOUNT_id and t.status = 2 AND t.isactive = 'Y'
       group by t.id, t.ad_client_id, t.ad_org_id, t.isactive, t.ownerid,
                t.modifierid, t.creationdate, t.modifieddate, t.C_CUSTOMERUP_ID,
                t1.m_product_id, t1.m_productalias_id, t1.m_attributesetinstance_id
       union all
       select t.id, t.ad_client_id, t.ad_org_id, t.isactive, t.ownerid,
              t.modifierid, t.creationdate, t.modifieddate,
              t.c_customer_id c_customer_id, t1.m_product_id,
              t1.m_productalias_id,
              (case
                  when t.out_status = 1 and t.in_status = 1 then
                   -sum(nvl(t1.qty, 0))
                  when t.out_status = 2 and t.in_status = 1 then
                   -sum(nvl(t1.qtyout, 0))
                  when t.out_status = 2 and t.in_status = 2 then
                   -sum(nvl(t1.qtyin, 0))
              end) QTY_UNACCOUNT, t1.m_attributesetinstance_id
       from m_transfer t, m_transferitem t1
       where t.id = t1.m_transfer_id and t.status = 2 AND t.isactive = 'Y' and
             t.transfertype = 'IN'
       group by t.id, t.ad_client_id, t.ad_org_id, t.isactive, t.ownerid,
                t.modifierid, t.creationdate, t.modifieddate, t.c_customer_id,
                t1.m_product_id, t1.m_productalias_id, t1.m_attributesetinstance_id, t.out_status,
                t.in_status)
group by ID, AD_CLIENT_ID, AD_ORG_ID, ISACTIVE, OWNERID, MODIFIERID,
         CREATIONDATE, MODIFIEDDATE, C_CUSTOMER_ID, M_PRODUCT_ID,
         M_PRODUCTALIAS_ID, M_ATTRIBUTESETINSTANCE_ID
/

