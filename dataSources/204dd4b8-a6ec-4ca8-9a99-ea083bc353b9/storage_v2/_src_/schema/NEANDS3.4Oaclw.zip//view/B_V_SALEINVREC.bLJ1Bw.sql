CREATE VIEW B_V_SALEINVREC AS
  select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.creationdate,a.modifierid,a.modifieddate,a.isactive,
a.id as m_sale_id,a.c_customer_id,a.dateout,a.tot_amtout_actual,
g.id as B_CUSINVOICE_ID,g.billdate as INVOICEDATE,case when g.id is null then 0 else a.tot_amtout_actual end as INVOICEAMT,
h.id as B_RECEIVE_ID,h.billdate as RECEIVEDATE,case when h.id is null then 0 else a.tot_amtout_actual end as RECEIVEAMT
from M_SALE a,
(select b.id,b.billdate,b.tot_amt_actual,c.m_sale_id from B_CUSINVOICE b,B_CUSINVOICEITEM c where b.id=c.b_cusinvoice_id and b.status=2) g,
(select d.id,d.billdate,d.tot_amt_actual,e.b_cusinvoice_id from B_RECEIVE d,B_RECEIVEITEM e where d.id=e.b_receive_id and d.status=2) h
where a.out_status=2
and a.id=g.m_sale_id(+)
and g.id=h.b_cusinvoice_id(+)
/

