CREATE VIEW V_TDEFATTRIBDEF AS
  select t.id,t.name as AttribDefName,t.dimflag from m_dimdef t
/

