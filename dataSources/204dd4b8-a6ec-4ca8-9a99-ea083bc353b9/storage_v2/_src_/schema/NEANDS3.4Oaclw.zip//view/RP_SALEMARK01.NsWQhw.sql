CREATE VIEW RP_SALEMARK01 AS
  select c.C_CUSTOMER_ID,d.year,d.month,substr(min(c.changedate),1,6) as yearmonth,
nvl(d.tot_amt_mark,0) as tot_amt_mark,sum(c.AMTSALE) as amtsale,
decode(nvl(d.tot_amt_mark,0),0,0,sum(c.AMTSALE)/d.tot_amt_mark) as sale_rate
from (select a.c_customer_id,b.year,b.month,b.tot_amt_mark from c_cuspurmark a,c_cuspurmarkitem b
      where a.id = b.c_cuspurmark_id) d ,rp_sale002 c
where d.c_customer_id(+)  = c.C_CUSTOMER_ID
and d.month(+) =substr(substr(c.changedate,1,6),5,2)
and to_date(to_char(d.year(+)),'YYYY')  = to_date(to_char(substr(c.changedate,1,4)),'YYYY')
group by c.C_CUSTOMER_ID,d.year,d.month,d.tot_amt_mark
with read only
/

