CREATE VIEW RP_B_PO002 AS
  select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,
a.BILLDATE,a.DOCNO,a.SALESREP_Id,a.C_STORE_ID,a.C_SUPPLIER_ID,a.DESCRIPTION,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,b.PRICEACTUAL,b.QTY,b.TOT_AMT_ACTUAL,b.m_productalias_id as m_product_alias_id,b.confirmdate,
z.PRECOST as PRECOST,b.QTY*z.PRECOST as AMT_PRECOST,a.id as b_po_id,b.tot_amt_list,b.qtymoveout,b.qtymovein
from B_PO a,B_POITEM b ,m_product z
where a.ID=b.B_PO_ID
and a.STATUS=2
and b.m_product_id = z.id
/

