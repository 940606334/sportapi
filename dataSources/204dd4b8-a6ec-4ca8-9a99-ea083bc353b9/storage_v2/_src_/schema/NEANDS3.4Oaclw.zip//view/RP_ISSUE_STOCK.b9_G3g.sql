CREATE VIEW RP_ISSUE_STOCK AS
  select max(b.id) as id,a.m_issue_task_id,b.m_product_id,b.m_attributesetinstance_id,b.m_productalias_id,sum(b.boxqty*a.boxqty) as qty,
(select t.qty-t.qtypreout
from fa_storage t
where t.m_product_id=b.m_product_id
and t.m_attributesetinstance_id=b.m_attributesetinstance_id
and t.c_store_id=c.c_store_id) as storeqty
from m_issue_taskitem a,b_so_matchsizeitem b,m_issue_task c
where a.b_so_matchsize_id=b.b_so_matchsize_id
and a.m_issue_task_id=c.id
and a.boxqty>=1
and c.status=1
and c.isactive='Y'
group by a.m_issue_task_id,c.c_store_id,b.m_product_id,b.m_attributesetinstance_id ,b.m_productalias_id
WITH READ ONLY
/

