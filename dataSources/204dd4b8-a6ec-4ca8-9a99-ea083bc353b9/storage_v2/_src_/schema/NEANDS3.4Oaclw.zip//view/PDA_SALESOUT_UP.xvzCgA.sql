CREATE VIEW PDA_SALESOUT_UP AS
  select a.docno,b.name,a.c_store_id,a.id from M_SALE a, C_STORE b where a.status='1' AND a.ISACTIVE='Y' and a.c_dest_id=b.id
/

