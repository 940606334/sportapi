CREATE VIEW V_FA_STORAGE_CAN AS
  select a.id,
       a.ad_client_id,
       a.ad_org_id,
       a.ownerid,
       a.modifierid,
       a.creationdate,
       a.modifieddate,
       a.isactive,
       a.c_store_id,
       a.m_product_id,
       a.m_attributesetinstance_id,
       a.m_productalias_id ,
       a.qty,
       a.qtypreout,
       a.qtyprein,
       nvl(a.qty, 0) - nvl(a.qtypreout, 0) + nvl(a.qtyprein, 0) as qtyvalid/*预计库存*/,
       case when nvl(a.qty, 0) >= nvl(a.qty, 0) - nvl(a.qtypreout, 0)-nvl(a.QTY_FREEZE,0)
       then nvl(a.qty, 0) - nvl(a.qtypreout, 0)-nvl(a.QTY_FREEZE,0)
       else nvl(a.qty, 0) end as qtycan/*可配*/,a.qty_freeze/*冻结量*/
  from fa_storage a
with read only
/

