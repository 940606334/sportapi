CREATE VIEW RP_SALEPRICE AS
  select b.id,b.ad_client_id,b.ad_org_id,b.m_bulkedit_saleprice_id,a.description,b.m_product_id,b.price_new,a.statuserid,a.statustime
from M_BULKEDIT_SALEPRICE a,M_BULKEDIT_SALEPRICEitem b
where a.id=b.m_bulkedit_saleprice_id
and a.status=2
WITH READ ONLY
/

