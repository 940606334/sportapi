CREATE VIEW AP_V_SERVICEPRI AS
  SELECT id, ad_client_id, ad_org_id, ownerid, modifierid, creationdate,
       modifieddate, isactive, docno, billdate, m_transfer_id, m_ret_sale_id,
       backdate, back_cusdate, to_backdate, c_store_id, c_customer_id,
       c_customerup_id, deladvice, description, tot_line, tot_qty, au_state,
       au_pi_id, pri_status AS status, priid AS statuserid,
       pritime AS statustime, confirm_status, confirmid, confirmtime, del_status,
       delid, deltime, close_status, closerid, closetime, pricon_status,
       priconid, pricontime
FROM ap_servicesapply
WHERE status = 2
/

