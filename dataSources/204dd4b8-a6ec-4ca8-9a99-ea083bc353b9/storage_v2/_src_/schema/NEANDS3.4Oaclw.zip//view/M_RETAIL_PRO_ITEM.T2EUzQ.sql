CREATE VIEW M_RETAIL_PRO_ITEM AS
  select max(id) as id,ad_client_id,ad_org_id,max(ownerid) as ownerid,
       max(modifierid) as modifierid,max(creationdate) as creationdate,
       max(modifieddate) as modifieddate,'y' as isactive,
       mp.m_retail_id,mp.m_product_id,sum(mp.qty) qty,avg(mp.pricelist) pricelist,
       avg(mp.priceactual) priceactual,avg(mp.discount) discount,sum(mp.tot_amt_actual) tot_amt_actual
from m_retailitem  mp
group by ad_client_id,ad_org_id,mp.m_retail_id,mp.m_product_id
with read only
/

