CREATE VIEW RP_PURCHASE_FORFEIT AS
  select b.id,a.ad_client_id,a.ad_org_id,a.m_purchase_quick_id,a.docno,
a.billdate,a.m_purchase_id,b.datein,a.description,
b.lateday,b.b_po_boxno_id,b.m_product_id,b.qty,b.priceactual,b.tot_amt_forfeit ,
b.reason
from M_PURCHASE_FORFEIT a, M_PURCHASE_FORFEITITEM b
where a.id = b.m_purchase_forfeit_id and a.status=2
/

