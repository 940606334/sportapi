CREATE VIEW RP_FAJQ AS
  SELECT MAX(a.id) AS id,
       37 AS ad_client_id,
       a.b_so_id,
       a.m_product_id,
       b.predateout,
       d.c_customer_id,
       d.c_store_id,
       CASE
         WHEN SYSDATE < to_date(b.predateout, 'yyyyMMdd') - 7 THEN
          1
         WHEN SYSDATE <= to_date(b.predateout, 'yyyyMMdd') THEN
          2
         WHEN SYSDATE > to_date(b.predateout, 'yyyyMMdd') THEN
          3
         ELSE
          4
       END sojq_status,
			 sum(decode(a.in_status,2,1,0)) as inqty,
       COUNT(a.id) AS boxqty,
       SUM(a.tot_qty) AS tot_qty,
       floor(SYSDATE - to_date(b.predateout, 'yyyyMMdd')) AS tot_day,
			 (select wm_concat(distinct f.billdate)
			 from b_poboxitem e,b_po f
			 where e.b_po_id=f.id
			 and e.b_so_id=a.b_so_id
			 and e.m_product_id=a.m_product_id
			 and f.status=2) as pobilldate
FROM b_po_boxno a, b_so_matchsize b, b_so d
WHERE a.b_so_matchsize_id = b.id
AND b.b_so_id = d.id
and a.status=2
AND a.out_status = 1
AND a.close_status = 1
GROUP BY a.b_so_id,
         a.m_product_id,
         b.predateout,
         d.c_customer_id,
         d.c_store_id
/

