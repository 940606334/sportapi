CREATE VIEW M_RETAIL_PERIODQUERY123 AS
  select max(id) id,max(ad_client_id) ad_client_id,max(ad_org_id) ad_org_id,billdate,c_store_id,salesrep_id,
       sum(qty) qty,sum(qty_sj) qty_sj,sum(retqty_sj) retqty_sj,sum(tot_amt_list) tot_amt_list,sum(tot_amt_actual) tot_amt_actual,
       sum(tot_retamt_actual) tot_retamt_actual,'Y' isactive--pricelist,priceactual
from(
select max(b.id) id,37 as ad_client_id,27 as ad_org_id,a.billdate,a.c_store_id,nvl(b.salesrep_id,a.salesrep_id) salesrep_id,
       count(b.id) qty,0 as qty_sj,0 as retqty_sj,0 as tot_amt_list,0 as tot_amt_actual,0 as tot_retamt_actual
from m_retail a,m_retailitem b
where a.id=b.m_retail_id
and   a.status=2
and   a.isactive='Y'
group by a.billdate,a.c_store_id,nvl(b.salesrep_id,a.salesrep_id)
union all
select max(b.id) id,37 as ad_client_id,27 as ad_org_id,a.billdate,a.c_store_id,nvl(b.salesrep_id,a.salesrep_id) salesrep_id,
      0 as qty,sum(b.qty) qty_sj,0 as retqty_sj,sum(b.tot_amt_list) tot_amt_list,sum(b.tot_amt_actual) as tot_amt_actual,0 as tot_retamt_actual
from m_retail a,m_retailitem b
where a.id=b.m_retail_id
and   a.status=2
and   a.isactive='Y'
and   b.type <>2
group by a.billdate,a.c_store_id,nvl(b.salesrep_id,a.salesrep_id)
union all
select max(b.id) id,37 as ad_client_id,27 as ad_org_id,a.billdate,a.c_store_id,nvl(b.salesrep_id,a.salesrep_id) salesrep_id,
      0 as qty,0 qty_sj,sum(b.qty) retqty_sj,0 as tot_amt_list,0 as tot_amt_actual,sum(b.tot_amt_actual) tot_retamt_actual
from m_retail a,m_retailitem b
where a.id=b.m_retail_id
and   a.status=2
and   a.isactive='Y'
and   b.type=2
group by a.billdate,a.c_store_id,nvl(b.salesrep_id,a.salesrep_id)
)group by billdate,c_store_id,salesrep_id
/

