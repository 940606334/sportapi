CREATE VIEW C_V_WEBPOSDISSTOREITEM AS
  select a.id,a.c_webposdis_id,C_STORE_ID
from C_WEBPOSDIS t,C_WEBPOSDISSTOREITEM a
where t.id=a.c_webposdis_id
and t.isactive='Y' and t.close_status=1
and t.STATUS = 2
and to_char(sysdate+1+nvl(KEEP_DAYS,0),'yyyymmdd')>=DATEBEGIN
and to_char(sysdate,'yyyymmdd')<=DATEEND/* edit by Selina 2017/2/24 15:19:00 */

