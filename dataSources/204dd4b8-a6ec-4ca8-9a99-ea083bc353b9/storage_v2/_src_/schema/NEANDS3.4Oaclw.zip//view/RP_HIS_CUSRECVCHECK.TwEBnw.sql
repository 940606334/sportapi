CREATE VIEW RP_HIS_CUSRECVCHECK AS
  select h."ID",h."AD_CLIENT_ID",h."AD_ORG_ID",h."MODIFIEDDATE",h."DOCNO",h."DOCTYPE",h."BILLDATE",h."C_CUSTOMER_ID",h."DESCRIPTION",
h."M_SALE_ID",h."M_RET_SALE_ID",h."TOT_AMT_ACTUAL",h."C_FEETYPE_ID",
--LAG("TOTAL",1,NULL)  OVER (partition by c_customer_id ORDER BY billdate,MODIFIEDDATE,DOCNO) last_hire,

SUM(h.tot_amt_actual)
  /*  OVER (partition by c_customer_id
        ORDER BY  billdate,MODIFIEDDATE,DOCNO
          ROWS 10000000 PRECEDING)*/ as "TOTAL",
SUM(h.collect_amt)
  /*  OVER (partition by c_customer_id
        ORDER BY  billdate,MODIFIEDDATE,DOCNO
          ROWS 10000000 PRECEDING)*/ as "TOTAL_COLLECT",
SUM(h.deduct_amt)
   /* OVER (partition by c_customer_id
        ORDER BY  billdate,MODIFIEDDATE,DOCNO
          ROWS 10000000 PRECEDING) */as "TOTAL_DEDUCT",
          SUM(h.amt_order)
   /* OVER (partition by c_customer_id
        ORDER BY billdate,MODIFIEDDATE,DOCNO
          ROWS 10000000 PRECEDING)*/ as "TOTAL_ORDER"

from (select
       g.id,g.ad_client_id,g.ad_org_id,
       g.docno,
       g.doctype,
      g.billdate,
       g.c_customer_id,
       g.description,
       g.status,
       null as m_sale_id,
       null as m_ret_sale_id,
       g.tot_amt_actual,
       g.c_feetype_id,
       g.tot_amt_actual as collect_amt,
       0 as deduct_amt,
       g.modifieddate,
       g.amt_order--,to_number(to_char(g.statustime,'YYYYMMDD')) AS billdate
     from  b_receive g where g.status =2

     UNION

     select
       t.id,t.ad_client_id,t.ad_org_id,
       t.docno,
       t.doctype,
       t.billdate,
       t.c_customer_id,
       t.description,
       t.status,
       t.m_sale_id,
       t.m_ret_sale_id,
       -t.tot_amt_actual as tot_amt_actual,
       t.c_feetype_id,
       0 as collect_amt,
       t.tot_amt_actual as deduct_amt,
       t.modifieddate,
       -t.amt_order AS amt_order--,to_number(to_char(t.statustime,'YYYYMMDD')) AS billdate
     from  b_receivable t where t.status =2 )h
     where exists (select 1 from dual where h.c_customer_id=c_customer_id)
     GROUP BY c_customer_id,billdate,modifieddate,h."ID",h."AD_CLIENT_ID",
     h."AD_ORG_ID",h."MODIFIEDDATE",h."DOCNO",h."DOCTYPE",h."BILLDATE",h."C_CUSTOMER_ID",h."DESCRIPTION",
     h."M_SALE_ID",h."M_RET_SALE_ID",h."TOT_AMT_ACTUAL",h."C_FEETYPE_ID"
/

