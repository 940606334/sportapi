CREATE VIEW EB_BOX_FASTNOITEM AS
  select max(t.id) as id,
       t.ad_client_id,
       t.ad_org_id,
       t.eb_box_id,
       t.boxno,
       max(t.ownerid) ownerid,
       t.fastno,
       t.isactive,
       max(t.modifierid) modifierid,
       max(t.modifieddate) modifieddate,
       max(t.creationdate) creationdate
  from eb_boxitem t
  group by  t.ad_client_id,
       t.ad_org_id,
       t.eb_box_id,
       t.boxno,
       t.fastno,
       t.isactive

/

