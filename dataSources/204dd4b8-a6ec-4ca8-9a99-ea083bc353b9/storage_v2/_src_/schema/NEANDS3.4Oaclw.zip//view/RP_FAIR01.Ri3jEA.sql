CREATE VIEW RP_FAIR01 AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,b.isactive,
a.b_fair_id,a.c_customer_id,a.docno,a.c_orig_id,a.c_dest_id,
b.m_product_id,b.m_attributesetinstance_id,b.qty,c.pricelist,b.priceactual,b.amt,c.pricelist * b.qty as amt_list,s.id as m_product_alias_id
from b_fo a, b_foitem b,m_product c,m_product_alias s
where a.id = b.b_fo_id
and b.m_product_id = c.id
and b.m_product_id=s.m_product_id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id
with read only
/

