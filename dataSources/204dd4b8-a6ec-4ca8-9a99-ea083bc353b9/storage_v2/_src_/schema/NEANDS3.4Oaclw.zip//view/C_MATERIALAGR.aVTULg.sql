CREATE VIEW C_MATERIALAGR AS
  SELECT t.id, t.ad_client_id, t.ad_org_id, t.docno, t.billdate, t.c_store_id,
       t.c_supplier_id, t.dateout, t.datein, t.description, t.out_description,
       t.in_description, t.agr_description, t.acc_description, t.tot_lines,
       t.tot_qty, t.tot_amt_list, t.tot_amt_actual, t.agr_status AS status,
       t.ownerid, t.modifierid, t.agrerid, t.creationdate, t.modifieddate,
       t.agrtime, t.isactive
FROM c_materialapply t
WHERE t.status = 2 AND t.out_status = 2 and t.in_status=2  --基于c_materialapply，已提交、已出货、已收货店仓装修材料申请单
/

