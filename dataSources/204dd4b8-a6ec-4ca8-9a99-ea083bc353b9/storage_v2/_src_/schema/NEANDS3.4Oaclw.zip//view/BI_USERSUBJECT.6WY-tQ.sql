CREATE VIEW BI_USERSUBJECT AS
  select id,bi_subject_id ,AD_CLIENT_ID,AD_ORG_ID,OWNERID ,MODIFIERID,CREATIONDATE ,MODIFIEDDATE,ISACTIVE ,url from (
select t1.id,t3.bi_subject_id,t1.AD_CLIENT_ID,t1.AD_ORG_ID, t1.OWNERID, t1.MODIFIERID, t1.CREATIONDATE,
       t1.MODIFIEDDATE, t1.ISACTIVE,
       '/BI-Report/BIReport.jsp?id='||t4.id as url,row_number()over( partition by t1.id,t3.bi_subject_id order by  t1.id,t3.bi_subject_id ) as a
  from users t1, bi_groupuser t2, bi_groupssubject t3, BI_SUBJECT t4
 where t1.id = t2.userid
   and t2.groupid=t3.groupid
   and t3.bi_subject_id=t4.id
    and t4.isactive = 'Y'
           and t3.ispermission='Y'
           and t1.isactive='Y'
           and t2.isactive='Y'
           and t3.isactive='Y'
           )
 where a<2
   order by id,bi_subject_id
/

