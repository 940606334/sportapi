CREATE VIEW V_TRANSFER AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.doctype,a.c_orig_id,a.c_dest_id,a.description,a.in_status,a.status,a.c_period_id,a.billdate,a.diffreason,a.out_status,a.dateout,a.datein,
a.c_customer_id,a.transfertype,a.statuserid,a.statustime,a.inerid,a.intime,a.outerid,a.outtime,
a.c_transfertype_id,a.box_status,a.b_so_id,
b.m_transfer_id,b.orderno,b.m_product_id,b.m_attributesetinstance_id,b.qtyout,b.qtyin,b.qtydiff,b.qty,
b.pricelist,b.tot_amtout_list,b.tot_amtin_list,b.tot_amtqty_list,b.m_productalias_id
from m_transfer a, m_transferitem b
where a.id = b.m_transfer_id
order by docno desc
/

