CREATE VIEW V_PO_BOX_MATRIX AS
  select max(a.id) as id,37 as ad_client_id,27 as ad_org_id,a.b_po_box_id,a.c_customer_id,a.m_product_id,a.m_color_id,a.m_matchsize_id,count(a.id) as boxqty,
       sum(decode(a.in_status,2,1,0)) as tot_in,sum(decode(a.out_status,2,1,0)) as tot_out
from b_po_boxno a
where a.isactive='Y'
group by a.b_po_box_id,a.c_customer_id,a.m_product_id,a.m_color_id,a.m_matchsize_id
WITH READ ONLY
/

