CREATE VIEW Y_IN_ITEM AS
  SELECT a.id || ascii('A') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.isactive, a.creationdate, a.ownerid, a.modifieddate, a.modifierid,
       a.y_purchase_id || ascii('A') AS y_in_id, a.y_material_id, a.y_color_id,
       a.fabric_width, a.fabric_weight, a.y_spec_id, a.qty, a.qtyin,
       c.NAME AS unitname, a.m_product_id, a.in_status AS status,
       a.y_materialalias_id, a.good_qty, a.defect_qty, a.fgood_qty,
       a.defectremark, a.deladvice, a.check_description
FROM y_purchase_item a, y_material b, y_unit c
WHERE a.y_material_id = b.id AND b.purchase_unit_id = c.id AND a.status = 2 --and in_status <> 2
UNION ALL
SELECT a.id || ascii('C') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.isactive, a.creationdate, a.ownerid, a.modifieddate, a.modifierid,
       a.y_drawret_id || ascii('C') AS y_in_id, a.y_material_id, a.y_color_id,
       a.fabric_width, a.fabric_weight, a.y_spec_id, a.qty, a.qtyin,
       c.NAME AS unitname, d.m_product_id AS m_product_id, a.in_status AS status,
       a.y_materialalias_id, 0 AS good_qty, 0 AS defect_qty, 0 AS fgood_qty,
       NULL AS defectremark, NULL AS deladvice, NULL AS check_description
FROM y_drawret_item a, y_material b, y_unit c, y_drawret d
WHERE a.y_material_id = b.id AND b.use_unit_id = c.id AND a.y_drawret_id = d.id AND
      a.status = 2 --and in_status <> 2
UNION ALL
SELECT a.id || ascii('D') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.isactive, a.creationdate, a.ownerid, a.modifieddate, a.modifierid,
       a.Y_TRANSFER_ID || ascii('D') AS y_in_id, a.y_material_id, a.y_color_id,
       a.fabric_width, a.fabric_weight, a.y_spec_id, QTYOUT AS QTY, a.qtyin,
       c.NAME AS unitname, null as m_product_id, a.in_status AS status,
       a.y_materialalias_id, 0 AS GOODQTY, 0 AS DEFECT_QTY, 0 as fgood_qty,
       null as defectremark, null as deladvice, null as check_description
FROM Y_TRANSFERITEM a, y_material b, y_unit c
WHERE a.y_material_id = b.id AND b.USE_UNIT_ID = c.id AND a.status = 2 --and in_status <> 2;
/

