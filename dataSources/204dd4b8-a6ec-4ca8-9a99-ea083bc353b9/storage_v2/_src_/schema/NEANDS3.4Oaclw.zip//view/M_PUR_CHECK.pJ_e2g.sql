CREATE VIEW M_PUR_CHECK AS
  SELECT id, ad_client_id, ad_org_id, ownerid, modifierid, creationdate,
       modifieddate, isactive, docno, doctype, billdate, salesrep_id, c_store_id,
       c_supplier_id, description, in_status, check_status AS status, au_state,
       au_pi_id, avg_discount, tot_lines, tot_qty, tot_amt_list, tot_amt_actual,
       tot_qtyin, tot_amtin_list, tot_amtin_actual, c_period_id, b_po_id,
       dateout, datein, checkerid AS statuserid, checktime AS statustime, inerid,
       intime, pcheckid, pchecktime, c_purchasetype_id, pck_status,
       tot_amtin_pcheck, diffreason, c_customer_id, amt_deduction, retover,
       operatoerid, oper_status, c_department_id, groupno, contract, contractno,
       isuf, tot_amt_precost, tot_amtin_precost, predatein, tot_amt_fee,
       exchangerate, c_cargotype_id, isbo2st, bo2st_remark, refno,
       c_store_location_id, printtimes, printintimes, c_cargointype_id,
       unite_status, m_purgroupno_id, exceedpoqty, pricemodify,
       tot_amtin_pchecktax, c_currency, realdate, c_currency_id, pursource,
       tax_dis, tot_qty_inved, c_tranway_jz_id, if_goodsarr, isadj, tot_amt_tax,
       in_au_state, in_au_pi_id, tot_qtyinved, tot_amtinved, isback,
       b_bwpuraccount_id, isagt, datewh, y_price_actual, y_tot_amt_actual,
       y_complete_id, y_inform_id, is_towms, tot_fgood_qty,tot_good_qty,tot_defect_qty
FROM m_purchase
WHERE status = 2
/

