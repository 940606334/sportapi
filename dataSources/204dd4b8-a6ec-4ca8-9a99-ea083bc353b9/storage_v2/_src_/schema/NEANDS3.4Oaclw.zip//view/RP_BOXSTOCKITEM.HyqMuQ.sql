CREATE VIEW RP_BOXSTOCKITEM AS
  select a.id,a.ad_client_id,a.ad_org_id,a.c_customer_id,a.m_product_id,b.c_supplier_id,a.tot_qty,a.m_color_id,a.predatein,a.confirmdate,a.in_status,a.id as b_po_boxno_id,b.c_store_id,a.m_matchsize_id
from b_po_boxno a,b_po b
where a.b_po_box_id=b.id
and a.status=2
and a.is_box=1
and a.dx_status=2
and a.out_status=1
and b.close_status=1
WITH READ ONLY
/

