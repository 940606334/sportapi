CREATE VIEW RP_FAIR02 AS
  select max(c.id) as id,max(b.ad_client_id) as ad_client_id,max(b.ad_org_id) as ad_org_id,
max(b.ownerid) as ownerid,max(b.modifierid) as modifierid,max(b.creationdate) as creationdate,
max(b.modifieddate) as modifieddate,b.isactive,b.b_fair_id,b.c_customer_id,
max(a.qty_target) as qty_target,max(a.amt_target) as amt_target,
sum(c.qty) as qty,sum(c.amt) as amt_actual
from B_FAIR_INDEX a, B_FO b, B_FOITEM c
where a.c_customer_id(+) = b.c_customer_id
and a.b_fair_id(+) = b.b_fair_id
and b.id = c.b_fo_id
group by b.b_fair_id,b.c_customer_id,b.isactive
with read only
/

