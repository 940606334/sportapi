CREATE VIEW TDEFOORDERNAME AS
  select id as orderid,to_char(name) as Ordername,1 as Isuse from B_FAIR
where to_char(sysdate, 'yyyymmdd')> = to_char(to_date(DATESTART,'yyyymmdd'),'YYYYMMDD')
and  to_char(sysdate, 'yyyymmdd') <= to_char(to_date(DATEEND,'yyyymmdd'),'YYYYMMDD')
/

