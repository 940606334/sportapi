CREATE VIEW B_V_RETAILDISSKUITEM AS
  select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,
a.B_RETAILDISSKU_ID,a.M_PRODUCT_ID,a.M_ATTRIBUTESETINSTANCE_ID,a.DISTYPE,a.CONTENT,a.ORDERNO
from B_RETAILDISSKU t,B_RETAILDISSKUITEM a
where t.id=a.b_retaildissku_id
and t.ISACTIVE ='Y'
and t.STATUS = 2 and t.close_status=1
and to_char(sysdate+1+nvl(KEEP_DAYS,0),'yyyymmdd')>=DATEBEGIN
and to_char(sysdate,'yyyymmdd')<=t.DATEEND/* edit by Selina 2017/2/24 15:16:08 */

