CREATE VIEW PDA_M_SALEITEM_UP AS
  select d.docno,c.no,b.value,a.qty,d.id,a.id item_id from m_saleitem a, m_product b,M_PRODUCT_ALIAS c,m_sale d
where a.m_product_id=b.id and a.m_productalias_id=c.id and a.m_sale_id=d.id
/

