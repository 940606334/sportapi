CREATE VIEW EB_V_OUT AS
  SELECT id AS id, ad_client_id, ad_org_id, isactive, modifierid, creationdate, modifieddate,
			 ownerid, DOCNO, DOCTYPE, BILLDATE, C_STORE_ID, C_CUSTOMER_ID, C_CUSTOMERUP_ID,
			 DESCRIPTION, TID, BUYER_MEMO, SELLER_MEMO, SHIPPING_TYPE, price, num, total_fee,
			 TYPE, post_fee, SELL_STATUS, OUT_STATUS AS STATUS, outtime AS statustime,
			 outerid AS statuserid, IN_STATUS, intime, inerid, BOX_STATUS, boxtime, boxerid,
			 SHIPPING_FEE, EB_ORDERSO_ID, MERGDOCNO, SPLIDOCNO, EB_LOGIS_ID, a.tstore,
			 a.seller_tel, a.seller_address, a.isvirtual, a.tvirtualid, a.fastno, a.SOURCE,
			 a.ACHECKED, a.ACHECKER, a.ACHECKDATE, a.ctype, a.RECEIVER_ADDRESS, a.RECEIVER_NAME,
			 a.BUYER_MESSAGE, a.BUYER_NICK, a.ALIPAY_NO, a.MODIFIEDER, a.CREATEDER, a.PAYMENT,
			 a.DISCOUNT_FEE, a.RECEIVED_PAYMENT, a.ADJUST_FEE, a.RECEIVER_MOBILE,
			 a.RECEIVER_PHONE, a.RECEIVER_ZIP, a.REAL_POINT_FEE, a.POINT_FEE, a.CONSIGN_TIME,
			 a.END_TIME, a.PAY_TIME, a.MODIFIED, a.CREATED, a.c_orig_id, a.VEERID, a.VE_STATUS,
			 a.VETIME, a.qtyfcan,a.dateoutin as dateout,a.seller_message,a.sec_send
	FROM EB_ORDERSO a
 WHERE status = 2
	 AND isactive = 'Y'
	 AND VE_STATUS = 2
	 AND (doctype = 'NOR' OR doctype = 'DIS')
/

