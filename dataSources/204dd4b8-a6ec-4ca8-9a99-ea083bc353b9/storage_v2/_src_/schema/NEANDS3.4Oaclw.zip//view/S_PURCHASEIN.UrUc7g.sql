CREATE VIEW S_PURCHASEIN AS
  select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.s_plan_id,a.isactive,
b.c_supplier_id,b.billdate,a.s_material_id,
  a.priceactual,a.qty,a.tot_amt,a.qty-a.qtyres as qtyin ,(a.qty-a.qtyres)*a.priceactual as tot_amtin_actual,a.qtyres as dqty,a.qty-a.qtyres as qtyout,
  a.tot_amt-(a.qty-a.qtyres)*a.priceactual as dprice,

  (select sum(t1.tot_amt_actual) as a_amt from B_pay t1,C_FEETYPE t2 where t1.status=2 and b.c_supplier_id=t1.c_supplier_id and t1.C_FEETYPE_ID=t2.id and t2.name='预收款' group by c_supplier_id) as yufujin,

  (select sum(t1.tot_amt_actual) as a_amt from B_pay t1,C_FEETYPE t2 where t1.status=2 and b.c_supplier_id=c_supplier_id and t1.C_FEETYPE_ID=t2.id and t2.name<>'预收款' group by c_supplier_id) as a_amt,
(select sum(tot_amt_actual) as a_amt from B_pay where status=2 and b.c_supplier_id=c_supplier_id) as totall
 ,
 nvl((select nvl(sum(tot_amt_actual),0) as a_amt from B_pay where status=2 and b.c_supplier_id=c_supplier_id),0)-
 nvl((select nvl(sum(TOT_AMT_ACTUAL ),0) as c_totamt from B_SUPINVOICE  where c_supplier_id=b.c_supplier_id group by c_supplier_id),0) as w_amt -- 未开票
 ,
 (select n.amt-nvl(m.amt,0) from
(select c_supplier_id ,sum(tot_actual) as amt from s_clearing where status=2 group by c_supplier_id) n left outer join
(select  c_supplier_id ,sum(tot_amt_actual) as amt from B_pay where status=2  group by c_supplier_id) m on
 n.c_supplier_id=m.c_supplier_id where n.c_supplier_id= b.c_supplier_id) as amt,

(select t1.d_count-nvl(t2.a_amt,0) from
(select c_supplier_id,sum(tot_amt) as d_count from s_plan where status=2 group by c_supplier_id) t1 left outer join
(select c_supplier_id,nvl(sum(tot_amt_actual),0) as a_amt from B_pay where status=2 group by c_supplier_id) t2
on t1.c_supplier_id=t2.c_supplier_id where t1.c_supplier_id=b.c_supplier_id) as totpay,
(select sum(TOT_AMT_ACTUAL ) as c_totamt from B_SUPINVOICE  where c_supplier_id=b.c_supplier_id group by c_supplier_id) as c_totamt,
(select sum(tot_amt) from s_plan  where status=2 and c_supplier_id=b.c_supplier_id  group by c_supplier_id) as c_amt,
(select sum(t1.p_price)
from s_clearingitem t1,s_clearing t2
where t1.s_clearing_id=t2.id and t2.status=2 and t1.s_material_id=a.s_material_id and t2.c_supplier_id=b.c_supplier_id
group by t2.c_supplier_id,t1.s_material_id) as p_price,
(select nvl(sum(b1.tot_amt_actual),0) as Chargeback
from  B_PAYABLE b1,c_feetype b2
where b1.c_feetype_id=b2.id and b1.status=2 and b2.ISFEEMIN='Y' and ISSYSTEM='N' and b1.c_supplier_id=b.c_supplier_id) as Chargeback,
(select t1.d_count-nvl(t2.a_amt,0) from
(select c_supplier_id,sum(tot_amt) as d_count from s_plan where status=2 group by c_supplier_id) t1 left outer join
(select c_supplier_id,nvl(sum(tot_amt_actual),0) as a_amt from B_pay where status=2 group by c_supplier_id) t2
on t1.c_supplier_id=t2.c_supplier_id where t1.c_supplier_id=b.c_supplier_id)-
(select nvl(sum(b1.tot_amt_actual),0) as Chargeback



from  B_PAYABLE b1,c_feetype b2
where b1.c_feetype_id=b2.id and b1.status=2 and b2.ISFEEMIN='Y' and ISSYSTEM='N' and b1.c_supplier_id=b.c_supplier_id) as
tot_qian_amt



  from s_planitem a,s_plan b where a.s_plan_id=b.id and
   b.status=2
/

