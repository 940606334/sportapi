CREATE VIEW AP_V_SERVICESPRERETITEM AS
  SELECT id, ad_client_id, ad_org_id, ownerid, modifierid, creationdate,
       modifieddate, isactive, ap_servicesapply_id AS ap_v_servicesdel_id,
       m_product_id, m_productalias_id, c_supplier_id, ap_units, delqty,
       ap_qualityreason_id, deladvice, ret_discount, repairdate, backdate,
       hr_v_employeescoat_id, factorydate, ap_liability_id, description,
       reworkatm, qty, del_status, m_attributesetinstance_id, to_ret,
       to_backdate, back_cusdate, ap_store, dateout, datein, end_ret,
       m_transfer_id, m_ret_sale_id, c_vip_id, image, ship_addr, dest_addr,
       fastamt,trate_status,c_dest_id
FROM ap_servicesapplydelitem
WHERE handleadvice = 'REW'
AND confirmadvice = 'REW'
/

