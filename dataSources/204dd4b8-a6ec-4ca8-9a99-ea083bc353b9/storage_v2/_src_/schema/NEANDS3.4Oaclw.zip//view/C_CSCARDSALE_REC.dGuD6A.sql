CREATE VIEW C_CSCARDSALE_REC AS
  SELECT ccs.id, ccs.ad_client_id, ccs.ad_org_id, ccs.ownerid, ccs.modifierid,
       ccs.creationdate, ccs.modifieddate, ccs.isactive, ccs.docno,ccs.billdate,
       ccs.c_store_id,ccs.c_client_consumecard_id,ccs.discount,ccs.tot_parvalue,
       ccs.tot_amt,ccs.tot_amt_receive,ccs.tot_amt_remain,ccs.discription,
       ccs.rec_status as status
FROM C_CSCARD_SALE ccs
where ccs.status = 2
/

