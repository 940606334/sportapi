CREATE VIEW RP_ISSUE_BOXNO AS
  SELECT a.id,
       B_BOXCREATE_ID AS m_issue_task_id,
			 a.b_so_id,
       a.boxno,
       a.c_customer_id,
       a.m_product_id,
       a.m_color_id,
       a.m_matchsize_id,
       a.test_status,
       a.testid,
       a.testtime,
       a.out_status,
       a.outid,
       a.outtime
FROM b_po_boxno a
WHERE  a.in_status=2
WITH READ ONLY
/

