CREATE VIEW M_SALE_PRO_ITEM AS
  select max(ID) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_SALE_ID as M_SALE_ID,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout,sum(qtyin) as qtyin,sum(QTYDIFF) as QTYDIFF,round(avg(pricelist)) as pricelist,round(avg(PRICEACTUAL),2) as PRICEACTUAL,
round(avg(DISCOUNT),2) as DISCOUNT,sum(TOT_AMT_LIST) as TOT_AMT_LIST ,sum(TOT_AMT_ACTUAL) as TOT_AMT_ACTUAL
,sum(TOT_AMTOUT_ACTUAL) as TOT_AMTOUT_ACTUAL,sum(TOT_AMTIN_ACTUAL) as TOT_AMTIN_ACTUAL,round(avg(HIS_PRICE),2) as HIS_PRICE
from M_SALEITEM
group by ad_client_id,ad_org_id,M_SALE_ID,m_product_id
/

