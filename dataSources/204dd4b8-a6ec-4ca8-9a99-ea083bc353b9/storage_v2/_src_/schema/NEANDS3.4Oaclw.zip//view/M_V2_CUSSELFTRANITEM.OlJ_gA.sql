CREATE VIEW M_V2_CUSSELFTRANITEM AS
  select ci.id,ci.ad_client_id,ci.ad_org_id,ci.m_cusselftran_id,
       ci.m_productalias_id,ci.m_product_id,ci.qty,ci.pricelist,
       ci.retprice,ci.discount,ci.tot_amt_list,ci.tot_amtret_actual,
       ci.m_attributesetinstance_id,ci.ownerid,ci.modifierid,ci.creationdate,
       ci.modifieddate,ci.isactive
from m_cusselftranitem ci
/

