CREATE VIEW V_IN AS
  select to_number(b.id || ascii('H')) as id,b.ad_client_id,b.ad_org_id,'M_SALEIN' as billtype,a.billdate,a.docno,a.doctype,a.c_customerup_id,a.c_customer_id,a.c_store_id,a.c_dest_id,a.description,a.in_status as status,
a.inerid,a.intime,a.dateout,a.datein,a.tot_lines,a.tot_qtyout,a.tot_qty,a.outerid,a.outtime,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.qtyout,b.qtyin,b.pricelist,b.priceactual,b.discount,b.tot_amt_list,b.tot_amt_actual,b.tot_amtout_list,b.tot_amtout_actual,b.tot_amtin_list,b.tot_amtin_actual,b.m_productalias_id,a.isactive,
null as c_supplier_id
from m_sale a,m_saleitem b
where a.id=b.m_sale_id
and a.out_status=2
union all
select to_number(b.id || ascii('K')) ,b.ad_client_id,b.ad_org_id,'M_V_CUSPURIN' as billtype,a.billdate,a.docno,a.doctype,a.c_customerup_id,a.c_customer_id,a.c_store_id,a.c_dest_id,a.description,a.in_status as status,
a.inerid,a.intime,a.dateout,a.datein,a.tot_lines,a.tot_qtyout,a.tot_qty,a.outerid,a.outtime,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.qtyout,b.qtyin,b.pricelist,b.priceactual,b.discount,b.tot_amt_list,b.tot_amt_actual,b.tot_amtout_list,b.tot_amtout_actual,b.tot_amtin_list,b.tot_amtin_actual,b.m_productalias_id,a.isactive,
null as c_supplier_id
from m_sale a,m_saleitem b
where a.id=b.m_sale_id
and a.out_status=2
union all
select to_number(b.id || ascii('J')) ,b.ad_client_id,b.ad_org_id,'M_TRANSFERIN' as billtype,a.billdate,a.docno,a.doctype,a.c_customer_id,a.c_customer_id,a.c_orig_id,a.c_dest_id,a.description,a.in_status,a.inerid,a.intime,a.dateout,a.datein,a.tot_lines,a.tot_qtyout,a.tot_qty,a.outerid,a.outtime,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.qtyout,b.qtyin,b.pricelist,b.pricelist,1,b.tot_amtqty_list,b.tot_amtout_list,b.tot_amtout_list,b.tot_amtin_list,b.tot_amtin_list,b.tot_amtin_list,b.m_productalias_id,a.isactive,
null as c_supplier_id
from m_transfer a,m_transferitem b
where a.id=b.m_transfer_id
and a.out_status=2
union all
select to_number(a.id || ascii('I')) as id,b.ad_client_id,b.ad_org_id,'M_RET_SALEIN' as billtype,a.billdate,a.docno,a.doctype,a.c_customerup_id,a.c_customer_id,a.c_orig_id,a.c_store_id,a.description,a.in_status as status,
a.inerid,a.intime,a.dateout,a.datein,a.tot_lines,a.tot_qtyout,a.tot_qty,a.outerid,a.outtime,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.qtyout,b.qtyin,b.pricelist,b.priceactual,b.discount,b.tot_amt_list,b.tot_amt_actual,b.tot_amtout_list,b.tot_amtout_actual,b.tot_amtin_list,b.tot_amtin_actual,b.m_productalias_id,a.isactive,
null as c_supplier_id
from m_ret_sale a,m_ret_saleitem b
where a.id=b.m_ret_sale_id
and a.out_status=2
union all
select to_number(a.id || ascii('L')) as id,b.ad_client_id,b.ad_org_id,'M_PURCHASEIN' as billtype,a.billdate,a.docno,a.doctype,a.c_customer_id as c_customerup_id,a.c_customer_id,null as c_orig_id,a.c_store_id,a.description,a.in_status as status,
a.inerid,a.intime,a.dateout,a.datein,a.tot_lines,a.tot_qty as tot_qtyout,a.tot_qty,a.statuserid as outerid,a.statustime as outtime,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.qty as qtyout,b.qtyin,b.pricelist,b.priceactual,b.discount,b.tot_amt_list,b.tot_amt_actual,b.tot_amtin_list as tot_amtout_list,b.tot_amtin_actual as tot_amtout_actual,b.tot_amtin_list,b.tot_amtin_actual,b.m_productalias_id,a.isactive,
a.c_supplier_id
from m_purchase a,m_purchaseitem b
where a.id=b.m_purchase_id
and a.status=2
/

