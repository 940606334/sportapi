CREATE VIEW Y_V_FA_STORAGE AS
  select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,
a.y_warehouse_id,a.y_material_id,a.y_color_id,a.fabric_width,a.fabric_weight,a.y_spec_id,a.unit_id,a.m_product_id,
a.qty,a.qtypreout,a.qtyprein,(nvl(a.qty, 0) - nvl(a.qtypreout, 0) + nvl(a.qtyprein, 0)) as qtyvalid,Y_MATERIALALIAS_ID
from y_fa_storage a
with read only
/

