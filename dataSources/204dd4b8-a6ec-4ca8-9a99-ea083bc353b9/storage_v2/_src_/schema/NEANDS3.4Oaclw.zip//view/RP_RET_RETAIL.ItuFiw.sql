CREATE VIEW RP_RET_RETAIL AS
  SELECT eri.id, eri.ad_client_id, eri.ad_org_id, eri.ownerid, eri.modifierid,
			 eri.creationdate, eri.modifieddate, eri.isactive, eo.dateoutin, eo.c_store_id,
			 eri.m_product_id, eo.ctype, mp.pricelist price,
			 DECODE(NVL(eri.qty, 0), 0, 0, (eri.payment / eri.qty) * eri.qtyin) AS payment,
			 eri.qtyin, mp.pricelist * eri.qtyin tot_amt_retsale, pa.id AS m_productalias_id,
			 0 AS ACTUAL_ATM_SALES
	FROM eb_orderso eo, eb_ordersoitem eri, m_product mp, m_product_alias pa
 WHERE eo.id = eri.eb_orderso_id
	 AND eri.m_product_id = mp.id
	 AND eo.doctype = 'RET'
	 AND eo.status = 2
	 AND mp.id = pa.m_product_id
	 AND eri.m_attributesetinstance_id = pa.m_attributesetinstance_id
	 AND eo.in_status = 2
UNION ALL
SELECT eri.id, eri.ad_client_id, eri.ad_org_id, eri.ownerid, eri.modifierid,
			 eri.creationdate, eri.modifieddate, eri.isactive, eo.dateoutin, eo.c_store_id,
			 eri.m_product_id, eo.ctype, mp.pricelist price, 0 AS payment, 0 AS qtyin,
			 0 AS tot_amt_retsale, pa.id AS m_productalias_id,
			 DECODE(NVL(eri.qty, 0), 0, 0, (eri.payment / eri.qty) * eri.qtyout) AS ACTUAL_ATM_SALES
	FROM eb_orderso eo, eb_ordersoitem eri, m_product mp, m_product_alias pa
 WHERE eo.id = eri.eb_orderso_id
	 AND eri.m_product_id = mp.id
	 AND mp.id = pa.m_product_id
	 AND eri.m_attributesetinstance_id = pa.m_attributesetinstance_id
	 AND eo.doctype <> 'RET'
	 AND eo.status = 2
	 AND eo.out_status = 2
/

