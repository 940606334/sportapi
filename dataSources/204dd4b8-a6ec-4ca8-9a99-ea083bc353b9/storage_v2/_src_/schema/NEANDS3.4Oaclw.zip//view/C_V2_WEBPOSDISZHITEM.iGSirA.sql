CREATE VIEW C_V2_WEBPOSDISZHITEM AS
  select a.id,a.c_webposdis_id,GET_FITLER_SQL(a.product_filter) as product_filter,a.comparetype,a.qty,a.relationtype,a.comparetypeamt,a.tot_amt_actual
from C_WEBPOSDIS t,C_WEBPOSDISZHITEM a
where t.id=a.c_webposdis_id
and t.isactive='Y' and t.close_status=1
and t.STATUS = 2
and to_char(sysdate+1+nvl(KEEP_DAYS,0),'yyyymmdd')>=DATEBEGIN
and to_char(sysdate,'yyyymmdd')<=DATEEND/* edit by Selina 2017/2/24 15:16:44 */

