CREATE VIEW RP_SALERETAIL001VIEW AS
  SELECT a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid, a.creationdate,
       a.modifieddate, a.isactive, a.c_customer_id, a.c_dest_id as c_store_id, a.billdate,
       a.docno, b.m_product_id,b.m_productalias_id as m_productalias_id , b.m_attributesetinstance_id, c.pricelist as pricelist,
       b.qty as saleqty, 0 as saleoutqty, 0 as saleoutamount,
       0 as saleoutfamount,
       0 as saledis,
       0 as saledisamount, 0 as salretqty,
       0 as salretinqty, 0 as salretinamount, 0 as salretinfamount, 0 as salretdis,
       0 as salretdisamount, 0 as retailqty, 0 as retailamount, 0 as retailfamount,
       0 as retaildis, 0 as retaildisamount,0 as realqty,
       0 as realfamount,
       0 as cost
FROM M_SALE A, M_SALEITEM B, m_Product c
WHERE a.id = b.m_sale_id AND b.m_product_id = c.id
      AND a.status = 2
      and a.out_status=1--只计算数量只提交未出库
union all
SELECT a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid, a.creationdate,
       a.modifieddate, a.isactive, a.c_customer_id, a.c_dest_id as c_store_id, a.dateout,
       a.docno, b.m_product_id,b.m_productalias_id , b.m_attributesetinstance_id, c.pricelist as pricelist,
       b.qty as saleqty, 0 as saleoutqty, 0 as saleoutamount,
       0 as saleoutfamount,
       0 as saledis,
       0 as saledisamount, 0 as salretqty,
       0 as salretinqty, 0 as salretinamount, 0 as salretinfamount, 0 as salretdis,
       0 as salretdisamount, 0 as retailqty, 0 as retailamount, 0 as retailfamount,
       0 as retaildis, 0 as retaildisamount,0 as realqty,
       0 as realfamount,
       0 as cost
FROM M_SALE A, M_SALEITEM B, m_Product c
WHERE a.id = b.m_sale_id AND b.m_product_id = c.id
	    AND a.status = 2
      and a.out_status=2--只计算数量提交出库
union all
SELECT a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid, a.creationdate,
			 a.modifieddate, a.isactive, a.c_customer_id, a.c_dest_id as c_store_id, a.dateout,
			 a.docno, b.m_product_id,b.m_productalias_id , b.m_attributesetinstance_id, c.pricelist as pricelist,
			 0 as saleqty, b.qtyout as saleoutqty, c.pricelist * b.qtyout as saleoutamount,
			 b.tot_amtout_actual as saleoutfamount,
			 decode(c.pricelist * b.qtyout, 0, 0, b.tot_amtout_actual / (c.pricelist * b.qtyout)) as saledis,
				--销售折扣
			 (c.pricelist * b.qtyout - b.tot_amtout_actual) as saledisamount, 0 as salretqty,
			 0 as salretinqty, 0 as salretinamount, 0 as salretinfamount, 0 as salretdis,
			 0 as salretdisamount, 0 as retailqty, 0 as retailamount, 0 as retailfamount,
			 0 as retaildis, 0 as retaildisamount, b.qtyout - 0 + 0 as realqty,
			 (b.tot_amtout_actual-0+0) as realfamount,
			 percost_analyse(substr(a.dateout, 1, 6), a.c_dest_id, b.m_product_id)*nvl(b.qtyout, 0) as cost
FROM M_SALE A, M_SALEITEM B, m_Product c
 WHERE a.id = b.m_sale_id AND b.m_product_id = c.id
	     AND a.status = 2
	     AND a.out_status = 2
union all
SELECT a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid, a.creationdate,
			 a.modifieddate, a.isactive, a.c_customer_id, a.c_orig_id as c_store_id, a.billdate,
			 a.docno, b.m_product_id,b.m_productalias_id as m_productalias_id, b.m_attributesetinstance_id,
			 c.pricelist as pricelist, 0 as saleqty, 0 as saleoutqty, 0 as saleoutamount,
			 0 as saleoutfamount, 0 as saledis, 0 as saledisamount, b.qty as salretqty,
			 0 as salretinqty,0 as salretinamount,
			 0 as salretinfamount,
			 0 as salretdis,--退货折扣
		   0 as salretdisamount, 0 as retailqty,
			 0 as retailamount, 0 as retailfamount, 0 as retaildis, 0 as retaildisamount,
			 0 as realqty, 0 as realfamount,
			 0 as cost
FROM m_ret_sale a, m_ret_saleitem b, m_product c
WHERE a.id = b.m_ret_sale_id AND b.m_product_id = c.id
	    AND a.status = 2
      and a.in_status=1--计算退货数量只提交未入库
union all
select a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid, a.creationdate,
			 a.modifieddate, a.isactive, a.c_customer_id, a.c_orig_id as c_store_id, a.datein,
			 a.docno, b.m_product_id, b.m_productalias_id as m_productalias_id, b.m_attributesetinstance_id,
			 c.pricelist as pricelist, 0 as saleqty, 0 as saleoutqty, 0 as saleoutamount,
			 0 as saleoutfamount, 0 as saledis, 0 as saledisamount, b.qty as salretqty,
			 0 as salretinqty,0 as salretinamount,
			 0 as salretinfamount,
			 0 as salretdis,--退货折扣
		   0 as salretdisamount, 0 as retailqty,
			 0 as retailamount, 0 as retailfamount, 0 as retaildis, 0 as retaildisamount,
			 0 as realqty, 0 as realfamount,
			 0 as cost
FROM m_ret_sale a, m_ret_saleitem b, m_product c
WHERE a.id = b.m_ret_sale_id  AND b.m_product_id = c.id
	    AND a.status = 2
      and a.in_status=2 --只计算退货数量提交入库
union all
select a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid, a.creationdate,
			 a.modifieddate, a.isactive, a.c_customer_id, a.c_orig_id as c_store_id, a.datein,
			 a.docno, b.m_product_id, b.m_productalias_id as m_productalias_id, b.m_attributesetinstance_id,
			 c.pricelist as pricelist, 0 as saleqty, 0 as saleoutqty, 0 as saleoutamount,
			 0 as saleoutfamount, 0 as saledis, 0 as saledisamount, 0 as salretqty,
			 b.qtyin as salretinqty, b.qtyin * c.pricelist as salretinamount,
			 b.tot_amtin_actual as salretinfamount,
			 decode(b.qtyin * c.pricelist, 0, 0, b.tot_amtin_actual / (b.qtyin * c.pricelist)) as salretdis,
				--退货折扣
			 (b.qtyin * c.pricelist - b.tot_amtin_actual) as salretdisamount, 0 as retailqty,
			 0 as retailamount, 0 as retailfamount, 0 as retaildis, 0 as retaildisamount,
			 (0 - b.qtyin + 0) as realqty, (0 - b.qtyin *b.priceactual + 0) as realfamount,
			 percost_analyse(substr(a.datein, 1, 6), a.c_orig_id, b.m_product_id) *
				nvl(b.qtyout, 0) as cost
from m_ret_sale a, m_ret_saleitem b, m_product c
where a.id = b.m_ret_sale_id and b.m_product_id = c.id
	    and a.status = 2
	    and a.out_status = 2
	    and a.in_status = 2
union all
SELECT a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid, a.creationdate,
			 a.modifieddate, a.isactive, a.c_customer_id, a.c_store_id as c_store_id, a.billdate,
			 a.docno, b.m_product_id, b.m_productalias_id, b.m_attributesetinstance_id,
			 c.pricelist as pricelist, 0 as saleqty, 0 as saleoutqty, 0 as saleoutamount,
			 0 as saleoutfamount, 0 as saledis, 0 as saledisamount, 0 as salretqty,
			 0 as salretinqty, 0 as salretinamount, 0 as salretinfamount, 0 as salretdis,
			 0 as salretdisamount, b.qty as retailqty, b.tot_amt_list as retailamount,
			 b.tot_amt_actual as retailfamount,
			 decode(b.tot_amt_list, 0, 0, b.tot_amt_actual / b.tot_amt_list) as retaildis,--零售折扣
			 (b.tot_amt_list - b.tot_amt_actual) as retaildisamount, (0 - 0 + b.qty) as realqty,
			 (0 - 0 + b.tot_amt_actual) as realfamount,
			 percost_analyse(substr(a.billdate, 1, 6), a.c_store_id, b.m_product_id)*nvl(b.qty, 0) as cost
FROM m_retail a, m_retailitem b, m_product c
WHERE a.id = b.m_retail_id AND b.m_product_id = c.id AND a.status = 2
/

