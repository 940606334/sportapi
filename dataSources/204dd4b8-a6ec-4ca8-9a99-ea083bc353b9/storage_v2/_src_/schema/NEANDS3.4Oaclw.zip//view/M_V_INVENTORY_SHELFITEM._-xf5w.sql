CREATE VIEW M_V_INVENTORY_SHELFITEM AS
  select mis.id,mis.ad_client_id,mis.ad_org_id,mis.m_inventory_id,mis.m_product_id,
       mis.qty,mis.pricelist,mis.tot_amt_list,mis.m_attributesetinstance_id,
       mis.ownerid,mis.modifierid,mis.creationdate,mis.modifieddate,mis.isactive,
       mis.isupdate,mis.shelfno,mis.m_productalias_id
from m_inventory_shelfitem mis
/

