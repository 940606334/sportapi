CREATE VIEW M_ADDRALLOT_DISTYPEITEM AS
  SELECT MAX(t.id) id, t.ad_client_id, t.ad_org_id,
       t.m_addrallot_id, t.b_so_id, t.c_dest_id,
       MAX(b.doctype) DOCTYPE, MAX(t.c_saledistype_id) c_saledistype_id,
       MAX(t.ownerid) ownerid, MAX(t.modifierid) modifierid,
       SYSDATE creationdate, SYSDATE modifieddate, 'Y' isactive
FROM M_ADDRALLOTITEM t, b_so b
WHERE t.flag = 'Y' AND t.b_so_id = b.id
GROUP BY t.ad_client_id, t.ad_org_id,t.m_addrallot_id, t.b_so_id, t.c_dest_id
/

