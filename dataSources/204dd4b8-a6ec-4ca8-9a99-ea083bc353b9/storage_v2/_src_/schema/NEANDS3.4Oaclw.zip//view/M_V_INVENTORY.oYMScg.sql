CREATE VIEW M_V_INVENTORY AS
  select mv.id,mv.ad_client_id,mv.ad_org_id,mv.ownerid,mv.modifierid,mv.creationdate,mv.modifieddate,mv.isactive,
       mv.billdate,mv.docno,mv.doctype,mv.c_store_id,mv.description,mv.status,mv.au_state,mv.au_pi_id,
       mv.tot_lines,mv.tot_amtbook_list,mv.tot_amtcount_list,
       mv.c_period_id,mv.diffreason,mv.c_customer_id,mv.dateout,mv.datein,mv.statuserid,
       mv.statustime,mv.inerid,mv.intime,mv.outerid,mv.outtime,mv.product_filter,mv.c_store_filter,
       mv.isunite,mv.isuf,mv.tot_amtdiff_precost,mv.tot_amtdiff_list1,mv.tot_qtydiff1
from m_inventory mv
/

