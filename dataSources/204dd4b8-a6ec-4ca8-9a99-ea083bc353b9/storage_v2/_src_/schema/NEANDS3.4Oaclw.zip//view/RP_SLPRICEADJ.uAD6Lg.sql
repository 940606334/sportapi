CREATE VIEW RP_SLPRICEADJ AS
  select
rownum as id,
37 as ad_client_id,
27 as ad_org_id,
893 as ownerid,
893 as modifierid,
sysdate as creationdate,
sysdate as modifieddate,
'Y' as isactive,
b.b_slpriceadj_id,a.discount_type,C_SALEDISTYPE_ID,b.c_customer_id,c.m_product_id,c.NOWPRICE,a.statustime
from B_SLPRICEADJ a,B_SLPRICEADJCUSITEM b,B_SLPRICEADJPDTITEM c
where a.status=2
and a.id=b.b_slpriceadj_id
and a.id=c.b_slpriceadj_id
WITH READ ONLY
/

