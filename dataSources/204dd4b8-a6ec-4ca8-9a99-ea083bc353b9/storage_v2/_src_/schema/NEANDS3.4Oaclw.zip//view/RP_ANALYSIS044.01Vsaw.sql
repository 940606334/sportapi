CREATE VIEW RP_ANALYSIS044 AS
  select a.id ,a.AD_CLIENT_ID,a.AD_ORG_ID, a.OWNERID,a.MODIFIERID,
a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,to_date(a.datein,'yyyymmdd')as BILLDATE,a.DOCNO,a.C_CUSTOMER_ID,
a.c_store_Id,b.M_PRODUCT_ID,s.id as m_product_alias_id,
b.M_ATTRIBUTESETINSTANCE_ID,b.QTYIN,0 as QTYOUT,0 as  QTYOUTsale ,0 as qtyoutret,0 as QTYCOUNT ,0 as OTHERQTY,0 as qtyretail
from  M_PURCHASE a, M_PURCHASEitem b,m_product_alias s
where a.ID=b.M_PURCHASE_ID
and b.m_product_id=s.m_product_id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id
and a.IN_STATUS  =2
union all
select a.id ,a.AD_CLIENT_ID,a.AD_ORG_ID, a.OWNERID,a.MODIFIERID,
a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,to_date(a.BILLDATE,'yyyymmdd')as BILLDATE,a.DOCNO,a.C_CUSTOMER_ID,
a.c_store_Id,b.M_PRODUCT_ID,s.id as m_product_alias_id,
b.M_ATTRIBUTESETINSTANCE_ID,0 as QTYIN, b.QTYOUT,0 as  QTYOUTsale ,0 as qtyoutret,0 as QTYCOUNT ,0 as OTHERQTY,0 as qtyretail
from   M_RET_PUR a,M_RET_PURitem b,m_product_alias s
where a.ID=b.M_RET_PUR_ID
and b.m_product_id=s.m_product_id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id
and a.OUT_STATUS=2
union all
select a.id ,a.AD_CLIENT_ID,a.AD_ORG_ID, a.OWNERID,a.MODIFIERID,
a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,to_date(a.dateout,'yyyymmdd')as BILLDATE,a.DOCNO,a.C_CUSTOMERUP_ID as C_CUSTOMER_ID,
a.c_store_Id,b.M_PRODUCT_ID,b.m_productalias_id m_product_alias_id,
b.M_ATTRIBUTESETINSTANCE_ID,0 as QTYIN, 0 as QTYOUT,b.QTYOUT as  QTYOUTsale ,0 as qtyoutret,0 as QTYCOUNT ,0 as OTHERQTY,0 as qtyretail
from  M_sale a, M_saleitem b
where a.ID=b.M_sale_ID
and a.OUT_STATUS=2
--order by a.dateout desc;
union all
select a.id ,a.AD_CLIENT_ID,a.AD_ORG_ID, a.OWNERID,a.MODIFIERID,
a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,to_date(a.dateout,'yyyymmdd')as BILLDATE,a.DOCNO,a.C_CUSTOMER_ID,
a.c_store_Id as C_dest_ID ,b.M_PRODUCT_ID,b.m_productalias_id as m_product_alias_id,
b.M_ATTRIBUTESETINSTANCE_ID,0 as QTYIN, 0 as QTYOUT,0  as  QTYOUTsale, b.qtyout as qtyoutret,0 as QTYCOUNT ,0 as OTHERQTY,0 as qtyretail
from  M_RET_SALE a, M_RET_SALEitem b
where a.ID=b.M_RET_SALE_ID
and a.OUT_STATUS=2
and a.in_status<>2

union all
select a.id ,a.AD_CLIENT_ID,a.AD_ORG_ID, a.OWNERID,a.MODIFIERID,
a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,to_date(a.BILLDATE,'yyyymmdd')as BILLDATE,a.DOCNO,a.C_CUSTOMER_ID,
a.c_store_Id ,b.M_PRODUCT_ID,b.m_productalias_id as m_product_alias_id,
b.M_ATTRIBUTESETINSTANCE_ID,0 as QTYIN, 0 as QTYOUT,0 as QTYOUTsale ,0 as qtyoutret, b.QTYCOUNT ,0 as OTHERQTY,0 as qtyretail
from  M_INVENTORY a, M_INVENTORYitem b
where a.ID=b.M_INVENTORY_ID
and a.STATUS =2
union all
select a.id ,a.AD_CLIENT_ID,a.AD_ORG_ID, a.OWNERID,a.MODIFIERID,
a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,to_date(a.BILLDATE,'yyyymmdd')as BILLDATE,a.DOCNO,a.C_CUSTOMER_ID,
a.c_store_Id,b.M_PRODUCT_ID,s.id as m_product_alias_id,
b.M_ATTRIBUTESETINSTANCE_ID,0 as QTYIN, 0 as QTYOUT,0 as QTYOUTsale ,0 as qtyoutret,0 as QTYCOUNT ,b.QTY  as OTHERQTY,0 as qtyretail
from  M_OTHER_INOUT a, M_OTHER_INOUTitem b,m_product_alias s
where a.ID=b.M_OTHER_INOUT_ID
and b.m_product_id=s.m_product_id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id
and a.STATUS =2
union all
select a.id ,a.ad_client_id,a.ad_org_id, a.ownerid,a.modifierid,
       a.creationdate,a.modifieddate,a.isactive,to_date(a.billdate,'yyyymmdd')as billdate,
       a.docno,a.c_customer_id,a.c_store_id,b.m_product_id,b.m_productalias_id as m_product_alias_id,
       b.m_attributesetinstance_id,0 as qtyin, 0 as qtyout,0 as qtyoutsale ,0 as qtyoutret,
       0 as qtycount ,0 as otherqty ,b.qty as qtyretail
from  m_retail a, m_retailitem b
where a.id=b.m_retail_id and a.status =2
with read only
/

