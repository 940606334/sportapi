CREATE VIEW V_M18_KDVOUCHER_MSALEWB AS
  select  d.code as storecode, e.code as customercode, a.dateout as billdate,sum(b.tot_amt_actual) as amt,
sum(b.qtyout*c.precost) as cost, max(e.c_cusattrib1_id) as c_cusattrib1_id, max(f.code) as companycode, g.attribcode as brand
from m_sale a, m_saleitem b, m_product c, c_store d, c_customer e, c_block f, m_dim g
where a.id=b.m_sale_id and b.m_product_id=c.id and a.c_dest_id=d.id and a.c_customer_id=e.id
and a.dateout is not null and d.c_block_id=f.id and c.m_dim1_id=g.id
group by a.dateout , d.code, e.code, g.attribcode
union all
select  d.code as storec, e.code as customerc, a.datein as billdate,  sum(b.tot_amt_actual) as amt,
sum(b.qtyin*c.precost) as cost, max(e.c_cusattrib1_id) as c_cusattrib1_id, max(f.code) as companycode, g.attribcode as brand
from m_ret_sale a, m_ret_saleitem b, m_product c, c_store d, c_customer e, c_block f, m_dim g
where a.id=b.m_ret_sale_id and b.m_product_id=c.id and a.c_orig_id=d.id and a.c_customer_id=e.id
and a.datein is not null and d.c_block_id=f.id and c.m_dim1_id=g.id
group by a.datein , d.code, e.code, g.attribcode
/

