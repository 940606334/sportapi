CREATE VIEW RP_RET_PREDICTION_OLD AS
  select max(id) as id,max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,
max(ownerid) as ownerid,max(modifierid) as modifierid,max(creationdate) as creationdate,
max(modifieddate) as modifieddate,max(isactive) as isactive,
cuscode,cusname,storecode,storename,
sum(saleamt) as saleamt,sum(salecost) as salecost,
sum(retamt) as retamt,sum(retcost) retcost,
--decode(sign(sum(saleamt)*0.1-sum(retamt)),-1,0,sum(saleamt)*0.1-sum(retamt)) as RET_AMT ,
--decode(sign(sum(salecost)*0.1-sum(retcost)),-1,0,sum(salecost)*0.1-sum(retcost)) as RET_COST
--sum(saleamt)*0.1-sum(retamt) as RET_AMT,
--sum(salecost)*0.1-sum(retcost) as RET_COST
case when sum(saleamt)*0.1-sum(retamt)>0 then sum(saleamt)*0.1-sum(retamt) else 0 end as RET_AMT,
case when sum(salecost)*0.1-sum(retcost)>0 then sum(salecost)*0.1-sum(retcost) else 0 end as RET_COST

from
(
select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,
f.id as cuscode,f.name as cusname,e.code as storecode,e.name as storename,
sum(b.tot_amtout_actual) as saleamt,sum(b.qtyout*c.precost) as salecost,0 as retamt,0 as retcost
from m_sale a, m_saleitem b, m_product c, c_saledistype d,c_store e,c_customer f,C_CUSATTRIBVALUE g
where a.id = b.m_sale_id
and a.out_status = 2
and a.c_saledistype_id = d.id(+)
and d.name = '现货非买断'
and b.m_product_id = c.id
and a.c_dest_id=e.id
and e.c_customer_id=f.id
and f.c_cusattrib1_id=g.id(+)---
and g.name='新加盟'---
group by a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,f.id ,f.name ,e.code ,e.name
union all
select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,
f.id as cuscode,f.name as cusname,e.code as storecode,e.name as storename,
0 as saleamt,0 as salecost,sum(b.tot_amtin_actual) as retamt,sum(b.qtyin*c.precost) as retcost
from m_ret_sale a, m_ret_saleitem b,m_product c, c_saledistype d,c_store e,c_customer f,C_CUSATTRIBVALUE g
where a.id = b.m_ret_sale_id
and a.in_status = 2
and a.c_saledistype_id = d.id(+)
and d.name = '现货非买断退货'
and b.m_product_id = c.id
and a.c_orig_id=e.id
and e.c_customer_id=f.id
and f.c_cusattrib1_id=g.Id(+) --
and g.Name='新加盟'   ------
group by a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,f.id ,f.name ,e.code ,e.name
)
group by cuscode,cusname,storecode,storename
order by cuscode,cusname,storecode,storename
--with read only
/

