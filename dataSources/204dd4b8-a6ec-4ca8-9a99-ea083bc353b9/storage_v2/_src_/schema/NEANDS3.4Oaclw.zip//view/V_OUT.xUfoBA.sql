CREATE VIEW V_OUT AS
  select to_number(b.ID||ascii('A')) as id,b.ad_client_id,b.ad_org_id,a.docno,a.doctype,'M_SALEOUT' as billtype,a.billdate,a.C_CUSTOMERUP_ID,a.c_store_id,a.c_dest_id,a.c_customer_id,
a.dateout,a.c_tranway_jz_id,a.tranwayno,a.description,a.out_status as status,a.outerid,a.outtime,a.in_status,a.inerid,a.intime,b.m_product_id,b.m_attributesetinstance_id,
b.qty,b.qtyout,b.pricelist,b.tot_amt_list,b.tot_amt_actual,b.tot_amtout_list,b.tot_amtout_actual,b.m_productalias_id,PICKERID
from m_sale a,m_saleitem b
where a.id=b.m_sale_id
and a.status=2
union all
select to_number(d.ID||ASCII('C')) ,d.ad_client_id,d.ad_org_id,c.docno,c.doctype,'M_TRANSFEROUT',c.billdate,c.c_customer_id,c.c_orig_id,c.c_dest_id,c.c_customer_id,c.dateout,c.c_tranway_jz_id,c.tranwayno,c.description,c.out_status as status,c.outerid,c.outtime,c.in_status,c.inerid,c.intime,d.m_product_id,d.m_attributesetinstance_id,d.qty,d.qtyout,d.pricelist,d.tot_amtqty_list,d.tot_amtqty_list,d.tot_amtout_list,d.tot_amtout_list,d.m_productalias_id,PICKERID
from M_TRANSFER c,M_TRANSFERITEM d
where c.id=d.m_transfer_id
and c.status=2
/

