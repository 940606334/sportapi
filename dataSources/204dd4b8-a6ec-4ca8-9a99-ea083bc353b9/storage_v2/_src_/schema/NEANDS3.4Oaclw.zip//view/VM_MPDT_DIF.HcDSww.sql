CREATE VIEW VM_MPDT_DIF AS
  SELECT F."ID",F."NAME",F."VALUE",F."M_DIM1_ID",F."M_DIM2_ID",F."M_DIM3_ID",F."M_DIM4_ID",F."M_DIM5_ID",F."M_DIM6_ID",F."M_DIM7_ID",F."M_DIM8_ID",F."M_DIM9_ID",F."M_DIM10_ID",F."M_DIM11_ID",F."M_DIM12_ID",F."M_DIM13_ID",F."M_DIM14_ID",F."M_DIM15_ID",F."M_DIM16_ID",F."M_DIM17_ID",F."M_DIM18_ID",F."M_DIM19_ID",F."M_DIM20_ID",F."SERIALNO",F."UNIT",F."PRICELIST",F."ISACTIVE",F."T",F."ISGIFT",F."LOWEST_DISCOUNT",F."NOTLIMITDIS",F."IS_MSCODE",1 RN
FROM (
Select b2a.*, 'm_product' T
from ((Select * from m_pdt) Minus (Select * From m_pdt_tmp)) b2a
--Union all
--Select a2b.*, 'm_pdt_tmp' T
--from ((Select * from m_pdt_tmp) Minus (Select * From m_pdt)) a2b
) F/* edit by Selina 2016/11/1 11:33:23 */

