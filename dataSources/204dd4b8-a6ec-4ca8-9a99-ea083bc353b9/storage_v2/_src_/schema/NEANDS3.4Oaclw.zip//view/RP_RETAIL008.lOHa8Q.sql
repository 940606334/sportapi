CREATE VIEW RP_RETAIL008 AS
  select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.BILLDATE,a.DOCNO,a.retailbilltype,a.c_customer_id,a.C_STORE_ID,a.DESCRIPTION,a.C_VIP_ID,b.SALESREP_ID,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,b.QTY as qtyrtl,null as qtyret,b.PRICELIST,
b.TOT_AMT_LIST as tot_amtrtl_list,null as tot_amtret_list,
b.tot_amt_list-b.tot_amt_actual as tot_amtrtl_discount,--add by ken for MKL report 20100327
b.tot_amt_actual/(1+NVL(e.taxrate,0)) as tot_amtrtl_aftertax,--add by ken for MKL report 20100327
b.PRICEACTUAL,b.TOT_AMT_ACTUAL as tot_amtrtl_actual, null as tot_amtret_actual,
null as tot_amtret_discount,--add by ken for MKL report 20100327
null as tot_amtret_aftertax,--add by ken for MKL report 20100327
b.qty,b.tot_amt_list,b.tot_amt_actual,
b.tot_amt_list-b.tot_amt_actual as tot_amt_discount,--add by ken for MKL report 20100327
b.tot_amt_actual/(1+NVL(e.taxrate,0)) as tot_amt_aftertax,--add by ken for MKL report 20100327
b.discount as rtldis, 0 as retdis,d.precost as PERCOST,
d.precost*b.QTY as tot_amtrtl_cost,null as tot_amtret_cost,
d.precost*b.QTY as tot_amt_cost,'S' AS C_STORE_TYPE,s.id as m_product_alias_id
from M_RETAIL a,M_RETAILITEM b,m_product d, c_store e,m_product_alias s
where a.ID=b.M_RETAIL_ID
and b.m_product_id = d.id
and a.c_store_id=e.id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id(+)
and b.m_product_id=s.m_product_id(+)
and a.STATUS=2
and b.qty > 0
union
select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.BILLDATE,a.DOCNO,a.retailbilltype,a.c_customer_id,a.C_STORE_ID,a.DESCRIPTION,a.C_VIP_ID,b.SALESREP_ID,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,null as qtyrtl,-b.qty as qtyret,b.PRICELIST,
null as tot_amtrtl_list,-b.TOT_AMT_LIST as tot_amtret_list,
null as tot_amtrtl_discount,--add by ken for MKL report 20100327
null as tot_amtrtl_aftertax,--add by ken for MKL report 20100327
b.PRICEACTUAL,null as tot_amtrtl_actual, -b.TOT_AMT_ACTUAL as tot_amtret_actual,
-(b.tot_amt_list-b.tot_amt_actual) as tot_amtret_discount,--add by ken for MKL report 20100327
-b.tot_amt_actual/(1+NVL(e.taxrate,0)) as tot_amtret_aftertax,--add by ken for MKL report 20100327
b.qty,b.tot_amt_list,b.tot_amt_actual,
-(b.tot_amt_list-b.tot_amt_actual) as tot_amt_discount,--add by ken for MKL report 20100327
-b.tot_amt_actual/(1+NVL(e.taxrate,0)) as tot_amt_aftertax,--add by ken for MKL report 20100327
0 as rtldis,b.discount as retdis,d.precost as PERCOST,
null as tot_amtrtl_cost,d.precost*(-b.QTY) as tot_amtret_cost,
d.precost*(-b.QTY) as tot_amt_cost,'S' AS C_STORE_TYPE,s.id as m_product_alias_id
from M_RETAIL a,M_RETAILITEM b,m_product d, c_store e,m_product_alias s
where a.ID=b.M_RETAIL_ID
and b.m_product_id = d.id
and a.c_store_id=e.id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id(+)
and b.m_product_id=s.m_product_id(+)
and a.STATUS=2
and b.qty < 0
with read only
/

