CREATE VIEW M_PUR_PRICE AS
  SELECT id, ad_client_id, ad_org_id, ownerid, modifierid, creationdate,
       modifieddate, isactive, docno, doctype, datein AS billdate, salesrep_id,
       c_store_id, c_supplier_id, description, pck_status as status, au_state,
       au_pi_id, avg_discount, tot_lines, tot_qty, tot_amt_list, tot_amt_actual,
       tot_qtyin, tot_amtin_list, tot_amtin_actual, tot_amtin_pcheck,
       amt_deduction, c_period_id, dateout, datein, statuserid, statustime,
       inerid, intime, pck_status, pcheckid, pchecktime, tot_amt_fee,
       exchangerate, tot_amt_precost, unite_status, pricemodify, t.pursource,
       tot_amtin_pchecktax, t.c_currency_id, t.tax_dis, t.tot_qty_inved,
       t.id as m_pur_check_id,t.tot_tax_amt,t.tot_notax_amt,ISAGT,SHIPPING_REMARK
FROM m_purchase t
WHERE in_status = 2
/

