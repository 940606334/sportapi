CREATE VIEW RP_FA_MONTHSTORE01 AS
  SELECT t.id, t.ad_client_id, t.ad_org_id, t.ownerid, t.modifierid,
       t.creationdate, t.modifieddate, t.isactive, t.c_period_id, t.c_store_id,
       t.m_product_id, t.m_attributesetinstance_id, a.pricelist, t.qtybegin,
       t.qtybegin * a.pricelist AS amtlistbeg, t.qtypurchase,
       t.qtypurchase * a.pricelist AS amtlistpurchase, t.amtpurchase,
       t.qtyretpur, t.qtyretpur * a.pricelist AS amtlistretpur, t.amtretpur,
       t.qtysale, t.qtysale * a.pricelist AS amtlistsale, t.amtsale,
       t.qtyretsale, t.qtyretsale * a.pricelist AS amtlistretsale, t.amtretsale,
       t.qtyretail, t.qtyretail * a.pricelist AS amtlistretail, t.amtretail,
       t.qtytransferout, t.qtytransferout * a.pricelist AS amtlisttransferout,
       t.qtytransferin, t.qtytransferin * a.pricelist AS amtlisttransferin,
       t.qtyinventory, t.qtyinventory * a.pricelist AS amtlistinventory,
       t.qtyotherinout, t.qtyotherinout * a.pricelist AS amtlistoth, t.qtyend,
       t.qtyend * a.pricelist AS amtlistend, t.qtyinbegin,
       t.qtyinbegin * a.pricelist AS amtlistinbeg, t.yearmonth, t.qtyinend,
       t.qtyinend * a.pricelist AS amtlistinend, t.notax_amt,t.costdiff
FROM fa_monthstore t, m_product a
WHERE t.m_product_id = a.id WITH READ ONLY
/

