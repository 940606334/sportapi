CREATE VIEW RP_PRODUCE_PRCPUR AS
  select docno,status,billdate,protype,y_factory_id,contractno,
   m_product_id,sum(prcfprice) as prcfprice,sum(purfprice) as purfprice,
   ad_client_id,ad_org_id,modifierid,modifieddate,ownerid,creationdate,isactive
from (select  a.docno,a.status,a.billdate,a.protype,a.y_factory_id,a.contractno,
   b.m_product_id,sum(b.fprice) as prcfprice,null as purfprice,
   a.ad_client_id,a.ad_org_id,a.modifierid,a.modifieddate,a.ownerid,a.creationdate,a.isactive
from Y_PRODUCE a,Y_PRODUCE_PRC_ITEM b --加工费用
where a.id=b.y_produce_id
--and a.status=2
group by b.m_product_id,a.docno,a.status,a.billdate,a.protype,a.y_factory_id,a.contractno,
 a.ad_client_id,a.ad_org_id,a.modifierid,a.modifieddate,a.ownerid,a.creationdate,a.isactive
union
select  a.docno,a.status,a.billdate,a.protype,a.y_factory_id,a.contractno,
    c.m_product_id,null as prcfprice,sum(c.fprice) as purfprice,
    a.ad_client_id,a.ad_org_id,a.modifierid,a.modifieddate,a.ownerid,a.creationdate,a.isactive
from Y_PRODUCE a,Y_PRODUCE_PUR_ITEM c --成采购价格
where a.id=c.y_produce_id
--and a.status=2
group by c.m_product_id,a.docno,a.status,a.billdate,a.protype,a.y_factory_id,a.contractno,
  a.ad_client_id,a.ad_org_id,a.modifierid,a.modifieddate,a.ownerid,a.creationdate,a.isactive) t
group by docno,status,billdate,protype,y_factory_id,contractno,
   m_product_id,
   ad_client_id,ad_org_id,modifierid,modifieddate,ownerid,creationdate,isactive
/

