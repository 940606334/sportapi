CREATE VIEW V_M_AREAPICKSTORYITEMS AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,b.isactive,
a.docno,a.billdate,a.destname,c.code as destcode,a.C_ORIG_ID,a.TABLETYPE,a.M_OUT_ID,to_char(a.STATUSTIME,'yyyymmdd') as statusdate,
b.M_PRODUCT_ID,b.M_PRODUCTALIAS_ID,b.QTY,b.QTYOUT,a.STATUS,a.STATUSERID,to_char(a.STATUSTIME ,'hh24:mi:ss') as STATUSTIME
from m_areapick a,m_areapickstoryitem b,c_store c
where a.id=b.m_areapick_id and a.destname=c.name
order by a.docno desc
/

