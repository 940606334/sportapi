CREATE VIEW RP_DAILY_COUNT AS
  select a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid,
       a.creationdate, a.modifieddate, a.isactive, a.C_CUSTOMER_ID,
       a.id as c_store_id,a.billdate , b.famountsvr, b.famountloc, b.famount,
       b.famountsvr - b.famount as DALIY_AMT_DIFF, b.remark,
      (case
           when b.billdate is not null then
            'Y'
            else
            'N'
      end ) as ISDAILY
from (select a.*,b.t_day_date  billdate from c_store a,t_day b  ) a, C_STORE_DAILYACC b
where a.id = b.c_store_id(+) and a.billdate=b.billdate(+)
/*union
select a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.modifierid,
       a.creationdate, a.modifieddate, a.isactive, a.C_CUSTOMER_ID,
       a.id as c_store_id, TO_NUMBER(to_CHAR(sysdate,'YYYYMMDD')) as billdate, 0 as famountsvr, 0 as famountloc, 0 as famount,
       0 as DALIY_AMT_DIFF, b.remark,
       (case
           when a.id is not null then
            'N'
            ELSE
            'Y'
       end) as ISDAILY
from (select a.*,b.t_day_date  billdate from c_store a,t_day b  ) a, C_STORE_DAILYACC b
where a.id = b.c_store_id(+) and a.billdate=b.billdate(+)*/
 with read only
 --日结报表  by tracy 20100519
/

