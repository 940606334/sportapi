CREATE VIEW RP_CUSPUR003_2 AS
  select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.salebilltype,a.BILLDATE,a.DOCNO,a.DOCTYPE,a.B_SO_ID,a.C_CUSTOMERUP_ID,a.C_STORE_ID,
a.C_CUSTOMER_ID,a.c_dest_id as PURSTORE_ID,a.DESCRIPTION,b.M_PRODUCT_ID,b.M_ATTRIBUTESETINSTANCE_ID,
c.QTY as QTYORDERED,b.QTY as QTYSALE,b.QTYIN as QTYSALEIN,0 as QTYRETSALE,0 as QTYRETSALEOUT,b.PRICELIST,
b.TOT_AMT_LIST as AMTLISTSALE,b.TOT_AMTIN_LIST as AMTLISTSALEIN,0 as AMTLISTRETSALE,0 as AMTLISTRETSALEOUT,
b.PRICEACTUAL,b.TOT_AMT_ACTUAL as AMTSALE,b.TOT_AMTIN_ACTUAL as AMTSALEIN,0 as AMTRETSALE,0 as AMTRETSALEOUT,
b.DISCOUNT as DISCOUNTSALE,0 as DISCOUNTRETSALE,s.id as M_PRODUCT_ALIAS_id,a.datein inoutdate
from M_SALE a/*,m_saleitem b,b_soitem c,m_product_alias s
where  a.ID=b.M_SALE_ID and a.B_SO_ID=c.B_SO_ID
and b.M_PRODUCT_ID=c.M_PRODUCT_ID(+)
and b.M_ATTRIBUTESETINSTANCE_ID=c.M_ATTRIBUTESETINSTANCE_ID(+)
and  b.m_product_id=s.m_product_id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id and a.IN_STATUS=2*/

inner join M_SALEITEM b on  a.ID=b.M_SALE_ID
left join B_SOITEM c on a.B_SO_ID=c.B_SO_ID and b.M_PRODUCT_ID=c.M_PRODUCT_ID
and b.M_ATTRIBUTESETINSTANCE_ID=c.M_ATTRIBUTESETINSTANCE_ID
left join M_PRODUCT_ALIAS s on b.m_product_id=s.m_product_id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id
where a.IN_STATUS=2
union all
select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
null as salebilltype,a.BILLDATE,a.DOCNO,a.DOCTYPE,null as B_SO_ID,a.C_CUSTOMERUP_ID,a.C_STORE_ID,
a.C_CUSTOMER_ID,a.c_orig_id as PURSTORE_ID,a.DESCRIPTION,b.M_PRODUCT_ID,b.M_ATTRIBUTESETINSTANCE_ID,
0 as QTYORDERED,0 as QTYSALE,0 as QTYSALEIN,b.QTY as QTYRETSALE,b.QTYOUT as QTYRETSALEOUT,b.PRICELIST,
0 as AMTLISTSALE,0 as AMTLISTSALEIN,b.TOT_AMT_LIST as AMTLISTRETSALE,b.TOT_AMTOUT_LIST as AMTLISTRETSALEOUT,
b.PRICEACTUAL,0 as AMTSALE,0 as AMTSALEIN,b.TOT_AMT_ACTUAL as AMTRETSALE,b.TOT_AMTOUT_ACTUAL as AMTRETSALEOUT,
0 as DISCOUNTSALE,b.DISCOUNT as DISCOUNTRETSALE,b.m_productalias_id as M_PRODUCT_ALIAS_id ,a.dateout as inoutdate
from M_RET_SALE a,M_RET_SALEITEM b
where a.ID=b.M_RET_SALE_ID
and a.OUT_STATUS=2
with read only
/

