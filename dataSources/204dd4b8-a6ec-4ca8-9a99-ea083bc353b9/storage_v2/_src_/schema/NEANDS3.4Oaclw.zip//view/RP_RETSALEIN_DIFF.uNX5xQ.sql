CREATE VIEW RP_RETSALEIN_DIFF AS
  select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.datein as BILLDATE,a.DOCNO,a.DOCTYPE,a.C_CUSTOMERUP_ID,A.C_ORIG_ID,a.C_STORE_ID,a.C_CUSTOMER_ID,a.DESCRIPTION,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,b.QTY as QTYRETSALE,b.QTYIN as QTYRETSALEIN,b.PRICELIST,
b.QTY*b.pricelist as AMTLISTRETSALE,b.QTYIN*b.pricelist as AMTLISTRETSALEIN,
b.PRICEACTUAL,b.QTY*b.priceactual as AMTRETSALE,b.QTYIN*b.priceactual as AMTRETSALEIN,
b.DISCOUNT as DISCOUNTRETSALE,a.INerid,c.no
from M_RET_SALE a,M_RET_SALEITEM b,m_product_alias c
where a.ID=b.M_RET_SALE_ID
and b.m_product_id=c.m_product_id and b.m_attributesetinstance_id =c.m_attributesetinstance_id
and a.IN_STATUS=2
/

