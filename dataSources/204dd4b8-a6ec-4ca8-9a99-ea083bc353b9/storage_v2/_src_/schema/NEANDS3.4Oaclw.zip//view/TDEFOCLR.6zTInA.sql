CREATE VIEW TDEFOCLR AS
  select to_char(value) as clr,to_char(name) as clrname
from m_color
/

