CREATE VIEW RP_RETAIL011 AS
  select id, ad_client_id, ad_org_id, isactive, creationdate,ownerid, modifieddate, modifierid,
billdate, docno, retailbilltype, c_customer_id, c_store_id, brand,description,
tot_amtrtl_list,tot_amtrtl_actual, tot_amtrtl_discount, tot_amtrtl_cost, tot_amtrtl_aftertax,
tot_amtret_list,tot_amtret_actual, tot_amtret_discount, tot_amtret_cost, tot_amtret_aftertax,
tot_amt_list,tot_amt_actual, tot_amt_discount, tot_amt_cost, tot_amt_aftertax, cuponamt,
tot_amt_actual-nvl(cuponamt,0) as netamt,c_store_type, tot_amt_relativecost
 from
(select max(id) as id, max(ad_client_id) as ad_client_id , max(ad_org_id) as ad_org_id, max(isactive) as isactive,
max(creationdate) as creationdate, max(ownerid) as ownerid, max(modifieddate) as modifieddate,
max(modifierid) as modifierid, billdate, docno, max(retailbilltype) as retailbilltype,c_store_type,
c_customer_id, c_store_id,brand, max(description) as description,
sum(tot_amtrtl_list) as tot_amtrtl_list, sum(tot_amtrtl_actual) as tot_amtrtl_actual,
sum(tot_amtrtl_discount) as tot_amtrtl_discount, sum(tot_amtrtl_cost) as tot_amtrtl_cost,
sum(tot_amtrtl_aftertax) tot_amtrtl_aftertax,sum(tot_amtret_list) as tot_amtret_list,
sum(tot_amtret_actual) as tot_amtret_actual, sum(tot_amtret_discount) as tot_amtret_discount,
sum(tot_amtret_cost) as tot_amtret_cost, sum(tot_amtret_aftertax) as tot_amtret_aftertax,
sum(tot_amt_list) as tot_amt_list,sum(tot_amt_actual) as tot_amt_actual, sum(tot_amt_discount) as tot_amt_discount,
sum(tot_amt_cost) AS tot_amt_cost, sum(tot_amt_aftertax) as tot_amt_aftertax,
sum(tot_amt_relativecost) as tot_amt_relativecost,sum(cuponamt) as cuponamt
from rp_retail010
group by billdate,c_store_id,brand,c_customer_id,docno,c_store_type
) e
/

