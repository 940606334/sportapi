CREATE VIEW V_TDEFSTYLE AS
  select id,name as style, value as stylename,
m_dim1_id, m_dim2_id, m_dim3_id, m_dim4_id, m_dim5_id, m_dim6_id, m_dim7_id, m_dim8_id, m_dim9_id, m_dim10_id,
m_dim11_id, m_dim12_id, m_dim13_id, m_dim14_id, m_dim15_id, m_dim16_id, m_dim17_id, m_dim18_id, m_dim19_id, m_dim20_id
from m_product t
/

