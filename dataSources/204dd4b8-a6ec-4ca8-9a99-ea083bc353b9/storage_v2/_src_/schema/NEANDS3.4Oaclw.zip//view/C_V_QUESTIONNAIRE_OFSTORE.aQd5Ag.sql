CREATE VIEW C_V_QUESTIONNAIRE_OFSTORE AS
  SELECT t.id,t.ad_client_id,t.ad_org_id,t.ownerid,t.modifierid,t.creationdate,t.modifieddate,t.isactive,
t.c_store_id,t.begindate,t.enddate,t.c_questionnaire_id,t.times,'Y' as isvalid
FROM C_QUESTIONNAIRE_OFSTORE t
where to_char(sysdate,'yyyymmdd') between t.begindate and t.enddate
union
SELECT t.id,t.ad_client_id,t.ad_org_id,t.ownerid,t.modifierid,t.creationdate,t.modifieddate,t.isactive,
t.c_store_id,t.begindate,t.enddate,t.c_questionnaire_id,t.times,'N' as isvalid
FROM C_QUESTIONNAIRE_OFSTORE t
where to_char(sysdate,'yyyymmdd') not between t.begindate and t.enddate
with read only
/

