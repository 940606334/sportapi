CREATE VIEW M_PDT AS
  SELECT id, NAME, VALUE, m_dim1_id, m_dim2_id, m_dim3_id, m_dim4_id, m_dim5_id,
       m_dim6_id, m_dim7_id, m_dim8_id, m_dim9_id, m_dim10_id, m_dim11_id,
       m_dim12_id, m_dim13_id, m_dim14_id, m_dim15_id, m_dim16_id, m_dim17_id,
       m_dim18_id, m_dim19_id, m_dim20_id, serialno, unit, pricelist,
       decode(is_retail, 'Y', 'N', isactive) AS isactive, isgift,
       lowest_discount, notlimitdis, is_mscode
FROM m_product
where isactive='Y'/* edit by Selina 2017/11/3 22:37:35 */

