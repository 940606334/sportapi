CREATE VIEW V_PO AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.doctype,a.billdate,a.description,a.salesrep_id,a.c_store_id,a.c_supplier_id,a.status,a.statuserid,
a.statustime,a.c_period_id,a.close_status,a.closerid,a.closetime,
a.contractno,a.predatein,a.c_potype_id,a.b_so_id,a.b_plan_id,
b.b_po_id,b.orderno,b.m_attributesetinstance_id,b.qty,b.pricelist,b.priceactual,b.discount,b.m_product_id,
b.tot_amt_list,b.tot_amt_actual,b.M_PRODUCTALIAS_ID,a.tot_qtyrem,a.tot_qtyconsign,b.qtyrem,a.is_box
from b_po a, b_poitem b
where a.id = b.b_po_id
order by docno desc
--with read only
/

