CREATE VIEW TDEFSTORE AS
  select a.id as store,a.name ||'('|| description ||')' as storename,a.c_customer_id as buyerid,b.name as DEPARTNAME,
c.name as CITYNAME,a.isactive as isactive
from c_store a,C_DEPART b,C_CITY c
where a.c_depart_id=b.id(+)
and a.c_city_id=c.id(+)
/

