CREATE VIEW RP_SO AS
  select b.id,b.ad_client_id,b.ad_org_id,
       a.docno,b.b_so_id,trim(a.doctype) as doctype,a.billdate,a.c_store_id,a.c_dest_id,a.c_period_id,
       b.m_product_id,b.m_attributesetinstance_id,
       b.pricelist,b.priceactual,b.tot_amt_list,b.tot_amt_actual,b.BOXQTYADJ,b.qyboxqtyadj,b.discount,
       b.qty,b.qtyconsign,b.qtyoccu,b.qtyrem,
       b.qtyconsign*b.pricelist amtconsin_list,b.QTYCLO,b.qtyconsign*b.priceactual amtconsin_actual,
       b.qtyoccu*b.pricelist amtoccu_list,b.qtyoccu*b.priceactual amtoccu_actual,
       b.qtyrem*b.pricelist amtrem_list,b.qtyrem*b.priceactual amtrem_actual,b.status,
       b.ownerid,b.modifierid, b.creationdate,b.modifieddate,b.isactive,b.m_productalias_id as m_product_alias_id,
(case  when
(select m.c_customer_id from c_store m where m.id=a.c_store_id)=
 (select n.c_customer_id from c_store n where n.id=a.c_dest_id) then 2 else 1 end
) as billtype,
nvl(t.qty,0) as po_qty,  --[?????],???[????????B_POFLWITEM]??????????????????????
a.b_fair_id,
b.qty-nvl(b.qtymovein,0) as qtyinit,
nvl(b.qtymovein,0)-nvl(b.qtymoveout,0) as qtymove,
b.qty+nvl(b.qtymovein,0)-(nvl(b.qtymovein,0)+nvl(b.qtymoveout,0)) as qtyfinal,
b.qtymovein,b.qtymoveout
from b_so a, b_soitem b,
     (select sum(c.qty) qty,c.b_so_id ,c.m_product_id,c.m_attributesetinstance_id
      from b_po c1,b_poflwitem c
      where c1.status=2 and c1.id=c.b_po_id and nvl(c.b_so_id,0)>0
      group by c.b_so_id,c.m_product_id,c.m_attributesetinstance_id
     ) t
where a.id = b.b_so_id
      and a.status =2 and b.b_so_id=t.b_so_id(+)
      and b.m_product_id=t.m_product_id(+)
      and b.m_attributesetinstance_id=t.m_attributesetinstance_id(+)
and /*b.qtyrem>=1
and */a.status=2
--and a.close_status=1
/

