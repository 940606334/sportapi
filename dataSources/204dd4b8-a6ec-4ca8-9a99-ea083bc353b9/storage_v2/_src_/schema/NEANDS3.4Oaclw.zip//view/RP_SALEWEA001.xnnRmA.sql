CREATE VIEW RP_SALEWEA001 AS
  select t.id, t.ad_client_id, t.ad_org_id, t.ownerid, t.modifierid,
       t.creationdate, t.modifieddate, t.isactive, t.billdate datetime,
       t.c_store_id, sum(t1.qty) qty, sum(t1.tot_amt_list) tot_amt_list,
       sum(t1.tot_amt_actual) tot_amt_actual, t2.c_weather_id, t2.tempera
from m_retail t, m_retailitem t1, c_datewea t2
where t.id = t1.m_retail_id
and t.billdate = t2.datetime(+)
and t.c_store_id = t2.c_store_id(+)
and t.status = 2
group by t.id, t.ad_client_id, t.ad_org_id, t.ownerid, t.modifierid,
         t.creationdate, t.modifieddate, t.isactive, t.billdate, t.c_store_id,
         t2.c_weather_id, t2.tempera
/

