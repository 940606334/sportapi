CREATE VIEW TDEFOEMP AS
  select  to_char(b.code) as buyerid,to_char(a.empno) as empid,to_char(a.truename) as empname,
        to_char(a.password) as password
from hr_emp_users a,c_customer b
where a.c_customer_id=b.id(+) and a.isactive='Y'
/

