CREATE VIEW TDEFOSIZE AS
  SELECT Size1, SizeName
FROM(select  to_char(VALUE) as Size1,to_char(NAME) as SizeName, ROW_NUMBER()
OVER(PARTITION BY a.VALUE ORDER BY a.NAME) AS code_id
from M_SIZE a )
WHERE code_id =1
/

