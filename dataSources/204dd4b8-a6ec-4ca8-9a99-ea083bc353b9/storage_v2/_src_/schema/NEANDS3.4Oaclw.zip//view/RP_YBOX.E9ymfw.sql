CREATE VIEW RP_YBOX AS
  select max(a.id) as id,a.y_boxout_id,b.m_matchsize_id,b.c_customer_id,b.m_product_id,b.m_color_id,count(b.id) as boxqty,sum(b.tot_qty) as qty
from y_boxoutitem a,b_po_boxno b
where a.b_po_boxno_id=b.id
group by a.y_boxout_id,b.m_matchsize_id,b.c_customer_id,b.m_product_id,b.m_color_id
/

