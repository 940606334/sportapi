CREATE VIEW V_SLPRICEADJITEM AS
  select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.modifieddate,a.creationdate,a.isactive,
a.docno,a.priority,a.begindate,a.closedate,b.c_customer_id,c.m_product_id,c.pricelist,c.nowprice,a.DISCOUNT_TYPE,a.C_SALEDISTYPE_ID
from B_SLPRICEADJ a,B_SLPRICEADJCUSITEM b,B_SLPRICEADJPDTITEM c
where a.id=b.b_slpriceadj_id
and a.id=c.b_slpriceadj_id
and a.status=2 and a.isactive='Y'
order by a.docno desc
/

