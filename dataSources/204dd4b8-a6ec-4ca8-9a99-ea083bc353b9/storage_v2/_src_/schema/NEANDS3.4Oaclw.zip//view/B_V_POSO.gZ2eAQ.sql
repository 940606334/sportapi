CREATE VIEW B_V_POSO AS
  select a.id,max(a.ad_client_id) as ad_client_id,max(a.ad_org_id) as ad_org_id,max(a.modifierid) as ownerid,
max(a.modifierid) as modifierid,max(a.modifieddate) as creationdate,max(a.modifieddate) as modifieddate,a.isactive,
a.docno,a.billdate,c.b_so_id,d.c_customer_id,d.c_dest_id,
b.m_product_id,b.m_attributesetinstance_id,b.m_productalias_id,b.predatein,b.confirmdate
from b_po a,b_poitem b,B_POFLWITEM c,b_so d,b_soitem e
where a.id=b.b_po_id
and a.id = c.b_po_id
and c.b_so_id = d.id
and d.id=e.b_so_id
and b.m_product_id=e.m_product_id
and b.m_attributesetinstance_id=e.m_attributesetinstance_id
and c.m_product_id=e.m_product_id
and c.m_attributesetinstance_id=e.m_attributesetinstance_id
and a.isactive='Y'
and a.status=2
group by a.id,a.docno,a.billdate,c.b_so_id,d.c_customer_id,d.c_dest_id,
b.m_product_id,b.m_attributesetinstance_id,b.m_productalias_id,
b.b_po_id,b.predatein,b.confirmdate,a.isactive
/*采购订单明细和采购订单追踪明细关联，取到采购订单号到款号到条码到发货订单号，
    结果让经销商可以看到其发货订单订的商品到条码在采购订单里供应商回复的交期*/

