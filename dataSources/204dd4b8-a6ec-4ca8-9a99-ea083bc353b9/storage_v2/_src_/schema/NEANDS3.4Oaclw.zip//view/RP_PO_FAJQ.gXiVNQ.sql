CREATE VIEW RP_PO_FAJQ AS
  SELECT MAX(a.id) AS id,
       37 AS ad_client_id,
       a.b_po_box_id as b_po_id,
       c.c_supplier_id,
       c.c_store_id,
       a.m_product_id,
       a.confirmdate,
       a.c_customer_id,
       CASE
         WHEN SYSDATE < to_date(a.confirmdate, 'yyyyMMdd') - 7 THEN    --当前时间小于回复交期-7   为未开始
          1
         WHEN SYSDATE <= to_date(a.confirmdate, 'yyyyMMdd') THEN    --当前时间小于等于回复交期   为交期中
          2
         WHEN SYSDATE > to_date(a.confirmdate, 'yyyyMMdd') THEN   --当前时间大于回复交期   为已超期
          3
         ELSE     --否则为 异常
          4
       END sojq_status,
       SUM(decode(a.dx_status, 2, 1, 0)) AS dxqty,
       COUNT(a.id) AS boxqty,
       SUM(a.tot_qty) AS tot_qty,
       floor(SYSDATE - to_date(nvl(a.confirmdate_late,a.confirmdate), 'yyyyMMdd')) AS tot_day,
       max((select t.confirmdate_late
       from b_poboxitem t
       where t.b_po_id=c.id
       and t.b_so_matchsize_id=a.b_so_matchsize_id
       and t.m_matchsize_id=a.m_matchsize_id
       and t.m_product_id=a.m_product_id)) as confirmdate_late
FROM b_po_boxno a, b_po c
WHERE a.b_po_box_id = c.id
AND a.status = 2
AND a.in_status = 1
AND a.close_status = 1
and c.is_box=1
GROUP BY a.b_po_box_id,
         c.c_supplier_id,
         c.c_store_id,
         a.m_product_id,
         a.confirmdate,
         a.confirmdate_late,
         a.c_customer_id
/

