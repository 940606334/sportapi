CREATE VIEW AP_V_SERVICESCONFIRM AS
  SELECT id, ad_client_id, ad_org_id, ownerid, modifierid, creationdate,
       modifieddate, isactive, docno, billdate, m_transfer_id, m_ret_sale_id,
       backdate, back_cusdate, to_backdate, c_store_id, c_customer_id,
       c_customerup_id, deladvice, description, tot_line, tot_qty, au_state,
       au_pi_id, confirm_status AS status, confirmid AS statuserid,
       confirmtime AS statustime, del_status, delid, deltime, close_status,
       closerid, closetime
FROM ap_servicesapply
WHERE pricon_status = 2
AND isactive = 'Y'
/

