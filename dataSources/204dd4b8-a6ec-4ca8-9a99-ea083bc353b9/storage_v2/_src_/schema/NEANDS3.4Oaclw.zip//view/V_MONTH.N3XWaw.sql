CREATE VIEW V_MONTH AS
  select min(t.id) as id,t.t_year_id,t.t_month_mth_of_year,t.t_month_id from t_day t
group by t.t_year_id,t.t_month_mth_of_year,t.t_month_id
order by t.t_month_id
--with read only
/

