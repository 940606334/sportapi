CREATE VIEW TD_SALED_DT AS
  SELECT     '' AS ref_no, '' AS Sku, 0 AS qty, 0 AS amount, 0 AS ifdiscount, 0 AS ifspecial from dual
/

