CREATE VIEW PDA_B_BOXNOCHKPDAITEM AS
  select e.ad_client_id,e.ad_org_id,e.ownerid,b.isactive,e.b_po_boxno_id,a.m_product_id,d.id as m_attributesetinstance_id,
b.qty,c.id as M_PRODUCTALIAS_ID,a.is_box,a.boxno,a.tot_qty,c.no,a.m_color_id,b.m_size_id,d.value1,d.value2,
e.m_purchase_order_id,f.status,f.test_type,a.test_status,f.in_status
from b_po_boxno a,m_matchsizeitem b,M_PRODUCT_ALIAS c,m_attributesetinstance d,M_PURCHASE_ORDERitem e,M_PURCHASE_ORDER f
where a.m_matchsize_id=b.m_matchsize_id
and c.m_product_id=a.m_product_id
and c.m_attributesetinstance_id=d.id
and b.m_size_id=d.value2_id
and a.m_color_id=d.value1_id
and a.id=e.b_po_boxno_id
and e.m_purchase_order_id=f.id
and f.status='2'--提交后1未提交，2提交
--and f.test_type=3--检验要求＝全检
and f.in_status='N'--入库状态＝N
/

