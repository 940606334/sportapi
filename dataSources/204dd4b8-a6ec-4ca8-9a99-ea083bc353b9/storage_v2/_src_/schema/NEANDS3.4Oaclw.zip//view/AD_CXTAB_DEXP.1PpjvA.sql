CREATE VIEW AD_CXTAB_DEXP AS
  select
       t.id,
       t.ad_cxtab_id,
       t.e_sql,
       g.ad_client_id,
       g.ad_org_id,
       g.ownerid,
       g.modifierid,
       g.creationdate,
       g.modifieddate,
       g.isactive
  from ad_cxtab_exp t,
       ad_cxtab g
 where t.ad_cxtab_id=g.id
/

