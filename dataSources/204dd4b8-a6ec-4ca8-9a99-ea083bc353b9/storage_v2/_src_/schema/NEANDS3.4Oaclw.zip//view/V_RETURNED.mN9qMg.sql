CREATE VIEW V_RETURNED AS
  select t.id,t.ad_client_id,t.ad_org_id,t.ownerid,t.modifierid,t.creationdate,t.modifieddate,t.isactive,
       t.docno,t.billdate,t.c_store_id,t.c_dest_id,t.predateout,t.description,t.tot_lines,t.tot_qty,t.au_state,t.au_pi_id,
       t.IN_STATE as STATUS,INUSERID as STATUSERID,intime as STATUSTIME,t.cl_state,t.reason,t.is_fixback,t.b_retreason_id
from M_RETURNED t
/

