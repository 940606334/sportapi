CREATE VIEW RP_SUPPAYCHECK AS
  select h."ID",h."AD_CLIENT_ID",h."AD_ORG_ID",h."MODIFIEDDATE",h."DOCNO",h."DOCTYPE",h."BILLDATE",h."C_SUPPLIER_ID",h."DESCRIPTION",
h."M_PURCHASE_ID",h."M_RET_PUR_ID",h."TOT_AMT_ACTUAL",h."C_FEETYPE_ID",LAG("TOTAL",1,NULL)
  OVER (partition by C_SUPPLIER_ID
        ORDER BY billdate,docno,MODIFIEDDATE) last_hire,
h."PAY_AMT",h."DEDUCT_AMT",h."TOTAL",h.isactive
from
(select k.*,

SUM(k.tot_amt_actual)
    OVER (partition by C_SUPPLIER_ID
          ORDER BY billdate,docno,MODIFIEDDATE
          ROWS 10000000 PRECEDING) as "TOTAL"

from (select
       g.id,g.ad_client_id,g.ad_org_id,
       g.docno,
       g.doctype,
       g.billdate,
       g.c_supplier_id,
       g.description,
       g.status,
       null as M_PURCHASE_ID,
       null as M_RET_PUR_ID,
       -g.tot_amt_actual as tot_amt_actual,
       g.c_feetype_id,
       -g.tot_amt_actual as pay_amt,
       0 as deduct_amt,
       g.modifieddate,
       g.isactive
     from  b_pay g where g.status =2

     union
select
       t.id,t.ad_client_id,t.ad_org_id,
       t.docno,
       t.doctype,
       t.billdate,
       t.c_supplier_id,
       t.description,
       t.status,
       t.M_PURCHASE_ID,
       t.M_RET_PUR_ID,
       t.tot_amt_actual as tot_amt_actual,
       t.c_feetype_id,
       0 as pay_amt,
       t.tot_amt_actual as deduct_amt,
       t.modifieddate,
       t.isactive

     from  b_payable t where t.status =2 )k where exists (select 1 from dual where k.c_supplier_id=c_supplier_id)
  ) h
  order by  billdate,docno,MODIFIEDDATE
/

