CREATE VIEW RP_RETAIL_PDT AS
  select t.id, t.ad_client_id, t.ad_org_id, 893 as OWNERID, 893 as MODIFIERID,
       sysdate as CREATIONDATE, sysdate as MODIFIEDDATE, 'Y' as isactive,
       t.c_vip_id, t.docno, t.refno, t.billdate, t.creationdate as createtime,
       t.c_store_id,
       decode(a.type, '1', '正常零售', '2', '退货', '3', '赠品', '4', '全额') as type,
       s.id as m_productalias_id, s.no, sum(a.qty) as qty,
       sum(a.tot_amt_actual) as tot_amt_actual, t.description
from m_retail t, m_retailitem a, m_product_alias s
where t.id = a.m_retail_id and a.m_product_id = s.m_product_id and
      a.m_attributesetinstance_id = s.m_attributesetinstance_id and
      t.status = 2 and t.c_vip_id is not null
group by t.id, t.ad_client_id, t.ad_org_id, t.c_vip_id, t.docno, t.refno,
         t.billdate, t.creationdate, t.c_store_id, t.description, a.type, s.id,
         s.no
order by t.c_vip_id, t.docno, t.refno, t.billdate, t.creationdate, t.c_store_id,
         t.description, a.type, s.no
/

