CREATE VIEW RP_RETAIL006_2 AS
  select b.ID,
       b.AD_CLIENT_ID,
       b.AD_ORG_ID,
       b.creationdate,
       b.ownerid,
       b.modifieddate,
       b.modifierid,
       b.isactive,
       a.BILLDATE,
       a.C_STORE_ID,
       b.M_PRODUCT_ID,
       b.M_ATTRIBUTESETINSTANCE_ID,
       b.m_productalias_id,
       b.QTY,
       b.PRICELIST,
       b.TOT_AMT_LIST,
       c.qty AS QTY_STORAGE,
       c.qtypreout,
       c.qtyprein,
       (c.qty-c.qtypreout+c.qtyprein) AS QTYVALID,
       c.qtycan as qtycan
  from M_RETAIL        a,
       M_RETAILITEM    b,
       v_fa_storage_can     c
 where a.ID = b.M_RETAIL_ID
   AND b.m_product_id=c.m_product_id
   AND a.c_store_id=c.c_store_id
   AND c.m_attributesetinstance_id=b.m_attributesetinstance_id
   and a.STATUS = 2
 ORDER BY a.billdate
/

