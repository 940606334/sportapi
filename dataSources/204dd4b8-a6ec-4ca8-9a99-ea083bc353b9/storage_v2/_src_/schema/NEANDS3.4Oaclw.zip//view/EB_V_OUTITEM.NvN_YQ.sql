CREATE VIEW EB_V_OUTITEM AS
  select id ,ad_client_id, ad_org_id, isactive, modifierid, creationdate,
       modifieddate, ownerid,EB_ORDERSO_ID--B_TBORDERSO_ID
 as EB_V_OUT_id,
 M_PRODUCTALIAS_ID ,
  M_PRODUCT_ID,
    M_ATTRIBUTESETINSTANCE_ID,
QTY , RQTY,QTYOUT,QTYIN ,price ,total_fee ,payment ,OUT_STATUS as STATUS ,IN_STATUS,FOB,SELL_STATUS,QTYFCAN,
OUT_STATUS,EB_ORDERSO_ID as B_TBORDERSO_ID
from EB_ORDERSOITEM   WHERE   isactive ='Y'
/

