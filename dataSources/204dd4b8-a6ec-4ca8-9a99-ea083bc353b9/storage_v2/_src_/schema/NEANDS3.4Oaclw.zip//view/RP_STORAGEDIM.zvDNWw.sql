CREATE VIEW RP_STORAGEDIM AS
  select max(t.id) as id,t.c_store_id,a.m_dim3_id,sum(t.qty) as qty,sum(t.qtypreout) as qtypreout,sum(t.qtyprein) as qtyprein
from fa_storage t,m_product a
where t.m_product_id=a.id
group by t.c_store_id,a.m_dim3_id
WITH READ ONLY
/

