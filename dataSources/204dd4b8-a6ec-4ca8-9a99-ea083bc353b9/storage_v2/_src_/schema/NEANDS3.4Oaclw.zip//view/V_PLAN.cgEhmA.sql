CREATE VIEW V_PLAN AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.billdate,a.predatein,a.b_so_filter,a.description,a.tot_qty,a.status,
a.close_status,a.au_state,a.finished,a.statuserid,a.statustime,a.closerid,a.closetime,
b.b_plan_id,b.b_so_id,b.m_product_id,b.qty,b.pricelist,b.tot_amt_list,b.m_attributesetinstance_id
from b_plan a, b_planitem b
where a.id = b.b_plan_id
order by a.docno desc
--with read only
/

