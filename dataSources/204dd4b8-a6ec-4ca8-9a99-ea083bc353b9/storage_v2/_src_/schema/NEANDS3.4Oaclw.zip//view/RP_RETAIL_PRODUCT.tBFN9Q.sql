CREATE VIEW RP_RETAIL_PRODUCT AS
  select w.id,w.AD_CLIENT_ID ,w.AD_ORG_ID ,w.OWNERID ,w.MODIFIERID ,
       w.CREATIONDATE ,w.MODIFIEDDATE ,w.ISACTIVE , W.m_product_id ,w.name, w.value, W.ATTRIBNAME, w.pricelist, w.sale_qty,
              w.PRICEACTUAl,W.BILLDATE,w.C_VIP_ID ,w.SALESREP_ID, w.c_store_id,
              sum(c.qty) store_qty
       from (select  a.id,a.AD_CLIENT_ID ,a.AD_ORG_ID ,a.OWNERID ,a.MODIFIERID ,
       a.CREATIONDATE ,a.	MODIFIEDDATE ,a.ISACTIVE ,
       a.m_attributesetinstance_id, b.name, b.value, a.m_product_id,
                     E.ATTRIBNAME, a.pricelist, a.PRICEACTUAL,d.BILLDATE ,d.C_VIP_ID ,a.	SALESREP_ID ,d.c_store_id, sum(a.qty) sale_qty
              from M_RETAILITEM a, m_product b, M_RETAIL d, m_dim e
              where  a.m_product_id = b.id(+) and b.m_dim1_id = e.id and  d.id = a.m_retail_id and d.status = 2
              group by  a.id,a.AD_CLIENT_ID ,a.AD_ORG_ID ,a.OWNERID ,a.MODIFIERID ,
       a.CREATIONDATE ,a.	MODIFIEDDATE ,a.	ISACTIVE ,a.m_attributesetinstance_id, a.m_product_id, b.name, b.value,
                       E.ATTRIBNAME, a.pricelist, a.PRICEACTUAL,d.BILLDATE,d.C_VIP_ID ,a.	SALESREP_ID ,d.c_store_id) w, FA_STORAGE c
       where w.m_product_id = c.m_product_id(+) and
             w.m_attributesetinstance_id = c.m_attributesetinstance_id(+)  AND w.c_store_id=C.C_STORE_ID(+)
            --   and  w.m_product_id = 66295    and w.priceactual =97
       group by  w.id,w.AD_CLIENT_ID ,w.AD_ORG_ID ,w.OWNERID ,w.MODIFIERID ,
       w.CREATIONDATE ,w.MODIFIEDDATE ,w.ISACTIVE ,W.m_product_id,w.name, w.value, W.ATTRIBNAME, w.pricelist, w.PRICEACTUAL,
                w.sale_qty ,W.BILLDATE,w.C_VIP_ID ,w.SALESREP_ID,w.c_store_id
/

