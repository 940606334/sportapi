CREATE VIEW V_RETURNEDITEM AS
  select t.id,t.ad_client_id,t.ad_org_id,t.ownerid,t.modifierid,t.creationdate,t.modifieddate,t.isactive,
t.m_returned_id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,t.qtyin as qty,t.qty as outqty,t.B_RETREASON_ID
from    M_RETURNEDITEM t
/

