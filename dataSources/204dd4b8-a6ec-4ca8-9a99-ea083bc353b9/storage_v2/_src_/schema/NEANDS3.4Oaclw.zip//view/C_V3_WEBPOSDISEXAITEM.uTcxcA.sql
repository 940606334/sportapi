CREATE VIEW C_V3_WEBPOSDISEXAITEM AS
  select a.id,a.c_webposdis_id,a.m_productalias_id,a.qty,a.relationtype
from 	C_WEBPOSDIS t,C_WEBPOSDISEXAITEM a
where t.id=a.c_webposdis_id
and t.webtype=3 and t.close_status=1
and t.isactive='Y'/* edit by Selina 2017/2/24 15:17:00 */

