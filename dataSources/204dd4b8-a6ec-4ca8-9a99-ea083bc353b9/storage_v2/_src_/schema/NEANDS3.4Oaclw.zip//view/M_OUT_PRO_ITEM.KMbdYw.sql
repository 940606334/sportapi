CREATE VIEW M_OUT_PRO_ITEM AS
  select max(ID||ascii('A')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_SALE_ID||ascii('A') as m_out_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout
from M_SALEITEM
where status=2
group by ad_client_id,ad_org_id,M_SALE_ID||ascii('A'),m_product_id
union all
select max(ID||ascii('B')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_RET_SALE_ID||ascii('B') as m_out_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout
from M_RET_SALEITEM
where status=2
group by ad_client_id,ad_org_id,M_RET_SALE_ID||ascii('B'),m_product_id
union all
select max(ID||ascii('C')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_TRANSFER_ID||ascii('C') as m_out_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout
from M_TRANSFERITEM
where status=2
group by ad_client_id,ad_org_id,M_TRANSFER_ID||ascii('C'),m_product_id
union all
select max(ID||ascii('D')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_RET_SALE_ID||ascii('D') as m_out_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout
from M_RET_SALEITEM
where status=2
group by ad_client_id,ad_org_id,M_RET_SALE_ID||ascii('D'),m_product_id
union all
select max(ID||ascii('E')) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
m_ret_pur_ID||ascii('E') as m_out_id,m_product_id,max(orderno) as orderno,
sum(qty) as qty,sum(qtyout) as qtyout
from m_ret_purITEM
where status=2
group by ad_client_id,ad_org_id,m_ret_pur_ID||ascii('E'),m_product_id
/

