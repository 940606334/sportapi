CREATE VIEW RP_RETAIL005 AS
  select id,c_store_id,no,docno,billdate,m_product_id,m_attributesetinstance_id,
qty,PRICELIST,TOT_AMT_LIST,PRICEACTUAL,TOT_AMT_ACTUAL ,   DISCOUNT  ,
(case when DISCOUNT <=1 and DISCOUNT>=0.85 then '10-9折'
     when DISCOUNT <0.85 and DISCOUNT>=0.65 then '8-7折'
     when DISCOUNT <0.65 and DISCOUNT>=0.5 then '6-5折'
      when DISCOUNT <0.5  then '5折以下'
   else null end)DISC_inteR from(select MAX(B.ID)ID, a.c_store_id,c.no, a.DOCNO,A.BILLDATE, b.m_product_id, b.m_attributesetinstance_id,sum(b.qty)qty,
 B.PRICELIST ,SUM(B.TOT_AMT_ACTUAL) TOT_AMT_ACTUAL ,  B.PRICEACTUAL,
 sum(B.TOT_AMT_LIST )TOT_AMT_LIST,
 round(decode(nvl(sum(b.tot_amt_list),0),0,0,SUM(B.TOT_AMT_ACTUAL)/sum(B.TOT_AMT_LIST )),2)   DISCOUNT
from M_RETAIL a, M_RETAILITEM b,M_PRODUCT_ALIAS c
where a.id = b.m_retail_id and a.status = 2
   and b.m_product_id=c.m_product_id and b.m_attributesetinstance_id=c.m_attributesetinstance_id
GROUP BY  a.c_store_id,c.no, a.DOCNO, b.m_product_id,A.BILLDATE, b.m_attributesetinstance_id,B.PRICELIST , B.PRICEACTUAL)
/

