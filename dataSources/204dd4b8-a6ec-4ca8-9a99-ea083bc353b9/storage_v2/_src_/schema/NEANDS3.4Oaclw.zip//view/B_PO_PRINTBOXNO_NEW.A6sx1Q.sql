CREATE VIEW B_PO_PRINTBOXNO_NEW AS
  select distinct b2.id,
                d2.ad_client_id,
                d2.ad_org_id,
                d2.ownerid,
                d2.modifierid,
                d2.creationdate,
                d2.modifieddate,
                d2.isactive,
                c2.B_PO_BOXNO_ID,
                b2.ORDERNO,
                b2. BOXNO,
                b2.B_SO_ID,
                b2.M_PRODUCT_ID,
                b2.CONFIRMDATE,
                d2.DESCRIPTION,
                d2.C_STORE_ID,
                d2.DOCNO,
                f.m_color_id,
                b2.TOT_QTY,
                t1.size1,
                qty1,
                t2.size2,
                qty2,
                t3.size3,
                qty3,
                t4.size4,
                qty4,
                t5.size5,
                qty5,
                t6.size6,
                qty6,
                t7.size7,
                qty7,
                t8.size8,
                qty8,
                b2.printstatus as status,
                b2.PRINTER AS statuserid,
                b2.PRINTTIME as statustime
  from B_PO_BOXNO b2,
       b_po_boxitem c2,
       M_ATTRIBUTESETINSTANCE a2,
       B_PO d2,
       m_product f,
       (select B_PO_BOXNO_ID, M_PRODUCT_ID,isize as size1, qty as qty1, code_id
          from b_po_sub_printboxno
         where code_id = 1) t1,
       (select B_PO_BOXNO_ID, M_PRODUCT_ID,isize as size2, qty as qty2, code_id
          from b_po_sub_printboxno
         where code_id = 2) t2,
       (select B_PO_BOXNO_ID, M_PRODUCT_ID,isize as size3, qty as qty3, code_id
          from b_po_sub_printboxno
         where code_id = 3) t3,
       (select B_PO_BOXNO_ID, M_PRODUCT_ID,isize as size4, qty as qty4, code_id
          from b_po_sub_printboxno
         where code_id = 4) t4,
       (select B_PO_BOXNO_ID, M_PRODUCT_ID,isize as size5, qty as qty5, code_id
          from b_po_sub_printboxno
         where code_id = 5) t5,
       (select B_PO_BOXNO_ID, M_PRODUCT_ID,isize as size6, qty as qty6, code_id
          from b_po_sub_printboxno
         where code_id = 6) t6,
       (select B_PO_BOXNO_ID, M_PRODUCT_ID,isize as size7, qty as qty7, code_id
          from b_po_sub_printboxno
         where code_id = 7) t7,
       (select B_PO_BOXNO_ID, M_PRODUCT_ID,isize as size8, qty as qty8, code_id
          from b_po_sub_printboxno
         where code_id = 8) t8
 where c2.B_PO_BOXNO_ID = b2.id
   and b2.b_po_box_id = c2.b_po_box_id
   and b2.M_PRODUCT_ID = c2.M_PRODUCT_ID
   and a2.id = c2.M_ATTRIBUTESETINSTANCE_ID
   and d2.id = c2.b_po_box_id
   and f.id = c2.m_product_id
   and d2.status = 2
   and d2.box_status=2
   and t1.b_po_boxno_id = c2.b_po_boxno_id
   and t1.m_product_id = c2.m_product_id
   and c2.b_po_boxno_id = t2.b_po_boxno_id(+)
   and c2.m_product_id = t2.m_product_id(+)
   and t2.b_po_boxno_id = t3.b_po_boxno_id(+)
   and t2.m_product_id = t3.m_product_id(+)
   and t3.b_po_boxno_id = t4.b_po_boxno_id(+)
   and t3.m_product_id = t4.m_product_id(+)
   and t4.b_po_boxno_id = t5.b_po_boxno_id(+)
   and t4.m_product_id = t5.m_product_id(+)
   and t5.b_po_boxno_id = t6.b_po_boxno_id(+)
   and t5.m_product_id = t6.m_product_id(+)
   and t6.b_po_boxno_id = t7.b_po_boxno_id(+)
   and t6.m_product_id = t7.m_product_id(+)
   and t7.b_po_boxno_id = t8.b_po_boxno_id(+)
   and t7.m_product_id = t8.m_product_id(+)
/

