CREATE VIEW B_SO_TOAS AS
  select
       c.name,
        f.value1,
        '裤子' as class,
             g.pricelist,
             'd1' as bo,

       t.doctype,
       d.name as cname,
       (select count(*) from c_store i where i.c_customer_id =d.id) as count_store,
      0.8 as pr,
      '顾晓梅' as ename,
       e.value,
       g.qty,
       g.m_product_id,
       c.m_sizegroup_id,
       t.id
       ,e.martixcol,h.name as gpname
       ,f.id as m_attributesetinstance_id
  from b_so t,
       b_soitem g,m_product c,m_attributesetinstance f,m_attributevalue e,c_customer d,m_attributeinstance k,M_ATTRIBUTE h
 where t.id = g.b_so_id   and g.m_product_id=c.id and g.m_attributesetinstance_id=f.id and t.c_customer_id=d.id  and  t.status=2
 and t.close_status=1 and g.qtyrem>0
  and c.m_sizegroup_id=e.m_attribute_id and f.id = k.m_attributesetinstance_id and k.m_attributevalue_id= e.id and c.m_sizegroup_id=h.id
  order by g.m_product_id,e.value,e.martixcol
/*
  group by   name,
       value1,
       class,
       pricelist,
        bo,
        doctype,
      ename,
       pr,
        count_store,
        cname,
       value,
      m_product_id,
       m_sizegroup_id,
       martixcol,
      gpname
  */

