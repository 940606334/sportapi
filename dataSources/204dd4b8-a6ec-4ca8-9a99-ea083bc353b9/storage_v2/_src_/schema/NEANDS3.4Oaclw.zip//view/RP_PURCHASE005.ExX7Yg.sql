CREATE VIEW RP_PURCHASE005 AS
  select '采购' as optype,b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,
a.billdate,a.DOCNO,a.DOCTYPE,a.C_STORE_ID,a.C_SUPPLIER_ID,a.DESCRIPTION,
b.M_PRODUCT_ID,b.M_ATTRIBUTESETINSTANCE_ID,b.QTYIN as QTYPUR,0 as QTYRETPUR,
b.PRICELIST,b.TOT_AMTIN_LIST as AMTLISTPUR,0.0000 as AMTLISTRETPUR,
b.PRICEACTUAL,b.TOT_AMTIN_ACTUAL as AMTPUR,b.PRICECHECK,b.TOT_AMTIN_PCHECK,0.0000 as AMTRETPUR,
b.DISCOUNT as DISCOUNTPUR,0.0000 as DISCOUNTRETPUR,s.id as M_PRODUCT_ALIAS_id,a.datein,
PERCOST_Analyse(to_number(substr(a.billdate,1,6)),a.c_store_id,b.m_product_id) as PERCOST,b.QTYIN as QTY_PURTRUE,b.TOT_AMTIN_ACTUAL as AMT_COST,
0 as SRPRICE
from M_PURCHASE a,M_PURCHASEITEM b,M_PRODUCT_ALIAS s
where a.ID=b.M_PURCHASE_ID
and b.m_product_id=s.m_product_id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id
and a.IN_STATUS=2
union
select '采购退货' as optype,b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,
a.billdate,a.DOCNO,a.DOCTYPE,a.C_STORE_ID,a.C_SUPPLIER_ID,a.DESCRIPTION,
b.M_PRODUCT_ID,b.M_ATTRIBUTESETINSTANCE_ID,0 as QTYPUR,b.QTYOUT as QTYRETPUR,
b.PRICELIST,0.0000 as AMTLISTPUR,b.TOT_AMT_LIST as AMTLISTRETPUR,
0 as PRICEACTUAL,0.0000 as AMTPUR,0.0000 as PRICECHECK, 0.0000 as TOT_AMTIN_PCHECK,b.TOT_AMTOUT_ACTUAL as AMTRETPUR,
0.0000 as DISCOUNTPUR,b.DISCOUNT as DISCOUNTRETPUR,s.id as M_PRODUCT_ALIAS_id,a.dateout as datein,
PERCOST_Analyse(to_number(substr(a.billdate,1,6)),a.c_store_id,b.m_product_id) as PERCOST,-b.QTYOUT as QTY_PURTRUE,-b.TOT_AMTOUT_ACTUAL as AMT_COST,
b.priceactual as SRPRICE
from M_RET_PUR a,M_RET_PURITEM b,M_PRODUCT_ALIAS s
where a.ID=b.M_RET_PUR_ID
and b.m_product_id=s.m_product_id
and b.m_attributesetinstance_id=s.m_attributesetinstance_id
and a.OUT_STATUS=2
with read only
/

