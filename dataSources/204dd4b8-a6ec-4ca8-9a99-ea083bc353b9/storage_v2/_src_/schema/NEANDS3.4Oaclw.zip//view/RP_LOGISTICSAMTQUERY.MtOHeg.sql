CREATE VIEW RP_LOGISTICSAMTQUERY AS
  select max(a.id) as id, max(a.ad_client_id) as ad_client_id,
       max(a.ad_org_id) as ad_org_id, max(a.ownerid) as ownerid,
       max(a.modifierid) as modifierid, max(a.creationdate) as creationdate,
       max(a.modifieddate) as modifieddate, max(a.isactive) as isactive,
       a.C_DEST_ID, a.C_CUSTOMER_ID, a.C_TRANWAY_JZ_ID, a.DATEOUT, a.TRANWAYNO,
       a.C_STORE_ID,
       decode(a.PAYMENTSTYLE,
               'SEND',
               '寄方付',
               'COLL',
               '收方付',
               'SECO',
               '第三方付',
               'SELF',
               '自提') as PAYMENTSTYLE, a.TRANWAY_PAY, sum(b.QTYOUT) as QTYOUT
from m_sale a, m_saleitem b
where a.out_STATUS = 2 and a.id = b.m_sale_id
group by a.C_DEST_ID, a.C_CUSTOMER_ID, a.C_TRANWAY_JZ_ID, a.DATEOUT, a.TRANWAYNO,
         a.C_STORE_ID, a.PAYMENTSTYLE, a.TRANWAY_PAY
/

