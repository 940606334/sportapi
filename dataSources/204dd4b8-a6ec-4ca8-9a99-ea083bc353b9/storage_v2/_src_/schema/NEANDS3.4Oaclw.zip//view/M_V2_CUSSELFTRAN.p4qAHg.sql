CREATE VIEW M_V2_CUSSELFTRAN AS
  select mc.id,mc.ad_client_id,mc.ad_org_id,mc.docno,mc.billdate,
       mc.c_origcustomer_id,mc.c_orig_id,mc.c_customer_id,mc.c_destcustomer_id,
       mc.c_store_id,mc.c_dest_id,mc.center_dateout,mc.send_dateout,
       mc.retsaletype,mc.c_saledistype_id,mc.description,mc.tot_lines,
       mc.tot_qty,mc.tot_amt_list,mc.tot_amtret_actual,mc.head_status as status,
       mc.status as cus_status,mc.c_period_id,mc.ownerid,mc.modifierid,mc.creationdate,
       mc.modifieddate,mc.statuserid as cus_statuserid,mc.statustime as cus_statustime,
       mc.head_statuserid as statuserid,mc.head_statustime as statustime,mc.isactive
from m_cusselftran mc
/

