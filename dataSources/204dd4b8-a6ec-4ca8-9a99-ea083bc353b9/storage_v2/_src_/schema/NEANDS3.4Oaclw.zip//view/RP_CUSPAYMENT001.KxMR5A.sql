CREATE VIEW RP_CUSPAYMENT001 AS
  select a.id,
       a.ad_client_id,
       a.ad_org_id,
       a.c_customer_id,
       a.modifieddate,
       a.last_hire  as tot_begin_amt,
       a.COLLECT_AMT as tot_rece_amt,
       a.deduct_amt  as tot_deduct_amt,
       a.last_hire + a.COLLECT_AMT - a.deduct_amt as  tot_last_amt,
       b.amt_receivable   as tot_rece_pay,
       c.INVOICE_AMT as tot_invoice_amt,
       a.last_hire + a.COLLECT_AMT - c.INVOICE_AMT as tot_unrece_amt
from  rp_cusrecvcheck a ,fa_customer b,rp_cusinvccheck c
/

