CREATE VIEW RP_OTHERINOUT002 AS
  select b.ID,
       b.AD_CLIENT_ID,
       b.AD_ORG_ID,
       a.BILLDATE,
       a.DOCNO,
       a.C_STORE_ID,
       a.DESCRIPTION,
       c.id C_OTHER_INOUTTYPE_ID,
       a.OTHERBILLTYPE OTHERBILLTYPE,
       b.M_PRODUCT_ID,
       b.M_ATTRIBUTESETINSTANCE_ID,
       b.QTY,
       m.PRICELIST,
       b.qty*m.pricelist TOT_AMT_LIST,
       s.id as m_product_alias_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,b.isactive,
       PERCOST_Analyse(substr(a.billdate,1,6),a.c_store_id,b.m_product_id) as percost,m.precost
from M_OTHER_INOUT a,M_OTHER_INOUTITEM b,C_OTHER_INOUTTYPE c,m_product_alias s,
     m_product m,c_store o, c_customer p,c_cusrank q
where a.ID = b.M_OTHER_INOUT_ID
  and b.m_product_id = s.m_product_id
  and b.m_attributesetinstance_id = s.m_attributesetinstance_id
  and a.c_other_inouttype_id = c.id(+)
  and a.STATUS = 2
  and b.m_product_id=m.id
  and a.c_store_id=o.id
  and o.c_customer_id=p.id
  and p.c_cusrank_id=q.id
  and q.name='总部'
union all
select b.ID,
       b.AD_CLIENT_ID,
       b.AD_ORG_ID,
       a.BILLDATE,
       a.DOCNO,
       a.C_STORE_ID,
       a.DESCRIPTION,
       c.id C_OTHER_INOUTTYPE_ID,
       a.OTHERBILLTYPE OTHERBILLTYPE,
       b.M_PRODUCT_ID,
       b.M_ATTRIBUTESETINSTANCE_ID,
       b.QTY,
       m.PRICELIST,
       b.qty*m.pricelist TOT_AMT_LIST,
       s.id as m_product_alias_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,b.isactive,
       PERCOST_Analyse(substr(a.billdate,1,6),a.c_store_id,b.m_product_id) as percost,
       decode((ad_param_value(a.ad_client_id, 'portal.4040', 'false')),'true',nvl(m.pricelist*(select saledis from C_CUSDISDEF l where p.id=l.c_customer_id and m.m_dim21_id=l.m_dim21_id),0),nvl(m.pricelist*p.saledis,0)) as precost
from M_OTHER_INOUT a,M_OTHER_INOUTITEM b,C_OTHER_INOUTTYPE c,m_product_alias s,
     m_product m,c_store o, c_customer p,c_cusrank q
where a.ID = b.M_OTHER_INOUT_ID
  and b.m_product_id = s.m_product_id
  and b.m_attributesetinstance_id = s.m_attributesetinstance_id
  and a.c_other_inouttype_id = c.id(+)
  and a.STATUS = 2
  and b.m_product_id=m.id
  and a.c_store_id=o.id
  and o.c_customer_id=p.id
  and p.c_cusrank_id=q.id
  and q.name<>'总部'
with read only
/

