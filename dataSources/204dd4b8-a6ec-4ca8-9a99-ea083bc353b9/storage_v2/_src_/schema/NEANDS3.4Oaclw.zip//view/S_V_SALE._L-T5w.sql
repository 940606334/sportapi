CREATE VIEW S_V_SALE AS
  select C_CUSTOMER_ID,billmonth,sum(tot_amt_mark) as tot_amt_mark,sum(tot_amt) as tot_amt,sum(sale_amt) as sale_amt
from (
 --物料销售-物料退货
 select C_CUSTOMER_ID,billmonth,0 as tot_amt_mark,0 as tot_amt,nvl(-sum(m_saleamt),0) as sale_amt from
 (select m1.C_CUSTOMER_ID,to_number(substr(m1.billdate,0,6)) as billmonth,sum(m1.TOT_AMT_ACTUAL) as m_saleamt from B_RECEIVABLE m1,M_SALE m2,C_SALETYPE m3
    where m1.m_sale_id=m2.id and m2.C_SALETYPE_ID=m3.id and m3.name='物料销售' and m1.status=2
    group by  m1.C_CUSTOMER_ID,substr(m1.billdate,0,6)
    union all
select m1.C_CUSTOMER_ID,to_number(substr(m1.billdate,0,6)) as billmonth,sum(m1.TOT_AMT_ACTUAL) as m_saleamt from B_RECEIVABLE m1,M_RET_SALE m2,C_RET_SALETYPE m3
     where m1.M_RET_SALE_ID=m2.id and m2.C_RET_SALETYPE_ID=m3.id and m3.name='物料退货' and m1.status=2
     group by m1.C_CUSTOMER_ID,substr(m1.billdate,0,6))
  group by C_CUSTOMER_ID,billmonth
  union all
 --任务指标
select c1.c_customer_id,to_number(s_getmonth(c2.year||c2.month)) as billmonth,sum(c2.tot_amt_mark) as tot_amt_mark,0 as tot_amt,0 as sale_amt from C_CUSPURMARK c1,C_CUSPURMARKITEM c2
 where c1.id=c2.c_cuspurmark_id group by c1.c_customer_id,s_getmonth(c2.year||c2.month)
 union all
 --回款
 select c3.c_customer_id,to_number(substr(c3.billdate,0,6)) as billmonth,0 as tot_amt_mark,sum(c3.tot_amt_actual) as tot_amt,0 as sale_amt
 from B_RECEIVE c3 where c3.status=2 group by c3.c_customer_id,substr(c3.billdate,0,6)
union all
--销售-销退
select  c_customer_id,to_number(substr(billdate,0,6)) as billmonth,0 as tot_amt_mark,0 as tot_amt,sum(nvl(AMTSALE,0)-nvl(AMTRETSALE,0)) as sale_amt
 from RP_SALE001 group by c_customer_id,substr(billdate,0,6)
union all
--货补
 select t3.c_customer_id,to_number(substr(t3.billdate,0,6)) as billmonth,0 as tot_amt_mark,0 as tot_amt,-sum(t3.tot_amt_actual) as sale_amt
 from B_RECEIVE t3,c_feetype t4 where t3.c_feetype_id=t4.id and t4.name='货补' and t3.status=2 group by t3.c_customer_id,substr(t3.billdate,0,6)
 ) group by C_CUSTOMER_ID,billmonth order by C_CUSTOMER_ID,billmonth
/

