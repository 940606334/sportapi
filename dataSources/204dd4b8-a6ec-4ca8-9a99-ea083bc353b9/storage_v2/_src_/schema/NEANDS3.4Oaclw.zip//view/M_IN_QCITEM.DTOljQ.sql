CREATE VIEW M_IN_QCITEM AS
  select TO_NUMBER(b.id||ascii('I')) as id,b.id as real_id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
       TO_NUMBER(b.m_ret_sale_id||ascii('I')) as m_in_id,b.m_product_id,b.m_attributesetinstance_id,b.qcqty,b.qtyin,
       b.m_productalias_id,'I' as billtype,b.boxno
from m_ret_saleinqcitem b
where b.isactive='Y'
union all
select TO_NUMBER(c.id||ascii('J')) as id,c.id as real_id,c.ad_client_id,c.ad_org_id,c.isactive,c.creationdate,c.ownerid,c.modifieddate,c.modifierid,
       TO_NUMBER(c.m_transfer_id||ascii('J')) as m_in_id,c.m_product_id,c.m_attributesetinstance_id,c.qcqty,c.qtyin,
       c.m_productalias_id,'J' as billtype,c.boxno
from m_transferinqcitem c
where c.isactive='Y'
/

