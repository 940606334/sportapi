CREATE VIEW RP_HISSTORAGE_BAK AS
  select t.ad_client_id,t.C_STORE_ID,t.M_PRODUCT_ID,t.M_ATTRIBUTESETINSTANCE_ID,t.total/num as total,t.changedate,
t.total/num*t.pricelist as amt_list,t.total/num*t.percost as amt_cost,t.pricelist,t.percost
 from (
select  t.*,count(*)
       OVER (
       partition by t.m_product_id,t.m_attributesetinstance_id,t.c_store_id
   order by t.c_store_id
  ) num from (
select t.ad_client_id,
       t.c_store_id,
       t.m_product_id,
       a.pricelist,
       decode(b.percost,null,a.precost,b.percost) as percost,
       t.m_attributesetinstance_id,
       SUM(t.qtychange)
       OVER (partition by t.m_product_id,t.m_attributesetinstance_id,t.c_store_id
          ORDER BY  t.c_store_id) as total,
        t.changedate

  from fa_storage_ftp t,m_product a,fa_product_cost b where t.m_product_id = a.id
and t.m_product_id = b.m_product_id (+)) t
 group by
  t.m_product_id,t.m_attributesetinstance_id,t.c_store_id,t.changedate,t.ad_client_id,t.pricelist,t.percost,t.total
  ) t
/

