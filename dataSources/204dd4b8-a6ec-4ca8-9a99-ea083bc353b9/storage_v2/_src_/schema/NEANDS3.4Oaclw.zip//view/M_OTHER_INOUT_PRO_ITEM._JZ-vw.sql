CREATE VIEW M_OTHER_INOUT_PRO_ITEM AS
  select max(id) as id,ad_client_id,ad_org_id,max(ownerid) as ownerid,
       max(modifierid) as modifierid,max(creationdate) as creationdate,
       max(modifieddate) as modifieddate,'y' as isactive,
       mp.m_other_inout_id,mp.m_product_id,sum(mp.qty) qty,
       avg(mp.pricelist) pricelist,sum(mp.tot_amt_list ) tot_amt_list
from m_other_inoutitem  mp
group by ad_client_id,ad_org_id,mp.m_other_inout_id,mp.m_product_id
with read only
/

