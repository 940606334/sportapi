CREATE VIEW RP_RETAIL004 AS
  SELECT b.id,
       b.ad_client_id,
       b.ad_org_id,
       a.billdate,
       a.docno,
       a.c_store_id,
       a.description,
       b.c_payway_id,
       b.payamount,
       c.name,
       b.face_value,
       a.ownerid,
       a.retailbilltype,
       d.name AS salesrep
FROM m_retail a, m_retailpayitem b, c_payway c, hr_employee d
WHERE a.id = b.m_retail_id
AND a.salesrep_id = d.id(+)
AND a.status = 2
AND b.c_payway_id = c.id
with read only
/

