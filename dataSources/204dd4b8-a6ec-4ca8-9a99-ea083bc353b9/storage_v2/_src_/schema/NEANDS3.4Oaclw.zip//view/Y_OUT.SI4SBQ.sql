CREATE VIEW Y_OUT AS
  SELECT a.id || ascii('A') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.ownerid, a.modifierid, a.creationdate, a.modifieddate, a.isactive,
       'Y_DRAWOUT' AS billtype, a.docno, a.list_type, a.billdate, a.dateout,
       a.y_warehouse_id, b.NAME AS destname, a.remark, a.out_status AS status,
       a.au_state, a.au_pi_id, a.tot_qty, a.tot_qtyout, a.statuserid,
       a.statustime, a.outerid, a.outtime, NULL AS involveproduct,
       a.m_dim1_id AS m_dim1_id, NULL AS octime, NULL AS oc_status, NULL AS ocer --add
FROM y_draw a, y_warehouse b
WHERE a.y_destwarehouse_id = b.id(+)
AND a.status = 2 --and a.in_status = 1
UNION ALL
SELECT a.id || ascii('C') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.ownerid, a.modifierid, a.creationdate, a.modifieddate, a.isactive,
       'Y_PURRETOUT' AS billtype, a.docno, a.list_type, a.billdate, a.dateout,
       a.y_warehouse_id, b.NAME AS destname, a.remark, a.out_status AS status,
       a.au_state, a.au_pi_id, a.tot_qty, a.tot_qtyout, a.statuserid,
       a.statustime, a.outerid, a.outtime, a.involveproduct AS involveproduct,
       NULL AS m_dim1_id, NULL AS octime, NULL AS oc_status, NULL AS ocer
FROM y_purret a, c_supplier b
WHERE a.y_supplier_id = b.id
AND a.status = 2 --and a.in_status = 1
UNION ALL
SELECT a.id || ascii('D') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.ownerid, a.modifierid, a.creationdate, a.modifieddate, a.isactive,
       'Y_TRANSFEROUT' AS billtype, a.docno, a.BILLTYPE as list_type, a.billdate, a.dateout,
       a.y_warehouse_id, b.NAME AS destname, a.DESCRIPTION as remark, a.out_status AS status,
       a.au_state, a.au_pi_id, a.tot_qty, a.tot_qtyout, a.statuserid,
       a.statustime, a.outerid, a.outtime, null as involveproduct,
       NULL AS m_dim1_id, NULL AS octime, NULL AS oc_status, NULL AS ocer
FROM Y_TRANSFER a, y_warehouse b
WHERE a.y_destwarehouse_id = b.id(+)
AND a.status = 2 --and a.in_status = 1;
/

