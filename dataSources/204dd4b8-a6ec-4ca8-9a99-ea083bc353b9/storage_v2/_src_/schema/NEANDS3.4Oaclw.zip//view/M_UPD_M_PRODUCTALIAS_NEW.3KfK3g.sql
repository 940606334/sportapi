CREATE VIEW M_UPD_M_PRODUCTALIAS_NEW AS
  select '1'as id,p_type,p_id  from (
select 'b_planitem' as p_type,id as p_id from b_planitem t where nvl(t.m_productalias_id,0)=0
union all
select 'b_poadjitem' as p_type,id as p_id from b_poadjitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'b_poitem' as p_type,id as p_id from b_poitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'b_soadjitem' as p_type,id as p_id from b_soadjitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'b_soitem' as p_type,id as p_id from b_soitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_assignitem' as p_type,id as p_id from m_assignitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_autocompitem' as p_type,id as p_id from m_autocompitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_custranitem' as p_type,id as p_id from m_custranitem t where nvl(t.m_productalias_id,0)=0
union all
select 'm_inboxitem' as p_type,id as p_id from m_inboxitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_inventoryitem' as p_type,id as p_id from m_inventoryitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_inventory_shelfitem' as p_type,id as p_id from m_inventory_shelfitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_inventory_unionchangehis' as p_type,id as p_id from m_inventory_unionchangehis t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_other_inoutitem' as p_type,id as p_id from m_other_inoutitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_purchaseitem' as p_type,id as p_id from m_purchaseitem t where nvl(t.m_productalias_id,0)=0
union all
select 'm_retailitem' as p_type,id as p_id from m_retailitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_ret_puritem' as p_type,id as p_id from m_ret_puritem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_ret_salediffitem' as p_type,id as p_id from m_ret_salediffitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_ret_saleitem' as p_type,id as p_id from m_ret_saleitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_salediffitem' as p_type,id as p_id from m_salediffitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_saleitem' as p_type,id as p_id from m_saleitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_selfcustranitem' as p_type,id as p_id from m_selfcustranitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_trandiffitem' as p_type,id as p_id from m_trandiffitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'm_transferdelitem' as p_type,id as p_id from m_transferdelitem t where nvl(t.m_productalias_id,0)=0
union all
select 'm_transferdelqtyitem' as p_type,id as p_id from m_transferdelqtyitem t where nvl(t.m_productalias_id,0)=0
union all
select 'm_transferitem' as p_type,id as p_id from m_transferitem t where  nvl(t.m_productalias_id,0)=0
union all
select 'fa_storage' as p_type,id as p_id from FA_STORAGE t where nvl(t.m_productalias_id,0)=0
union all
select 'fa_storage_ftp' as p_type,id as p_id from fa_storage_ftp t where nvl(t.m_productalias_id,0)=0
union all
select 'fa_monthstore' as p_type,id as p_id from fa_monthstore t where nvl(t.m_productalias_id,0)=0
union all
select 'm_saledelqtyitem' as p_type,id as p_id from m_saledelqtyitem t where nvl(t.m_productalias_id,0)=0
union all
select 'm_saledelitem' as p_type,id as p_id  from m_saledelitem t where nvl(t.m_productalias_id,0)=0
union all
select 'm_invoiceitem' as p_type,id as p_id from m_invoiceitem t where nvl(t.m_productalias_id,0)=0
) group by p_type,p_id
/

