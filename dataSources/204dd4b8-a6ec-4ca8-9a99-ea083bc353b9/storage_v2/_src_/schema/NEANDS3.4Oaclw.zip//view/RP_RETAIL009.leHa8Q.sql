CREATE VIEW RP_RETAIL009 AS
  select id, ad_client_id, ad_org_id, isactive, creationdate,ownerid, modifieddate, modifierid,
billdate, docno, retailbilltype, c_customer_id, c_store_id, description,
tot_amtrtl_list,tot_amtrtl_actual, tot_amtrtl_discount, tot_amtrtl_cost, tot_amtrtl_aftertax,
tot_amtret_list,tot_amtret_actual, tot_amtret_discount, tot_amtret_cost, tot_amtret_aftertax,
tot_amt_list,tot_amt_actual, tot_amt_discount, tot_amt_cost, tot_amt_aftertax, cuponamt, tot_amt_actual-cuponamt as netamt,'S' AS C_STORE_TYPE
 from (

select e.id, e.ad_client_id, e.ad_org_id, e.isactive, e.creationdate,e.ownerid, e.modifieddate, e.modifierid,
e.billdate, e.docno, e.retailbilltype, e.c_customer_id, e.c_store_id, e.description,
e.tot_amtrtl_list,e.tot_amtrtl_actual, e.tot_amtrtl_discount, e.tot_amtrtl_cost, e.tot_amtrtl_aftertax,
e.tot_amtret_list,e.tot_amtret_actual, e.tot_amtret_discount, e.tot_amtret_cost, e.tot_amtret_aftertax,
e.tot_amt_list,e.tot_amt_actual, e.tot_amt_discount, e.tot_amt_cost, e.tot_amt_aftertax,

 (select sum(b.payamount)
from m_retail a, m_retailpayitem b, c_payway c
where a.id=b.m_retail_id
and a.docno=e.docno
and b.c_payway_id=c.id
and c.code<>'MCH'
and  c.isbankcard<>'Y'
group by m_retail_id
) as cuponamt

from

(select max(id) as id, max(ad_client_id) as ad_client_id , max(ad_org_id) as ad_org_id, max(isactive) as isactive,
max(creationdate) as creationdate, max(ownerid) as ownerid, max(modifieddate) as modifieddate,
max(modifierid) as modifierid, max(billdate) as billdate, docno, max(retailbilltype) as retailbilltype,
max(c_customer_id) as c_customer_id, max(c_store_id) as c_store_id, max(description) as description,
sum(tot_amtrtl_list) as tot_amtrtl_list, sum(tot_amtrtl_actual) as tot_amtrtl_actual,
sum(tot_amtrtl_discount) as tot_amtrtl_discount, sum(tot_amtrtl_cost) as tot_amtrtl_cost,
sum(tot_amtrtl_aftertax) tot_amtrtl_aftertax,sum(tot_amtret_list) as tot_amtret_list,
sum(tot_amtret_actual) as tot_amtret_actual, sum(tot_amtret_discount) as tot_amtret_discount,
sum(tot_amtret_cost) as tot_amtret_cost, sum(tot_amtret_aftertax) as tot_amtret_aftertax,
sum(tot_amt_list) as tot_amt_list,sum(tot_amt_actual) as tot_amt_actual, sum(tot_amt_discount) as tot_amt_discount,
sum(tot_amt_cost)tot_amt_cost, sum(tot_amt_aftertax) as tot_amt_aftertax

from rp_retail008
group by docno
) e

)
/

