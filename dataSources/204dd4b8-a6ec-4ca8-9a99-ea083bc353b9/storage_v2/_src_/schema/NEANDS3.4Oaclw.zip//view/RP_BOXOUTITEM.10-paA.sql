CREATE VIEW RP_BOXOUTITEM AS
  select t.id,t.y_boxout_id,t.b_po_id,a.c_customer_id,a.m_product_id,a.m_matchsize_id,a.b_so_id,t.b_po_boxno_id,t.isactive
from Y_BOXOUTITEM t,b_po_boxno a
where t.b_po_boxno_id=a.id
WITH READ ONLY
/

