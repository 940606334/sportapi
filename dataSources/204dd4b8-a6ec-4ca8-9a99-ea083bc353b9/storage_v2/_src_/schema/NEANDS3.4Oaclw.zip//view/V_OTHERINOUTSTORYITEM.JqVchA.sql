CREATE VIEW V_OTHERINOUTSTORYITEM AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.OTHERBILLTYPE,a.billdate,a.c_store_id,a.c_other_inouttype_id,b.m_productalias_id,b.m_product_id,
b.m_attributesetinstance_id,
b.C_STORE_LOCATION_ID,b.qty,b.pricelist,b.tot_amt_list,a.status,
a.STATUSERID as STATUSERID,to_char(a.STATUSTIME,'yyyymmdd') as SUBMITDATE,
to_char(a.statustime,'hh24:mi:ss') as STATUSTIME
from M_OTHER_INOUT a,M_OTHERINOUTSTORYITEM b
where a.id = b.m_other_inout_id and a.isactive='Y'
order by STATUSTIME desc
--with read only
/

