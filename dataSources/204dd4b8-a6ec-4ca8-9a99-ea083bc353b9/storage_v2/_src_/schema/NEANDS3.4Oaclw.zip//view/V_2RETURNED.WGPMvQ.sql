CREATE VIEW V_2RETURNED AS
  select t.id,t.ad_client_id,t.ad_org_id,t.ownerid,t.modifierid,t.creationdate,t.modifieddate,t.isactive,
       t.docno,t.billdate,t.c_store_id,t.c_dest_id,t.predateout,t.description,t.tot_lines,t.tot_qty,t.au_state,t.au_pi_id,
       t.CL_STATE as STATUS,CLUSERID as STATUSERID,CLTIME as STATUSTIME,t.is_fixback
from M_RETURNED t
where t.IN_STATE=2
/

