CREATE VIEW RP_ANALYSIS111 AS
  select  a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,
        a.isactive,a.billdate,a.docno,a.c_customer_id,
        a.c_store_id,b.m_product_id,b.m_productalias_id as m_product_alias_id,
        b.m_attributesetinstance_id,b.qty,b.pricelist,b.tot_amt_list,b.priceactual ,
        b.tot_amt_actual,d.precost,d.precost*b.qty as precostlist ,
        nvl(c.percost,d.precost) as percost,nvl(c.percost,d.precost)*b.qty as qtycost,
        (case
             when b.discount<0 then '折扣<0%'
             when b.discount>=0.0 and  b.discount<0.1 then '0%<=折扣<10%'
             when  b.discount>=0.1 and  b.discount<0.2 then '10%<=折扣<20%'
             when  b.discount>=0.2 and  b.discount<0.3 then '20%<=折扣<30%'
             when  b.discount>=0.3 and  b.discount<0.4 then '30%<=折扣<40%'
             when  b.discount>=0.4 and  b.discount<0.5 then '40%<=折扣<50%'
             when  b.discount>=0.5 and  b.discount<0.6 then '50%<=折扣<60%'
             when  b.discount>=0.6 and  b.discount<0.7 then '60%<=折扣<70%'
             when  b.discount>=0.7 and  b.discount<0.8 then '70%<=折扣<80%'
             when  b.discount>=0.8 and  b.discount<0.9 then '80%<=折扣<90%'
             when  b.discount>=0.9 and  b.discount<=1 then '90%<=折扣<100%'
             when  b.discount>1 then '折扣>100%' end
        ) as discount,
        decode(f.empcnt,0,0.00,b.tot_amt_actual/f.empcnt) as renx,
        decode(f.proportion,0,0.00,b.tot_amt_actual/f.proportion) as pingx,
        m.t_month_id as month,substr(m.t_day_week_of_year,1,4)||'年'||'第'||substr(m.t_day_week_of_year,5,4)||'周' as week,
        substr(a.billdate,5,2)||'月'||'第'||substr(a.billdate,7,2)||'天' as day,
        m.t_weekname as week_name,b.tot_amt_actual-(nvl(c.percost,d.precost)*b.qty) as profitcost,
        decode(nvl(b.tot_amt_actual,0),0,0,
               (b.tot_amt_actual- (nvl(c.percost,d.precost)*b.qty))/b.tot_amt_actual
              ) as profit1
from  m_retail a, m_retailitem b,fa_product_cost c,m_product d,c_store f,t_day m
where a.id=b.m_retail_id
      and a.c_store_id=f.id
      and b.m_product_id=c.m_product_id (+)
      and b.m_product_id = d.id
      and a.status  =2
      and a.billdate=m.t_day_date
with read only
/

