CREATE VIEW FA_V_STORAGE_FTP0302 AS
  select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_SALEOUT' as billtype,a.billdate,a.dateout as changedate,a.docno,a.doctype,a.c_store_id,
a.c_dest_id as c_restore_id,null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,b.qtyout,0 as qtyin,0 as qtyother,b.qtyout*b.pricelist as amtout,0 as amtin,0 as amtother
from m_sale a,m_saleitem b
where a.id=b.m_sale_id and a.status=2 and a.out_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_RET_PUROUT' as billtype,a.billdate,a.dateout as changedate,a.docno,a.doctype,a.c_store_id,
null as c_restore_id,a.c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,b.qtyout,0 as qtyin,0 as qtyother,b.qtyout*b.pricelist as amtout,0 as amtin,0 as amtother
from m_ret_pur a,m_ret_puritem b
where a.id=b.m_ret_pur_id and a.status=2 and a.out_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_TRANSFEROUT' as billtype,a.billdate,a.dateout as changedate,a.docno,a.doctype,a.c_orig_id as c_store_id,
a.c_dest_id as c_restore_id,null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,b.qtyout,0 as qtyin,0 as qtyother,b.qtyout*b.pricelist as amtout,0 as amtin,0 as amtother
from m_transfer a,m_transferitem b
where a.id=b.m_transfer_id and a.status=2 and a.out_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_RET_SALEOUT' as billtype,a.billdate,a.dateout as changedate,a.docno,a.doctype,a.c_orig_id as c_store_id,
a.c_store_id as c_restore_id,null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,b.qtyout,0 as qtyin,0 as qtyother,b.qtyout*b.pricelist as amtout,0 as amtin,0 as amtother
from m_ret_sale a,m_ret_saleitem b
where a.id=b.m_ret_sale_id and a.status=2 and a.out_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_V_CUSRET_PUROUT' as billtype,a.billdate,a.dateout as changedate,a.docno,a.doctype,a.c_orig_id as c_store_id,
a.c_store_id as c_restore_id,null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,b.qtyout,0 as qtyin,0 as qtyother,b.qtyout*b.pricelist as amtout,0 as amtin,0 as amtother
from m_ret_sale a,m_ret_saleitem b
where a.id=b.m_ret_sale_id and a.status=2 and a.out_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_SALEIN' as billtype,a.billdate,a.datein as changedate,a.docno,a.doctype,
a.c_dest_id as c_store_id,a.c_store_id as c_restore_id
/*a.c_store_id,
a.c_dest_id as c_restore_id*/,null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,0 as qtyout,b.qtyin,0 as qtyother,0 as amtout,b.qtyin*b.pricelist as amtin,0 as amtother
from m_sale a,m_saleitem b
where a.id=b.m_sale_id and a.status=2 and a.out_status=2 and a.in_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_TRANSFERIN' as billtype,a.billdate,a.datein as changedate,a.docno,
a.doctype,a.c_dest_id as c_store_id,a.c_orig_id as c_restore_id,
/*,a.c_orig_id as c_store_id,
a.c_dest_id as c_restore_id*/
null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,0 as qtyout,b.qtyin,0 as qtyother,0 as amtout,b.qtyin*b.pricelist as amtin,0 as amtother
from m_transfer a,m_transferitem b
where a.id=b.m_transfer_id and a.status=2 and a.out_status=2  and a.in_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_RET_SALEIN' as billtype,a.billdate,a.datein as changedate,a.docno,a.doctype,
a.c_store_id as c_store_id,a.c_orig_id as c_restore_id,
/*a.c_orig_id as c_store_id,a.c_store_id as c_restore_id,*/
null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,0 as qtyout,b.qtyin,0 as qtyother,0 as amtout,b.qtyin*b.pricelist as amtin,0 as amtother
from m_ret_sale a,m_ret_saleitem b
where a.id=b.m_ret_sale_id and a.status=2 and a.out_status=2 and a.in_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_PURCHASEIN' as billtype,a.billdate,a.datein as changedate,a.docno,a.doctype,a.c_store_id,
null as c_restore_id
,a.c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,0 as qtyout,b.qtyin,0 as qtyother,0 as amtout,b.qtyin*b.pricelist as amtin,0 as amtother
from m_purchase a,m_purchaseitem b
where a.id=b.m_purchase_id and a.status=2 and a.in_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_V_CUSPURIN' as billtype,a.billdate,a.datein as changedate,a.docno,a.doctype,
a.c_dest_id as c_store_id,
a.c_store_id as c_restore_id,
/*a.c_store_id,
a.c_dest_id as c_restore_id,*/null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,0 as qtyout,b.qtyin,0 as qtyother,0 as amtout,b.qtyin*b.pricelist as amtin,0 as amtother
from m_sale a,m_saleitem b
where a.id=b.m_sale_id and a.status=2 and a.out_status=2 and a.in_status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_RETAIL' as billtype,a.billdate,a.billdate as changedate,a.docno,a.doctype,a.c_store_id,
null as c_restore_id,null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,b.qty as qtyout,0 as qtyin,0 as qtyother,b.qty*b.pricelist as amtout,0 as amtin,0 as amtother
from m_retail a,m_retailitem b
where a.id=b.m_retail_id and a.status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_OTHER_INOUT' as billtype,a.billdate,a.billdate as changedate,a.docno,a.doctype,a.c_store_id,
null as c_restore_id,null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,0 as qtyout,0 as qtyin,b.qty as qtyother,0 as amtout,0 as amtin,b.qty*b.pricelist as amtother
from m_other_inout a,m_other_inoutitem b
where a.id=b.m_other_inout_id and a.status=2
union all
select b.id,a.ad_client_id,a.ad_org_id,a.modifierid as ownerid,a.modifierid,a.modifieddate as creationdate,a.modifieddate,a.isactive,
'M_INVENTORY' as billtype,a.billdate,a.billdate as changedate,a.docno,a.doctype,a.c_store_id,
null as c_restore_id,null as c_supplier_id,b.m_product_id,b.m_productalias_id,b.m_attributesetinstance_id,
b.pricelist,0 as qtyout,0 as qtyin,b.qtydiff as qtyother,0 as amtout,0 as amtin,b.qtydiff*b.pricelist as amtother
from m_inventory a,m_inventoryitem b
where a.id=b.m_inventory_id and a.status=2
with read only
/

