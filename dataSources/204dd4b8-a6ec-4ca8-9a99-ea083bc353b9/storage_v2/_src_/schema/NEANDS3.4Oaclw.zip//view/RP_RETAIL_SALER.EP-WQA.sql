CREATE VIEW RP_RETAIL_SALER AS
  select count(distinct a.docno) as COUNT, a.id as ID,a.ad_client_id AS AD_CLIENT_ID,a.ad_org_id AS AD_ORG_ID,a.ownerid,a.modifierid,
a.creationdate,a.modifieddate,a.isactive,
a.billdate AS BILLDATE,a.c_store_id AS C_STORE_ID,
b.salesrep_id AS 	SALESREP_ID,
sum(b.qty) as QTY,sum(b.tot_amt_list) as AMT_LIST,sum(b.tot_amt_actual) as AMTACTUAL,a.statuserid as USERS_ID
from m_retail a,m_retailitem b
where b.m_retail_id=a.id
and a.status=2
group by a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,a.statuserid,
a.billdate,a.c_store_id,b.salesrep_id
with read only
/

