CREATE VIEW V_SERVICESAPPLY AS
  SELECT a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,a.docno,
a.billdate,a.C_STORE_ID,a.C_CUSTOMER_ID,a.C_EXPRESSCOMPANY_ID,a.FASTNO,a.STORE_CONTACTOR,a.STORE_PHONE,a.COM_CONTACTOR,
a.COM_PHONE,a.ADRESS,a.DESCRIPTION,b.M_PRODUCT_ID,b.M_PRODUCTALIAS_ID,b.ISSALE,b.QUESTION,b.QTY,b.AP_LIABILITY_ID,b.REWORKATM,
b.SHIP_ADDR,b.DEST_ADDR,b.FASTAMT,b.C_SUPPLIER_ID,b.C_VIP_ID,b.IMAGE,b.factorydate,b.m_attributesetinstance_id
FROM AP_SERVICESAPPLY a,ap_servicesapplydelitem b
WHERE a.id=b.ap_servicesapply_id
AND a.status=2
/

