CREATE VIEW B_V_RTPADJALIASITEM AS
  select a.id,t.docno,t.priority,t.begindate,t.closedate,a.c_pricearea_id,a.M_PRODUCT_ALIAS_ID,a.pricelist,a.discount,a.price,t.isactive
from B_RTPADJ t,B_RTPADJPDTALIASITEM a
where t.id=a.b_rtpadj_id
and t.status=2
and t.isactive='Y'
and t.begindate<=to_char(sysdate+1,'yyyymmdd')
and t.closedate>=to_char(sysdate,'yyyymmdd')
and (a.c_pricearea_id,a.M_PRODUCT_ALIAS_ID,substr('00000000000000000000'||DECODE(t.priority, 1, t.priority + 999999999999, t.priority),-20,20)||'-'||substr('0000000000'||t.ID,-10,10) ) in
(select a.c_pricearea_id,a.M_PRODUCT_ALIAS_ID,
MAX(substr('00000000000000000000'||DECODE(t.priority, 1, t.priority + 999999999999, t.priority),-20,20)||'-'||substr('0000000000'||t.ID,-10,10) ) over(partition  by a.c_pricearea_id,a.M_PRODUCT_ALIAS_ID)
from B_RTPADJ t,B_RTPADJPDTALIASITEM a
where t.id=a.b_rtpadj_id
and t.status=2
and t.isactive='Y'
and t.begindate<=to_char(sysdate+1,'yyyymmdd')
and t.closedate>=to_char(sysdate,'yyyymmdd')
)/* edit by Selina 2016/12/28 11:37:26 */

