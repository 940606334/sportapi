CREATE VIEW TC_ATTRIB AS
  select substr(a.dimflag,4) as attrib,a.name as AttribDefName,b.id,b.attribcode as code,b.attribname as name
from m_dimdef a, m_dim b
where a.id = b.m_dimdef_id
/

