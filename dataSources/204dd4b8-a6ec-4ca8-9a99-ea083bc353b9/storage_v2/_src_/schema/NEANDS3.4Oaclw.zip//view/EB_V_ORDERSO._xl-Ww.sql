CREATE VIEW EB_V_ORDERSO AS
  select a.id,a.ad_client_id,a.ad_org_id,a.docno,a.doctype,a.billdate,a.c_store_id,a.c_customer_id,a.c_customerup_id,a.EB_LOGIS_ID,
a.description,a.tid,a.buyer_memo,a.seller_memo,a.alipay_no,a.buyer_message,a.shipping_type,a.price,a.num,a.total_fee,
a.type,a.post_fee,a.discount_fee,a.payment,a.received_payment,a.point_fee,a.real_point_fee,a.createder,a.created,a.end_time,
a.modifieder,a.modified,a.pay_time,a.consign_time,a.receiver_address,a.receiver_city,a.receiver_district,a.receiver_phone,
a.receiver_name,a.receiver_mobile,a.receiver_state,a.receiver_zip,a.sell_status,/*a.status,*/a.out_status,a.in_status,
a.ve_status as status,a.ebsaletype,a.tid2,
a.box_status,a.shipping_fee,a.eb_orderso_id,a.mergdocno,a.splidocno,a.statuserid,a.statustime,a.ownerid,a.modifierid,a.creationdate,
a.modifieddate,a.isactive,a.boxerid,a.boxtime,a.outerid,a.outtime,a.inerid,a.intime,a.veerid,a.vetime,a.adjust_fee,a.buyer_nick buyer_nick,a.seller_tel
,a.seller_address,a.tstore,a.ctype,a.TVIRTUALID,a.ISVIRTUAL,a.FASTNO,a.SOURCE,a.c_orig_id,a.paytype,a.c_vip_id,a.integral,a.tot_amt_actual,a.qtyfcan,
a.seller_message,a.SEC_SEND
from eb_orderso a
where a.status=2 and a.isactive='Y'
/

