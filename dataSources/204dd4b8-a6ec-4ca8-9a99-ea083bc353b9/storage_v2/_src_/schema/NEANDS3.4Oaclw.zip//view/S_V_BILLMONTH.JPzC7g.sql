CREATE VIEW S_V_BILLMONTH AS
  select S_GETMONTH(billmonth) as billmonth, S_GETMONTH(billmonth) as id from
(select distinct(c1.year)||c2.month as billmonth from C_CUSPURMARK c1,C_CUSPURMARKITEM c2 where c1.id=c2.c_cuspurmark_id
group by c1.c_customer_id,c1.year,c2.month) order  by to_number(billmonth) desc
/

