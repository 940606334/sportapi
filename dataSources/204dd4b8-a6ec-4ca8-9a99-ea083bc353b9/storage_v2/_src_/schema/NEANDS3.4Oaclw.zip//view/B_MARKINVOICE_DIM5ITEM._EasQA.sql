CREATE VIEW B_MARKINVOICE_DIM5ITEM AS
  SELECT max(bma.id) id, bm.ad_client_id, bm.ad_org_id, bm.ownerid, bm.modifierid,
       bm.creationdate, bm.modifieddate, bm.isactive, bm.id AS B_MARKINVOICE_ID,
       mp.m_dim5_id AS M_DIM5_ID, SUM(bma.AMT_ACTUAL) AS AMT_ACTUAL,
       SUM(bma.AMT_INVOICE) AS AMT_INVOICE
FROM B_MARKINVOICE_AMTITEM bma, M_PRODUCT mp, B_MARKINVOICE bm
WHERE bma.m_product_id = mp.id AND bma.B_MARKINVOICE_ID = bm.id
GROUP BY bm.id, bm.ad_client_id, bm.ad_org_id, bm.ownerid, bm.modifierid,
         bm.creationdate, bm.modifieddate, bm.isactive, B_MARKINVOICE_ID, M_DIM5_ID
/

