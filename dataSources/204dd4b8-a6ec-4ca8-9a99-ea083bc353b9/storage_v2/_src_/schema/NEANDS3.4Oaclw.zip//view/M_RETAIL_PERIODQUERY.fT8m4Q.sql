CREATE VIEW M_RETAIL_PERIODQUERY AS
  select max(a.id) as id,a.billdate,a.c_store_id,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '000000' and
                             '005959'
       ) as AMT_ACTUAL1,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '010000' and
                             '015959'
       ) as AMT_ACTUAL2,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '020000' and
                             '025959'
       ) as AMT_ACTUAL3,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '030000' and
                             '035959'
       ) as AMT_ACTUAL4,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '040000' and
                             '045959'
       ) as AMT_ACTUAL5,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '050000' and
                             '055959'
       ) as AMT_ACTUAL6,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '060000' and
                             '065959'
       ) as AMT_ACTUAL7,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '070000' and
                             '075959'
       ) as AMT_ACTUAL8,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '080000' and
                             '085959'
       ) as AMT_ACTUAL9,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '090000' and
                             '095959'
       ) as AMT_ACTUAL10,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '100000' and
                             '105959'
       ) as AMT_ACTUAL11,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '110000' and
                             '115959'
       ) as AMT_ACTUAL12,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '120000' and
                             '125959'
       ) as AMT_ACTUAL13,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '130000' and
                             '135959'
       ) as AMT_ACTUAL14,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '140000' and
                             '145959'
       ) as AMT_ACTUAL15,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '150000' and
                             '155959'
       ) as AMT_ACTUAL16,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '160000' and
                             '165959'
       ) as AMT_ACTUAL17,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '170000' and
                             '175959'
       ) as AMT_ACTUAL18,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '180000' and
                             '185959'
       ) as AMT_ACTUAL19,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '190000' and
                             '195959'
       ) as AMT_ACTUAL20,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '200000' and
                             '205959'
       ) as AMT_ACTUAL21,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '210000' and
                             '215959'
       ) as AMT_ACTUAL22,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '220000' and
                             '225959'
       ) as AMT_ACTUAL23,
       (select nvl(sum(b.tot_amt_actual),0)
        from m_retail b
        where b.billdate=a.billdate and b.c_store_id=a.c_store_id and b.status=2 and
              substr(to_char(b.creationdate,'yyyymmddhh24miss'),-6) between '230000' and
                             '235959'
       ) as AMT_ACTUAL24
from m_retail a
where a.status=2
group by a.billdate,a.c_store_id
/

