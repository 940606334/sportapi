CREATE VIEW M_ASSIGN_PRO_ITEM AS
  select sameproduct_id as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,m_assign_id,m_product_id,
max(autoqty) as autoqty , sum(origqtycan) as origqtycan,sum(occurqty) as occurqty,sum(qty_assi) as qty_assi
from m_assignitem
group by sameproduct_id,ad_client_id,ad_org_id,m_assign_id,m_product_id
/

