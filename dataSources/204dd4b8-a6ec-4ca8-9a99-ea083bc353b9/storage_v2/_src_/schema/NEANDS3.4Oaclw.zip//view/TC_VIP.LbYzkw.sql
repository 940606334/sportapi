CREATE VIEW TC_VIP AS
  SELECT t.id as disc_type ,t.description as type_name FROM   	 C_VIPTYPE t
/

