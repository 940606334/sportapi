CREATE VIEW M_RETSALE_PRO_ITEM AS
  select max(ID) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
M_RET_SALE_ID  as M_RET_SALE_ID ,m_product_id,max(orderno) as orderno,	STATUS,OUT_STATUS ,in_status,
sum(qty) as qty,sum(qtyout) as qtyout,sum(qtyin) as qtyin,sum(QTYDIFF) as QTYDIFF,round(avg(pricelist)) as pricelist,round(avg(PRICEACTUAL),2) as PRICEACTUAL,
round(avg(DISCOUNT),2) as DISCOUNT,sum(TOT_AMT_LIST) as TOT_AMT_LIST ,sum(TOT_AMT_ACTUAL) as TOT_AMT_ACTUAL
,sum(TOT_AMTOUT_ACTUAL) as TOT_AMTOUT_ACTUAL,sum(TOT_AMTIN_ACTUAL) as TOT_AMTIN_ACTUAL,min(	HISTORY_MINDIS) as 	HISTORY_MINDIS
from M_RET_SALEITEM
group by ad_client_id,ad_org_id,M_RET_SALE_ID ,m_product_id ,STATUS,OUT_STATUS ,in_status
/

