CREATE VIEW M_PDT_PRICE AS
  select 'AREA' as c_pricearea_id,id as m_product_id,name as pdtname,pricelist,m_dim2_id from m_product
/

