CREATE VIEW RP_PUR_PAY AS
  select h.id,h.ad_client_id,h.ad_org_id,h.ownerid,h.modifierid,h.creationdate,h.modifiedate,h.isactive,
h.c_supplier_id,g.m_product_id,
g.qtyso,g.qtypur,g.qtyretpur,g.amtso,g.amtpur,g.amtretpur,g.qtydiff,g.amtdiff,g.soqtydiff,g.soamtdiff,
h.befpay,h.payment,h.amtpay,h.amt_payable,h.amt_dopay,h.amtvoice,h.amt_novoice
from
( select d.ad_client_id,d.ad_org_id,d.c_supplier_id,d.m_product_id,
sum(d.qtyso) as qtyso,sum(nvl(d.qtypur,0)) as qtypur,sum(nvl(d.qtyretpur,0)) as qtyretpur,
sum(d.amtso) as amtso,sum(nvl(d.amtpur,0)) as amtpur,sum(nvl(d.amtretpur,0)) as amtretpur,
(sum(d.qtyso) - sum(nvl(d.qtypur,0)) + sum(nvl(d.qtyretpur,0)) ) as qtydiff, --差异数量＝订单量－到货量＋退货量
(sum(d.amtso) - sum(nvl(d.amtpur,0)) + sum(nvl(d.amtretpur,0)) ) as amtdiff,
(sum(d.qtyso) - sum(nvl(d.qtypur,0)) ) as soqtydiff, --发货差异量＝订单量－到货量
(sum(d.amtso) - sum(nvl(d.amtpur,0)) ) as soamtdiff
from
(select a.ad_client_id,a.ad_org_id,a.c_supplier_id,b.m_product_id,b.m_attributesetinstance_id,b.qty as qtyso,0 as qtypur,0 as qtyretpur,
 b.tot_amt_actual as amtso,0 as amtpur,0 as amtretpur
 from b_po a,b_poitem b
where a.id = b.b_po_id
and a.status = 2
and a.close_status <> 2
union
select c.ad_client_id,c.ad_org_id,c.c_supplier_id,c.m_product_id,c.M_ATTRIBUTESETINSTANCE_ID,0 as qtyso,nvl(c.qtypur,0) as qtypur,
nvl(c.qtyretpur,0) as qtyretpur,0 as amt_so,nvl(c.TOT_AMTIN_PCHECK,0) as amtpur,nvl(c.amtretpur,0) as amtretpur
from rp_purchase001 c) d
group by d.ad_client_id,d.ad_org_id,d.c_supplier_id,d.m_product_id ) g,

( select f.id,f.ad_client_id,f.ad_org_id,f.ownerid,f.modifierid,f.creationdate,f.modifiedate,f.isactive,
f.c_supplier_id,nvl(e.befpay,0) as befpay,nvl(e.payment,0) as payment,
nvl(e.amtpay,0) as amtpay,f.amt_payable,(f.amt_payable-nvl(e.amtpay,0)) as amt_dopay,
f.amtvoice,(nvl(e.amtpay,0)-f.amtvoice) as amt_novoice
from
(select d.ad_client_id,d.ad_org_id,d.c_supplier_id,
sum(d.befpay) as befpay,sum(payment) as payment, (sum(d.befpay)+sum(payment) ) as amtpay
from
(select a.ad_client_id,a.ad_org_id,a.c_supplier_id,a.tot_amt_actual as befpay,0 as payment from b_pay a,c_feetype b
where a.c_feetype_id = b.id
and b.name like '预付%'
and a.status = 2
union
select a.ad_client_id,a.ad_org_id,a.c_supplier_id,0 as befpay,a.tot_amt_actual as payment from b_pay a,c_feetype b
where a.c_feetype_id = b.id
and b.name not like '预付%'
and a.status = 2) d
group by d.ad_client_id,d.ad_org_id,d.c_supplier_id ) e,
(select max(c.id) as id,c.ad_client_id,c.ad_org_id,max(c.ownerid) as ownerid,max(c.modifierid) as modifierid,
max(c.creationdate) as creationdate,max(c.modifieddate) as modifiedate,'Y' as isactive,
c.c_supplier_id,sum(c.amt_payable) as amt_payable,
sum(amt_pay) as amt_pay,sum(amtvoice) as amtvoice
from
(select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,
a.c_supplier_id,a.amt_payable,a.amt_pay,0 as amtvoice from fa_supplier a
union
select max(b.id) as id,b.ad_client_id,b.ad_org_id,max(b.ownerid) as ownerid,max(b.modifierid) as modifierid,
max(b.creationdate) as creationdate,max(b.modifieddate) as modifiedate,'Y' as isactive,
b.c_supplier_id,0 as amt_payable,0 as amt_pay,sum(b.tot_amt_actual) as amtvoice
from b_supinvoice b
where b.status = 2
group by b.ad_client_id,b.ad_org_id,b.c_supplier_id) c
group by c.ad_client_id,c.ad_org_id,c.c_supplier_id) f
where e.ad_client_id(+) = f.ad_client_id
and e.ad_org_id(+) = f.ad_org_id
and e.c_supplier_id(+) = f.c_supplier_id ) h
where g.c_supplier_id(+) = h.c_supplier_id
with read only
/

