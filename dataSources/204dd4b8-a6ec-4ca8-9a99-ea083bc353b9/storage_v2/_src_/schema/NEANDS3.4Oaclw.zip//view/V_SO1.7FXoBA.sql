CREATE VIEW V_SO1 AS
  select a.c_store_id, b.m_product_id, b.m_attributesetinstance_id,
        nvl(sum(b.qtyrem),0) as qtyconsign
 from b_so a, b_soitem b
 where a.doctype = 'FWD' and a.status = 2 and a.close_status = nvl(1,uid) and
       a.id = b.b_so_id
 group by a.c_store_id, b.m_product_id, b.m_attributesetinstance_id
/

