CREATE VIEW M_PDTALIAS_INC AS
  select a.id as m_pdtalias_id,a.no,a.forcode,b.name as pdtname,b.value as pdtvalue,b.id as m_product_id,
c.value1_id as m_color_id,c.value2_id as m_size_id,e.no as old_no,b.m_dim2_id,a.creationdate
from m_product_alias a,m_product b,m_attributesetinstance c,m_pdt_alias_con d,m_product_alias e,m_dim m
where a.m_product_id = b.id
and a.m_attributesetinstance_id = c.id
and a.id = d.m_pda_new_id(+)
and d.m_pda_old_id = e.id(+)
and b.m_dim2_id=m.id
and m.attribcode=to_char(sysdate,'yyyy')

/

