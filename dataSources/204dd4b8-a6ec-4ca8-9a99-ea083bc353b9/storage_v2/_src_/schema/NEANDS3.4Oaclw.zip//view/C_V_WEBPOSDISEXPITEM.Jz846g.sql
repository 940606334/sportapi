CREATE VIEW C_V_WEBPOSDISEXPITEM AS
  select a.id,a.c_webposdis_id,GET_FITLER_SQL(a.exproduct_filter) as exproduct_filter,
       a.qty,a.relationtype,a.relatetype,a.comparetypeamt,a.amt
from C_WEBPOSDIS t,C_WEBPOSDISEXPITEM a
where t.id=a.c_webposdis_id
and t.isactive='Y' and t.close_status=1
and t.STATUS = 2
and  to_char(sysdate+1+nvl(KEEP_DAYS,0),'yyyymmdd')>=DATEBEGIN
and to_char(sysdate,'yyyymmdd')<=DATEEND/* edit by Selina 2017/7/4 15:56:18 */

