CREATE VIEW RP_B_SO AS
  select c.id ,c.ad_client_id,c.ad_org_id,c.ownerid,c.modifierid,c.creationdate,c.modifieddate,c.isactive,
 c.no,c.m_product_id,c.m_attributesetinstance_id,
 c.docno,c.C_DEST_ID,c.C_CUSTOMER_ID,c.C_STORE_ID ,c.C_CUSTOMERUP_ID ,nvl(c.qty,0)qty ,nvl(d.qty,0) qty_storage,
 d.qtycan as  qtyfcan
 from (
  select b.id, a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,
  e.no,b.m_product_id,b.m_attributesetinstance_id,
  a.docno,a.C_DEST_ID,a.C_CUSTOMER_ID,a.C_STORE_ID , a.C_CUSTOMERUP_ID ,b.qty
  from  B_SO a,b_soitem b,m_product_alias e
  where a.id=b.b_so_id and a.status=2
  and b.m_product_id=e.m_product_id and b.m_attributesetinstance_id=e.m_attributesetinstance_id) c
 left join  v_FA_STORAGE_can d
 on c.m_product_id=d.m_product_id and c.m_attributesetinstance_id=d.m_attributesetinstance_id
 and c.C_STORE_ID=d.C_STORE_ID
 with read only
/

