CREATE VIEW M_OUTOVER AS
  select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,
a.MODIFIEDDATE,a.ISACTIVE,'M_SALE'as billtype, a.DOCNO,a.DOCTYPE,a.BILLDATE,
a.C_CUSTOMERUP_ID,a.C_CUSTOMER_ID,c.name as origname,b.name as destname,
a.DESCRIPTION,a.DIFFREASON,a.BOX_STATUS,
a.status,a.OUT_STATUS,a.IN_STATUS,a.AU_STATE,a.AU_PI_ID,a.AVG_DISCOUNT,a.TOT_LINES,a.TOT_QTY,
a.TOT_AMT_LIST,a.TOT_AMT_ACTUAL,a.TOT_QTYOUT,a.TOT_AMTOUT_LIST,a.TOT_AMTOUT_ACTUAL,
a.tot_qtyin,a.tot_amtin_list,a.tot_amtin_actual,
a.DATEOUT,a.DATEIN,a.STATUSERID,a.STATUSTIME,a.OUTERID,a.OUTTIME,a.INERID,a.INTIME,
a.C_SALETYPE_ID as TYPE_ID,a.SALETYPE as DEALTYPE
from m_sale a,c_store b, c_store c
where a.c_store_id = c.id
and a.c_dest_id = b.id
and a.STATUS =2 and a.OUT_STATUS =2 and a.in_status = 2
union
select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,
a.MODIFIEDDATE,a.ISACTIVE,'M_RET_SALE'as billtype, a.DOCNO,a.DOCTYPE,a.BILLDATE,
a.C_CUSTOMERUP_ID,a.C_CUSTOMER_ID,c.name as origname,b.name as destname,
a.DESCRIPTION,a.DIFFREASON,a.BOX_STATUS,
a.status,a.OUT_STATUS,a.IN_STATUS,a.AU_STATE,a.AU_PI_ID,a.AVG_DISCOUNT,a.TOT_LINES,a.TOT_QTY,
a.TOT_AMT_LIST,a.TOT_AMT_ACTUAL,a.TOT_QTYOUT,a.TOT_AMTOUT_LIST,a.TOT_AMTOUT_ACTUAL,
a.tot_qtyin,a.tot_amtin_list,a.tot_amtin_actual,
a.DATEOUT,a.DATEIN,a.STATUSERID,a.STATUSTIME,a.OUTERID,a.OUTTIME,a.INERID,a.INTIME,
a.C_RET_SALETYPE_ID as TYPE_ID,a.RETSALETYPE as DEALTYPE
from m_ret_sale a,c_store b,c_store c
where a.c_orig_id = c.id
and a.c_store_id = b.id
and a.STATUS =2 and a.OUT_STATUS =2 and a.in_status = 2
union
select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,
a.MODIFIEDDATE,a.ISACTIVE,'M_TRANSFER'as billtype,a.DOCNO,a.DOCTYPE,a.BILLDATE,
a.C_CUSTOMER_ID as C_CUSTOMERUP_ID,a.C_CUSTOMER_ID,c.name as origname,b.name as destname,
a.DESCRIPTION,a.DIFFREASON,a.BOX_STATUS,
a.status,a.OUT_STATUS,a.IN_STATUS,a.AU_STATE,a.AU_PI_ID,null as AVG_DISCOUNT,a.TOT_LINES,a.TOT_QTY,
a.TOT_AMTQTY_LIST as TOT_AMT_LIST,null as TOT_AMT_ACTUAL,a.TOT_QTYOUT,a.TOT_AMTOUT_LIST,null as TOT_AMTOUT_ACTUAL,
a.tot_qtyin,a.tot_amtin_list,null as tot_amtin_actual,
a.DATEOUT,a.DATEIN,a.STATUSERID,a.STATUSTIME,a.OUTERID,a.OUTTIME,a.INERID,a.INTIME,
a.C_TRANSFERTYPE_ID as TYPE_ID,a.TRANSFERTYPE as DEALTYPE
from m_transfer a,c_store b,c_store c
where a.c_orig_id = c.id
and a.c_dest_id=b.id
and a.STATUS =2 and a.OUT_STATUS =2 and a.in_status = 2
union
select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,
a.MODIFIEDDATE,a.ISACTIVE,'M_V_CUSRET_PUR'as billtype, a.DOCNO,a.DOCTYPE,a.BILLDATE,
a.C_CUSTOMERUP_ID,a.C_CUSTOMER_ID,c.name as origname,b.name as destname,
a.DESCRIPTION,a.DIFFREASON,a.BOX_STATUS,
a.status,a.OUT_STATUS,a.IN_STATUS,a.AU_STATE,a.AU_PI_ID,a.AVG_DISCOUNT,a.TOT_LINES,a.TOT_QTY,
a.TOT_AMT_LIST,a.TOT_AMT_ACTUAL,a.TOT_QTYOUT,a.TOT_AMTOUT_LIST,a.TOT_AMTOUT_ACTUAL,
a.tot_qtyin,a.tot_amtin_list,a.tot_amtin_actual,
a.DATEOUT,a.DATEIN,a.STATUSERID,a.STATUSTIME,a.OUTERID,a.OUTTIME,a.INERID,a.INTIME,
a.C_RET_SALETYPE_ID as TYPE_ID,a.RETSALETYPE as DEALTYPE
from m_ret_sale a,c_store b,c_store c
where a.c_orig_id = c.id
and a.c_store_id = b.id
and a.STATUS =2 and a.OUT_STATUS =2 and a.in_status = 2
union
select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,
a.MODIFIEDDATE,a.ISACTIVE,'M_V_CUSPUR'as billtype, a.DOCNO,a.DOCTYPE,a.BILLDATE,
a.C_CUSTOMERUP_ID,a.C_CUSTOMER_ID,c.name as origname,b.name as destname,
a.DESCRIPTION,a.DIFFREASON,a.BOX_STATUS,
a.status,a.OUT_STATUS,a.IN_STATUS,a.AU_STATE,a.AU_PI_ID,a.AVG_DISCOUNT,a.TOT_LINES,a.TOT_QTY,
a.TOT_AMT_LIST,a.TOT_AMT_ACTUAL,a.TOT_QTYOUT,a.TOT_AMTOUT_LIST,a.TOT_AMTOUT_ACTUAL,
a.tot_qtyin,a.tot_amtin_list,a.tot_amtin_actual,
a.DATEOUT,a.DATEIN,a.STATUSERID,a.STATUSTIME,a.OUTERID,a.OUTTIME,a.INERID,a.INTIME,
a.C_SALETYPE_ID as TYPE_ID,a.SALETYPE as DEALTYPE
from m_sale a,c_store b, c_store c
where a.c_store_id = c.id
and a.c_dest_id = b.id
and a.STATUS =2 and a.OUT_STATUS =2 and a.in_status = 2
union
select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,
a.MODIFIEDDATE,a.ISACTIVE,'M_RET_PUR'as billtype, a.DOCNO,a.DOCTYPE,a.BILLDATE,
null as C_CUSTOMERUP_ID,null as C_CUSTOMER_ID,c.name as origname,b.name as destname,
a.DESCRIPTION,a.DIFFREASON,a.BOX_STATUS,
a.status,OUT_STATUS,2 as IN_STATUS,a.AU_STATE,a.AU_PI_ID,a.AVG_DISCOUNT,a.TOT_LINES,TOT_QTY,
a.TOT_AMT_LIST,a.TOT_AMT_ACTUAL,a.TOT_QTYOUT,a.TOT_AMTOUT_LIST,a.TOT_AMTOUT_ACTUAL,
null as tot_qtyin,null as tot_amtin_list,null as tot_amtin_actual,
a.DATEOUT,a.DATEIN,a.STATUSERID,a.STATUSTIME,a.OUTERID,a.OUTTIME,a.INERID,a.INTIME,
null as TYPE_ID,null as DEALTYPE
from m_ret_pur a, c_supplier b, c_store c
where a.c_store_id = c.id
and a.c_supplier_id = b.id
and a.STATUS =2 and a.OUT_STATUS =2
union
select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,
a.MODIFIEDDATE,a.ISACTIVE,'M_PURCHASE'as billtype, a.DOCNO,a.DOCTYPE,a.BILLDATE,
null as C_CUSTOMERUP_ID,null as C_CUSTOMER_ID,b.name as origname,c.name as destname,
a.DESCRIPTION,a.DIFFREASON,1 as BOX_STATUS,
a.status,2 as OUT_STATUS,IN_STATUS,a.AU_STATE,a.AU_PI_ID,a.AVG_DISCOUNT,a.TOT_LINES,TOT_QTY,
a.TOT_AMT_LIST,a.TOT_AMT_ACTUAL,null as TOT_QTYOUT,null as TOT_AMTOUT_LIST,null as TOT_AMTOUT_ACTUAL,
a.tot_qtyin,a.tot_amtin_list,a.tot_amtin_actual,
a.DATEOUT,a.DATEIN,a.STATUSERID,a.STATUSTIME,null as OUTERID,null as OUTTIME,a.INERID,a.INTIME,
null as TYPE_ID,null as DEALTYPE
from m_purchase a, c_supplier b, c_store c
where a.c_store_id=c.id
and a.c_supplier_id = b.id
and a.STATUS =2 and a.in_status = 2
/

