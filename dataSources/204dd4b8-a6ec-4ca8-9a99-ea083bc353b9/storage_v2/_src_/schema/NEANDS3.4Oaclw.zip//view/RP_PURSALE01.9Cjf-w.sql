CREATE VIEW RP_PURSALE01 AS
  select "ID","AD_CLIENT_ID","MODIFIERID","MODIFIEDDATE","ISACTIVE","BILLDATE","M_PRODUCT_ID","M_ATTRIBUTESETINSTANCE_ID",
"C_STORE_ID","PRICELIST","PERCOST","PO_QTY","QTYIN","QTYOUT","M_PRODUCT_ALIAS_ID" from (
select a.id,
       a.ad_client_id,
       a.modifierid,
       a.modifieddate,
       a.isactive,
       a.billdate,
       b.m_product_id,
       b.m_attributesetinstance_id,
       a.c_store_id,
        b.pricelist,
        nvl(c.percost,0) as percost,
        qty as po_qty,
        0 as qtyin,
       0 as qtyout,
       b.m_productalias_id as M_PRODUCT_ALIAS_id
  from b_po a,
       b_poitem b,fa_product_cost c
 where b.b_po_id=a.id and a.status=2  and b.m_product_id=c.m_product_id(+)
  union
select a.id,
       a.ad_client_id,
       a.modifierid,
       a.modifieddate,
       a.isactive,
        a.datein as billdate,
       b.m_product_id,
       b.m_attributesetinstance_id,
       a.c_store_id,
        b.pricelist,
        nvl(c.percost,0) as percost,
        0 as po_qty,
       nvl(b.qtyin,0) as qtyin,
       0 as qtyout,
       b.m_productalias_id as M_PRODUCT_ALIAS_id
  from m_purchase a,
       m_purchaseitem b,fa_product_cost c
 where b.m_purchase_id=a.id and a.in_status=2  and b.m_product_id=c.m_product_id(+)
  union
select a.id,
       a.ad_client_id,
       a.modifierid,
       a.modifieddate,
       a.isactive,
        a.dateout as billdate,
       b.m_product_id,
       b.m_attributesetinstance_id,
       a.c_store_id,
        b.pricelist,
        nvl(c.percost,0) as percost,
        0 as po_qty,
       -nvl(b.qtyout,0) as qtyin,
       0 as qtyout,
       b.m_productalias_id as M_PRODUCT_ALIAS_id
  from m_ret_pur a,
       m_ret_puritem b,fa_product_cost c
 where b.m_ret_pur_id=a.id and a.out_status=2  and b.m_product_id=c.m_product_id(+)
  union
 select a.id,
        a.ad_client_id,
        a.modifierid,
         a.modifieddate,
        a.isactive,
        a.dateout as billdate,
      b.m_product_id,
      b.m_attributesetinstance_id,
        a.c_store_id,
        b.pricelist,
         nvl(c.percost,0) as percost,
         0 as po_qty,
        0 as qtyin,
        nvl(b.qty,0) as qtyout,
        b.m_productalias_id as M_PRODUCT_ALIAS_id
   from m_retail a,
        m_retailitem b,fa_product_cost c
  where a.id = b.m_retail_id and a.status=2 and b.m_product_id=c.m_product_id(+)
 union
 select a.id,
        a.ad_client_id,
        a.modifierid,
         a.modifieddate,
        a.isactive,
        a.dateout as billdate,
      b.m_product_id,
      b.m_attributesetinstance_id,
        a.c_orig_id as c_store_id,
        b.pricelist,
         nvl(c.percost,0) as percost,
         0 as po_qty,
        0 as qtyin,
        nvl(b.qtyout,0) as qtyout,
        b.m_productalias_id M_PRODUCT_ALIAS_id
   from m_transfer a,
        m_transferitem b,fa_product_cost c
  where a.id = b.m_transfer_id and a.out_status=2 and b.m_product_id=c.m_product_id(+)
 union
 select a.id,
        a.ad_client_id,
        a.modifierid,
         a.modifieddate,
        a.isactive,
        a.dateout as billdate,
      b.m_product_id,
      b.m_attributesetinstance_id,
        a.c_store_id,
        b.pricelist,
         nvl(c.percost,0) as percost,
         0 as po_qty,
        0 as qtyin,
        nvl(b.qtyout,0) as qtyout,
        b.m_productalias_id as M_PRODUCT_ALIAS_id
   from m_sale a,
        m_saleitem b,fa_product_cost c
  where a.id = b.m_sale_id and a.out_status=2 and b.m_product_id=c.m_product_id(+)
   union
 select a.id,
        a.ad_client_id,
        a.modifierid,
         a.modifieddate,
        a.isactive,
        a.datein as billdate,
      b.m_product_id,
      b.m_attributesetinstance_id,
        a.c_dest_id as c_store_id,
        b.pricelist,
         nvl(c.percost,0) as percost,
         0 as po_qty,
        0 as qtyin,
        -nvl(b.qtyin,0) as qtyout,
        b.m_productalias_id as M_PRODUCT_ALIAS_id
   from m_transfer a,
        m_transferitem b,fa_product_cost c
  where a.id = b.m_transfer_id and a.in_status=2 and b.m_product_id=c.m_product_id(+)
     union
 select a.id,
        a.ad_client_id,
        a.modifierid,
         a.modifieddate,
        a.isactive,
        a.datein as billdate,
      b.m_product_id,
      b.m_attributesetinstance_id,
        a.c_store_id ,
        b.pricelist,
         nvl(c.percost,0) as percost,
         0 as po_qty,
        0 as qtyin,
        -nvl(b.qtyin,0) as qtyout,
        b.m_productalias_id as M_PRODUCT_ALIAS_id
   from m_ret_sale a,
        m_ret_saleitem b,fa_product_cost c
  where a.id = b.m_ret_sale_id and a.in_status=2 and b.m_product_id=c.m_product_id(+)
  ) t
/

