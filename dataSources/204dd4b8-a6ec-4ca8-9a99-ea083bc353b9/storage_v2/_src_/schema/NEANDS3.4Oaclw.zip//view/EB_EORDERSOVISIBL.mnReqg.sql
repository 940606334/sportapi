CREATE VIEW EB_EORDERSOVISIBL AS
  select 1 as id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,
       sysdate as creationdate,sysdate as modifieddate,a.isactive,
       '可合并网店订单信息' as REMARK, to_char(sysdate,'YYYY-MM-DD hh24:mi:ss') as billdate
from EB_ORDERSO a
where rownum = 1  and a.ad_client_id=37
/

