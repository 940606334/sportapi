CREATE VIEW M_PURIN_BOXITEM AS
  select id,ad_client_id ,ad_org_id ,m_purnotice_id,boxno,m_productalias_id,
    m_product_id,qty,m_attributesetinstance_id,ownerid,modifierid,creationdate,
    modifieddate,isactive
from m_purnotice_boxitem
/

