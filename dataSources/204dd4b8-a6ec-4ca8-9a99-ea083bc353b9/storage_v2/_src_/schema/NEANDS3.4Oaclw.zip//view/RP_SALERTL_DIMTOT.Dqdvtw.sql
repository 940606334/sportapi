CREATE VIEW RP_SALERTL_DIMTOT AS
  select a.id,
       a.ad_client_id,
       a.ad_org_id,
       a.ownerid,
       a.modifierid,
       a.creationdate,
       a.modifieddate,
       a.isactive,
       a.c_customer_id,
       a.c_dest_id,
       b.m_product_id,
       b.qtyout as qty_soo,
       0 as qty_sio,
       0 as qty_suo,
       0 as qty_rtl
  from m_sale a, m_saleitem b
 where a.id = b.m_sale_id
   and a.out_status = 2
   and a.docno = 'SOO'
union
select a.id,
       a.ad_client_id,
       a.ad_org_id,
       a.ownerid,
       a.modifierid,
       a.creationdate,
       a.modifieddate,
       a.isactive,
       a.c_customer_id,
       a.c_dest_id,
       b.m_product_id,
       0 as qty_soo,
       b.qtyout as qty_sio,
       0 as qty_suo,
       0 as qty_rtl
  from m_sale a, m_saleitem b
 where a.id = b.m_sale_id
   and a.out_status = 2
   and a.docno = 'SIO'
union
select a.id,
       a.ad_client_id,
       a.ad_org_id,
       a.ownerid,
       a.modifierid,
       a.creationdate,
       a.modifieddate,
       a.isactive,
       a.c_customer_id,
       a.c_dest_id,
       b.m_product_id,
       0 as qty_soo,
       0 as qty_sio,
       b.qtyout as qty_suo,
       0 as qty_rtl
  from m_sale a, m_saleitem b
 where a.id = b.m_sale_id
   and a.out_status = 2
   and a.docno = 'SUO'
union
select a.id,
       a.ad_client_id,
       a.ad_org_id,
       a.ownerid,
       a.modifierid,
       a.creationdate,
       a.modifieddate,
       a.isactive,
       a.c_customer_id,
       a.c_store_id as c_dest_id,
       b.m_product_id,
       0 as qty_soo,
       0 as qty_sio,
       0 as qty_suo,
       b.qty as qty_rtl
  from m_retail a, m_retailitem b
 where a.id = b.m_retail_id
   and a.status = 2
/

