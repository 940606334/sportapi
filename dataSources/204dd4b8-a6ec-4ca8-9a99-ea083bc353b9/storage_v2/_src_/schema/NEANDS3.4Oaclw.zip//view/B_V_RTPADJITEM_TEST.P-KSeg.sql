CREATE VIEW B_V_RTPADJITEM_TEST AS
  select a.id,t.docno,t.priority,t.begindate,t.closedate,a.c_pricearea_id,a.m_product_id,a.pricelist,a.discount,a.price,t.isactive
from B_RTPADJ t,B_RTPADJitem a,m_product c
where t.id=a.b_rtpadj_id
and t.status=2
and t.isactive='Y'
and t.begindate<=to_char(sysdate,'yyyymmdd')
and t.closedate>=to_char(sysdate,'yyyymmdd')
and (a.c_pricearea_id,a.m_product_id,substr('00000000000000000000'||priority,-20,20)||'-'||TO_CHAR(t.statustime,'YYYY-MM-DD HH24:MI:SS')) in
(select a.c_pricearea_id,a.m_product_id,
MAX(substr('00000000000000000000'||priority,-20,20)||'-'||TO_CHAR(statustime,'YYYY-MM-DD HH24:MI:SS')) over(partition  by c_pricearea_id,a.m_product_id)
from B_RTPADJ t,B_RTPADJitem a
where t.id=a.b_rtpadj_id
and t.status=2
and t.isactive='Y'
and t.begindate<=to_char(sysdate,'yyyymmdd')
and t.closedate>=to_char(sysdate,'yyyymmdd') )
/

