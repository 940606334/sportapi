CREATE VIEW V_TDEFATTRIB AS
  select a.dimflag,a.name as AttribDefName,b.id as m_dim_id,b.attribname from m_dimdef a, m_dim b
where a.id = b.m_dimdef_id
/

