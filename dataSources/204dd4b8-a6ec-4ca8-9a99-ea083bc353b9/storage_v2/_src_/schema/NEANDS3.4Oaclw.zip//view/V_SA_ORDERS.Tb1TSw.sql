CREATE VIEW V_SA_ORDERS AS
  SELECT b.id,
       a.docno||'-'||b.id AS orderid,
       (SELECT decode(c_suppliertype_id, 13, '02', '01')
        FROM c_supplier
        WHERE id = a.c_supplier_id) AS sale_style,
       d.code AS contactnum,
       a.statustime AS orderdate,
       e.name AS poster,
       c.addr AS deliveryplace,
       a.description AS summary,
       decode(c.doctype,'FWD',1,0) AS isproxy,
       CASE
         WHEN c.c_realstore_id IS NULL THEN
          (SELECT code FROM c_store WHERE id = c.c_dest_id)
         ELSE
          (SELECT k.code
           FROM c_store k
           WHERE k.id = c.c_realstore_id)
       END AS subcontactnum,0 as IMPORTED
FROM b_po a, b_poboxitem b, b_so c, c_customer d, users e
WHERE a.id = b.b_po_id
AND b.b_so_id = c.id
AND c.c_customer_id = d.id
AND a.statuserid = e.id
     --and a.statustime >sysdate-7
AND a.status = 2
/

