CREATE VIEW Y_PUR_CHECK AS
  SELECT id, ad_client_id, ad_org_id, docno, list_type, billdate, datein,
       datasource, deliverydate, y_supplier_id, y_warehouse_id, y_plan_id,
       loss_rate, more_rate, address, remark, tot_qty, tot_qtyin, tot_famount,
       tot_famountin, in_status, au_state, au_pi_id, ownerid, creationdate,
       inerid, intime, modifierid, modifieddate, isactive, m_dim1_id,
       involveproduct, oc_status, ocer, octime, tax_dis, pricemodify, pck_status,
       pcheckid, pchecktime, tot_famountin_pcheck, tot_famountin_dec,
       tot_famountin_fee, tot_famountin_pchecktax, check_status AS status,
       checkerid AS statuserid, checktime AS statustime, datewh, tot_qtyinved,
       tot_amtinved, isback, b_bwmtlpuraccount_id, is_towms, tot_fgood_qty,
       tot_good_qty, tot_defect_qty
FROM y_purchase
WHERE status = 2
/

