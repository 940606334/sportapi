CREATE VIEW C_V_WEBPOSDISEXAITEM AS
  select a.id,a.c_webposdis_id,a.m_productalias_id,a.qty,a.relationtype
       ,a.relatetype,a.comparetypeamt,a.AMT
from 	C_WEBPOSDIS t,C_WEBPOSDISEXAITEM a
where t.id=a.c_webposdis_id
and t.isactive='Y' and t.close_status=1
and t.STATUS = 2
and to_char(sysdate+1+nvl(KEEP_DAYS,0),'yyyymmdd')>=DATEBEGIN
and to_char(sysdate,'yyyymmdd')<=DATEEND/* edit by Selina 2017/7/4 15:56:31 */

