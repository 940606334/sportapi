CREATE VIEW RP_SORETAIL_ORDER_CP AS
  select b.id ,a.ad_client_id ,a.ad_org_id ,a.c_dest_id c_store_id,a.c_customer_id,b.m_product_id,
       b.m_attributesetinstance_id,a.billdate,a.docno ,b.qty qty_so,0 qty_sale,a.isactive
from b_so a ,b_soitem b
where a.id=b.b_so_id and a.status=2
union all
select b.id id,a.ad_client_id ,a.ad_org_id ,a.c_store_id,a.c_customer_id,b.m_product_id,
       b.m_attributesetinstance_id, a.billdate,a.docno ,0 qty_so,b.qty qty_sale,a.isactive
from m_retail a,m_retailitem b
where a.id=b.m_retail_id and a.status=2
/

