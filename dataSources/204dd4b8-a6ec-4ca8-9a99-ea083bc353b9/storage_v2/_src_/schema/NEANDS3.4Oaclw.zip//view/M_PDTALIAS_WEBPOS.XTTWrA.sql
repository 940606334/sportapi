CREATE VIEW M_PDTALIAS_WEBPOS AS
  select a.ID,a.NO,a.FORCODE ,b.id as M_PRODUCT_ID,b.name as PDTNAME,b.value as PDTVALUE,
c.VALUE1_ID,c.VALUE2_ID,c.VALUE1,c.VALUE2,c.VALUE1_CODE,c.VALUE2_CODE
from m_product_alias a,m_product b,m_attributesetinstance c
where a.m_product_ID = b.ID
and a.m_attributesetinstance_ID=c.ID
and a.ISACTIVE ='Y'
and b.ISACTIVE ='Y'
/

