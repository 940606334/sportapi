CREATE VIEW RP_V_HISSTORAGE01 AS
  select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.creationdate,a.modifierid,a.modifieddate,a.isactive,
b.yearmonth,b.c_customer_id,a.c_store_id,a.m_product_id,c.ACOST,c.PRICEDIS,a.qtyend as total,
c.ACOST*a.qtyend as AMT_ACOST,c.pricedis*a.qtyend as AMT_PRICEDIS,a.costend
from fa_monthstore a,c_period b,m_product c
where a.c_period_id=b.id
  and b.ismonthsum='Y'
  and a.m_product_id=c.id
/

