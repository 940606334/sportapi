CREATE VIEW B_PO_PRO_ITEM AS
  select max(a.id) as id,
       a.ad_client_id,
       a.ad_org_id,
       max(a.ownerid) as OWNERID,
       max(a.modifierid) as MODIFIERID,
       max(a.creationdate) as CREATIONDATE,
       max(a.modifieddate) as MODIFIEDDATE,
       'Y' as ISACTIVE,
       a.b_po_id,
       a.m_product_id,
       max(a.orderno) as orderno,
       sum(a.qty) as qty,
       max(nvl(a.pricelist, 0)) as pricelist,
       max(nvl(a.priceactual, 0)) as priceactual,
       max(nvl(a.discount, 1)) as discount,
       sum(a.tot_amt_list) as tot_amt_list,
       sum(a.tot_amt_actual) as tot_amt_actual,
       b.value1_id as m_color_id,
       max(a.predatein) as predatein
  from b_poitem a,m_attributesetinstance b
  where a.m_attributesetinstance_id=b.id
 group by a.ad_client_id, a.ad_org_id, a.b_po_id, a.m_product_id,b.value1_id
/

