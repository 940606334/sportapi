CREATE VIEW TD_SALED AS
  SELECT     '' AS ref_no, 0 AS t_qty, 0 AS t_amount from dual
/

