create view V_INVENTORY as
SELECT a.id,
       a.name AS inventory_id,
       a.value AS description,
       a.m_sizegroup_id + 200 AS size_type,
       a.unit,
       substr(a.name, 2, length(a.name) - 3) AS model,
       a.e_name AS ename,
       (SELECT attribcode FROM m_dim WHERE id = a.m_dim13_id) AS color,
       (SELECT attribcode FROM m_dim WHERE id = a.m_dim12_id) AS leather,
       (SELECT attribcode FROM m_dim WHERE id = a.m_dim11_id) AS lastno， a.serialno AS cnpo,
			 	a.IMP_STAND   as Last,0 as IMPORTED
FROM m_product a
WHERE -- a.modifieddate>sysdate-7 AND
a.name !='123'
and  a.isactive = 'Y'
/

