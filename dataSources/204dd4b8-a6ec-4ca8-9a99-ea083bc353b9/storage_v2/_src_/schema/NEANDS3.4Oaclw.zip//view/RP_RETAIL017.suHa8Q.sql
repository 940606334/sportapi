CREATE VIEW RP_RETAIL017 AS
  select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,to_char(a.creationdate,'yyyymmdd') as creationdate,
       a.modifieddate,a.isactive,a.billdate,a.docno,a.c_store_id,b.m_product_id,
       b.m_productalias_id,b.m_attributesetinstance_id,b.type,b.qty,b.priceactual,
       (select nvl(c.acost,0) from m_product c where c.id=b.m_product_id) as acost,
       percost_analyse(substr(a.billdate,1,6),a.c_store_id,b.m_product_id) as percost,
       nvl(b.priceactual,0)* b.qty as tot_amt_actual,
       (select nvl(c.acost,0) from m_product c where c.id=b.m_product_id)*b.qty as priceacost ,
       percost_analyse(substr(a.billdate,1,6),a.c_store_id,b.m_product_id)* b.qty as tot_amt_cost,
       nvl(b.priceactual,0)* b.qty-(select nvl(c.acost,0) from m_product c where c.id=b.m_product_id)*b.qty as pregross,
       --decode(b.priceactual* b.qty ,0,0,(nvl(b.priceactual,0)* b.qty-nvl(c.acost,0)*b.qty)/b.priceactual* b.qty) as pregrossrate,
       nvl(b.priceactual,0)* b.qty-percost_analyse(substr(a.billdate,1,6),a.c_store_id,b.m_product_id)* b.qty as profitcost,
       a.description,b.pricelist,b.tot_amt_list
       --decode(b.priceactual* b.qty,0,0,(nvl(b.priceactual,0)* b.qty-nvl(d.percost,0)* b.qty)/b.priceactual* b.qty) as profit1
from m_retail a,m_retailitem b
where a.id=b.m_retail_id
and a.status=2
and a.isactive='Y' with read only
/

