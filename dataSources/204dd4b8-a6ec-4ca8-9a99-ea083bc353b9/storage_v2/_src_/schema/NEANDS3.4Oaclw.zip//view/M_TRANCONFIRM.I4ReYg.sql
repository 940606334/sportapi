CREATE VIEW M_TRANCONFIRM AS
  select a.id,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,
a.docno,a.doctype,a.c_orig_id,a.c_dest_id,a.description,a.in_status,a.au_state,a.au_pi_id,a.tot_lines,
a.tot_qtyout,a.tot_qtyin,a.tot_diff_qty,a.tot_amtout_list,a.tot_amtin_list,a.c_period_id,a.billdate,a.diffreason,
a.out_status,a.tot_qty,a.tot_amtqty_list,a.dateout,a.datein,a.c_customer_id,a.transfertype,a.statuserid,
a.statustime,a.inerid,a.intime,a.outerid,a.outtime,a.c_transfertype_id,a.box_status,a.c_tranway_jz_id,a.tranwayno,
a.b_so_id,a.tranway_pay,a.operatoerid,a.oper_status,a.description2,a.pickerid,a.isuf,a.process_mode,a.tot_amt_precost,
a.tot_amtin_precost,a.shipping_remark,a.isbox,a.m_allot_id,a.m_assign_id,
a.dest_addr,a.c_cargotype_id,a.isst2bo,a.c_store_location_id,a.printtimes,a.printintimes,a.printouttimes,
a.c_cargointype_id,a.ifmove,a.scanstate,a.sendqty,a.subsendqty,a.confirm_status as status,a.confirmid,a.confirmtime,
a.status as ori_status/*原单状态从status改成ori_status*/
from M_TRANSFER a
/

