CREATE VIEW TDEFBUYER AS
  select id as buyerid,name ||'('|| description ||')' as buyername,isactive from c_customer
/

