CREATE VIEW V_RETAIL AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.B_RETAILDISSKU_ID,b.modifieddate,a.isactive,
a.docno,a.doctype,a.billdate,a.c_store_id,a.description,a.status,a.avg_discount,a.retailbilltype,
a.tot_qty,a.amtchange,a.c_Vip_Id,b.salesrep_id,a.statuserid,a.statustime,
b.m_retail_id,b.orderno,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.pricelist,b.priceactual,
b.discount,b.tot_amt_list,b.tot_amt_actual,b.type,b.orgdocno,a.refno,b.m_productalias_id
from m_retail a, m_retailitem b
where a.id = b.m_retail_id
order by docno desc
--with read only
/

