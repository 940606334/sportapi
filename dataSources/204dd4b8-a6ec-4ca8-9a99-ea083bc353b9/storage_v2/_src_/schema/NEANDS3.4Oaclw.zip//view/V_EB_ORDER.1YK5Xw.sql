CREATE VIEW V_EB_ORDER AS
  select rownum as id,eo.eb_trade_id,eo.adjust_fee,eo.buyer_rate,eo.discount_fee,
       eo.iid,eo.num,eo.num_iid,eo.oid,eo.out_iid,eo.payment,eo.pic_path,
       eo.price,eo.refund_status,eo.seller_rate,eo.seller_type,eo.status as tbstatus,
       eo.title,eo.total_fee,eo.ku_properties_name,eo.sku_id,eo.outer_sku_id,
       eo.item_meal_name,eo.refund_id,eo.tid,eo.sku
from eb_order eo
/

