CREATE VIEW V_RTPADJITEM AS
  select b.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.creationdate,a.modifierid,a.modifieddate,a.isactive,a.c_customer_id,
a.docno,a.priority,a.begindate,a.closedate,b.c_pricearea_id,b.m_product_id,b.pricelist,b.discount,b.price
from B_RTPADJ a,B_RTPADJITEM b
where a.id=b.b_rtpadj_id
and a.status=2
and a.isactive='Y'
order by a.docno desc
/

