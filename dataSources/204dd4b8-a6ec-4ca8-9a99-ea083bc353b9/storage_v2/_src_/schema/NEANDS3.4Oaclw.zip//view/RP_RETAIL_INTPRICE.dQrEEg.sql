CREATE VIEW RP_RETAIL_INTPRICE AS
  select a.id,a.ad_client_id,a.ad_org_id,a.modifierid,a.modifieddate,a.ownerid,a.creationdate,a.id as C_INTEGRALMIN_ID,a.name,
a.datebegin,a.dateend,a.viptype_filter,
decode(a.allstore,'Y',d.id,b.c_store_id) as c_store_id,c.m_product_id,c.integral,c.content
from C_INTEGRALMIN a,C_INTEGRALMINITEM b,C_INTEGRALMINPDITEM c,c_store d
where a.id=b.c_integralmin_id(+) and a.id=c.c_integralmin_id(+)
and a.status=2 and a.close_status=1 and d.isactive='Y'
with read only
/

