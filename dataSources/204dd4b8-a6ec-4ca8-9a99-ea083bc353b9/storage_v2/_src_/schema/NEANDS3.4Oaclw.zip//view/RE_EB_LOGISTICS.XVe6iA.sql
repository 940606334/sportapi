CREATE VIEW RE_EB_LOGISTICS AS
  SELECT orders.ID, orders.AD_CLIENT_ID, orders.AD_ORG_ID, orders.OWNERID,
       orders.MODIFIERID, orders.CREATIONDATE, orders.MODIFIEDDATE,
       orders.ISACTIVE, orders.DOCNO, orders.CTYPE, orders.RECEIVER_NAME,
       orders.RECEIVER_ADDRESS, orders.C_STORE_ID, orders.TID, logis.COMNAME,
       logis.COMNO, decode(orders.SHIPPING_TYPE,1,'快递',2,'平邮',3,'EMS','其他') AS SHIPPING_TYPE, orders.OUT_SID,
       orders.PAY_TIME, orders.BUYER_MEMO, orders.BUYER_MESSAGE,
       orders.RECEIVER_PHONE, orders.RECEIVER_MOBILE, orders.RECEIVER_CITY,
       orders.RECEIVER_STATE, orders.OUTTIME, orders.dateoutin,
       orders.ctype AS ctype2, orders.RECEIVER_DISTRICT,
       decode(orders.paytype, 1, orders.post_fee, 2, 0) AS BUY_POST_FEE,
       decode(orders.PAYTYPE, 1, 0, 2, orders.post_fee) AS SALE_POST_FEE
FROM EB_ORDERSO orders, EB_LOGIS logis
WHERE orders.EB_LOGIS_ID = logis.ID AND orders.status = 2 AND
      orders.out_status = 2
/

