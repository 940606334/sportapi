CREATE VIEW S_V_WSALELVL AS
  select C_CUSTOMER_ID,BILLDATE,sum(a_tot_amt) as a_tot_amt,sum(b_tot_amt) as b_tot_amt,sum(c_tot_amt) as c_tot_amt,
sum(abc_tot_amt) as abc_tot_amt,sum(s_tot_amt) as s_tot_amt,sum(o_tot_amt) as o_tot_amt,sum(all_tot_amt) as all_tot_amt from

(select C_CUSTOMER_ID,BILLDATE,sum(a_tot_amt ) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from
(SELECT M1.C_CUSTOMER_ID,M1.BILLDATE,-nvl(SUM(TOT_AMT_ACTUAL),0) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
  FROM B_RECEIVE M1,C_FEETYPE M2,M_PRODUCT M3,M_DIM M4
 WHERE M1.STATUS=2 AND M1.C_FEETYPE_ID=M2.ID AND M2.ISCASH='Y'
 AND M3.NAME=SUBSTR(M1.DESCRIPTION,1,INSTR(M1.DESCRIPTION,' ')-1) AND M4.ID=M3.M_DIM6_ID AND M4.ATTRIBNAME='A类货品'
 GROUP BY M1.C_CUSTOMER_ID,M1.BILLDATE
 union all
select t.C_CUSTOMER_ID,t.BILLDATE,sum(t.AMTSALEOUT ) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from RP_SALE001 t,M_product a,m_dim b where t.M_PRODUCT_ID=a.id and a.m_dim6_id=b.id and b.attribname='A类货品'
group by t.C_CUSTOMER_ID,t.BILLDATE)
group by C_CUSTOMER_ID,BILLDATE

union all

select C_CUSTOMER_ID,BILLDATE,0 as a_tot_amt,sum(a_tot_amt )as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from
(SELECT M1.C_CUSTOMER_ID,M1.BILLDATE,-nvl(SUM(TOT_AMT_ACTUAL),0) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
  FROM B_RECEIVE M1,C_FEETYPE M2,M_PRODUCT M3,M_DIM M4
 WHERE M1.STATUS=2 AND M1.C_FEETYPE_ID=M2.ID AND M2.ISCASH='Y'
 AND M3.NAME=SUBSTR(M1.DESCRIPTION,1,INSTR(M1.DESCRIPTION,' ')-1) AND M4.ID=M3.M_DIM6_ID AND M4.ATTRIBNAME='B类货品'
 GROUP BY M1.C_CUSTOMER_ID,M1.BILLDATE
 union all
select t.C_CUSTOMER_ID,t.BILLDATE,sum(t.AMTSALEOUT ) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from RP_SALE001 t,M_product a,m_dim b where t.M_PRODUCT_ID=a.id and a.m_dim6_id=b.id and b.attribname='B类货品'
group by t.C_CUSTOMER_ID,t.BILLDATE)
group by C_CUSTOMER_ID,BILLDATE

union all

select C_CUSTOMER_ID,BILLDATE,0 as a_tot_amt,0 as b_tot_amt,sum(a_tot_amt )as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from
(SELECT M1.C_CUSTOMER_ID,M1.BILLDATE,-nvl(SUM(TOT_AMT_ACTUAL),0) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
  FROM B_RECEIVE M1,C_FEETYPE M2,M_PRODUCT M3,M_DIM M4
 WHERE M1.STATUS=2 AND M1.C_FEETYPE_ID=M2.ID AND M2.ISCASH='Y'
 AND M3.NAME=SUBSTR(M1.DESCRIPTION,1,INSTR(M1.DESCRIPTION,' ')-1) AND M4.ID=M3.M_DIM6_ID AND M4.ATTRIBNAME='C类货品'
 GROUP BY M1.C_CUSTOMER_ID,M1.BILLDATE
 union all
select t.C_CUSTOMER_ID,t.BILLDATE,sum(t.AMTSALEOUT ) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from RP_SALE001 t,M_product a,m_dim b where t.M_PRODUCT_ID=a.id and a.m_dim6_id=b.id and b.attribname='C类货品'
group by t.C_CUSTOMER_ID,t.BILLDATE)
group by C_CUSTOMER_ID,BILLDATE

union all

select C_CUSTOMER_ID,BILLDATE,0 as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,sum(a_tot_amt ) as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from
(SELECT M1.C_CUSTOMER_ID,M1.BILLDATE,-nvl(SUM(TOT_AMT_ACTUAL),0) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
  FROM B_RECEIVE M1,C_FEETYPE M2,M_PRODUCT M3,M_DIM M4
 WHERE M1.STATUS=2 AND M1.C_FEETYPE_ID=M2.ID AND M2.ISCASH='Y'
 AND M3.NAME=SUBSTR(M1.DESCRIPTION,1,INSTR(M1.DESCRIPTION,' ')-1) AND M4.ID=M3.M_DIM6_ID AND M4.ATTRIBNAME in ('A类货品','B类货品','C类货品')
 GROUP BY M1.C_CUSTOMER_ID,M1.BILLDATE
 union all
select t.C_CUSTOMER_ID,t.BILLDATE,sum(t.AMTSALEOUT ) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from RP_SALE001 t,M_product a,m_dim b where t.M_PRODUCT_ID=a.id and a.m_dim6_id=b.id and b.attribname in ('A类货品','B类货品','C类货品')
group by t.C_CUSTOMER_ID,t.BILLDATE)
group by C_CUSTOMER_ID,BILLDATE

union all

select C_CUSTOMER_ID,BILLDATE,0 as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,sum(a_tot_amt ) as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from
(SELECT M1.C_CUSTOMER_ID,M1.BILLDATE,-nvl(SUM(TOT_AMT_ACTUAL),0) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
  FROM B_RECEIVE M1,C_FEETYPE M2,M_PRODUCT M3,M_DIM M4
 WHERE M1.STATUS=2 AND M1.C_FEETYPE_ID=M2.ID AND M2.ISCASH='Y'
 AND M3.NAME=SUBSTR(M1.DESCRIPTION,1,INSTR(M1.DESCRIPTION,' ')-1) AND M4.ID=M3.M_DIM6_ID AND M4.ATTRIBNAME='春夏货品'
 GROUP BY M1.C_CUSTOMER_ID,M1.BILLDATE
 union all
select t.C_CUSTOMER_ID,t.BILLDATE,sum(t.AMTSALEOUT ) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from RP_SALE001 t,M_product a,m_dim b where t.M_PRODUCT_ID=a.id and a.m_dim6_id=b.id and b.attribname='春夏货品'
group by t.C_CUSTOMER_ID,t.BILLDATE)
group by C_CUSTOMER_ID,BILLDATE

union all

select C_CUSTOMER_ID,BILLDATE,0 as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,sum(a_tot_amt ) as o_tot_amt,0 as all_tot_amt
 from
(SELECT M1.C_CUSTOMER_ID,M1.BILLDATE,-nvl(SUM(TOT_AMT_ACTUAL),0) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
  FROM B_RECEIVE M1,C_FEETYPE M2,M_PRODUCT M3,M_DIM M4
 WHERE M1.STATUS=2 AND M1.C_FEETYPE_ID=M2.ID AND M2.ISCASH='Y'
 AND M3.NAME=SUBSTR(M1.DESCRIPTION,1,INSTR(M1.DESCRIPTION,' ')-1) AND M4.ID=M3.M_DIM6_ID AND M4.ATTRIBNAME='老货'
 GROUP BY M1.C_CUSTOMER_ID,M1.BILLDATE
 union all
select t.C_CUSTOMER_ID,t.BILLDATE,sum(t.AMTSALEOUT ) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from RP_SALE001 t,M_product a,m_dim b where t.M_PRODUCT_ID=a.id and a.m_dim6_id=b.id and b.attribname='老货'
group by t.C_CUSTOMER_ID,t.BILLDATE)
group by C_CUSTOMER_ID,BILLDATE

union all

select C_CUSTOMER_ID,BILLDATE,0 as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,sum(a_tot_amt ) as all_tot_amt
 from
(SELECT M1.C_CUSTOMER_ID,M1.BILLDATE,-nvl(SUM(TOT_AMT_ACTUAL),0) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
  FROM B_RECEIVE M1,C_FEETYPE M2,M_PRODUCT M3,M_DIM M4
 WHERE M1.STATUS=2 AND M1.C_FEETYPE_ID=M2.ID AND M2.ISCASH='Y'
 AND M3.NAME=SUBSTR(M1.DESCRIPTION,1,INSTR(M1.DESCRIPTION,' ')-1) AND M4.ID=M3.M_DIM6_ID AND M4.ATTRIBNAME in ('A类货品','B类货品','C类货品','春夏货品','老货')

 GROUP BY M1.C_CUSTOMER_ID,M1.BILLDATE
 union all
select t.C_CUSTOMER_ID,t.BILLDATE,sum(t.AMTSALEOUT ) as a_tot_amt,0 as b_tot_amt,0 as c_tot_amt,0 as abc_tot_amt,0 as s_tot_amt,0 as o_tot_amt,0 as all_tot_amt
 from RP_SALE001 t,M_product a,m_dim b where t.M_PRODUCT_ID=a.id and a.m_dim6_id=b.id and b.attribname in ('A类货品','B类货品','C类货品','春夏货品','老货')

group by t.C_CUSTOMER_ID,t.BILLDATE)
group by C_CUSTOMER_ID,BILLDATE)
group by C_CUSTOMER_ID,BILLDATE
/

