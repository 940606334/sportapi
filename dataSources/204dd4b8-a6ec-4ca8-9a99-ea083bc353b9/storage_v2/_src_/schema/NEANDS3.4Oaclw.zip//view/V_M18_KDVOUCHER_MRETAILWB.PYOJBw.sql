CREATE VIEW V_M18_KDVOUCHER_MRETAILWB AS
  select d.code as storecode, e.code as customercode, a.billdate,  sum(b.tot_amt_actual) as amt,
sum(b.qty*c.precost) as cost, max(e.c_cusattrib1_id) as c_cusattrib1_id, max(f.code) as companycode, g.attribcode as brand
from  m_retail a, m_retailitem b, m_product c,  c_store  d, c_customer e, c_block f, m_dim g
where a.id=b.m_retail_id and b.m_product_id=c.id and a.c_store_id=d.id and a.c_customer_id=e.id
and a.status=2 and d.c_block_id=f.id and c.m_dim1_id=g.id
group by a.billdate , d.code, e.code, g.attribcode
/

