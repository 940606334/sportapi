CREATE VIEW M_V_PRODUCT_DIM AS
  select a.id, a.ad_client_id, a.ad_org_id, a.isactive, a.creationdate,
               a.ownerid, a.modifieddate, a.modifierid, a.name, a.m_dim1_id,
               a.m_dim2_id, a.m_dim3_id, a.m_dim4_id, a.m_dim5_id, a.m_dim6_id,
               a.m_dim7_id, a.m_dim8_id, a.m_dim9_id, a.m_dim10_id, a.m_dim11_id,
               a.m_dim12_id, a.m_dim13_id, a.m_dim14_id, a.m_dim15_id
        from m_product a
        where a.m_dim1_id is null and a.m_dim2_id is null and
              a.m_dim3_id is null and a.m_dim4_id is null and
              a.m_dim5_id is null and a.m_dim6_id is null and
              a.m_dim7_id is null and a.m_dim8_id is null and
              a.m_dim9_id is null and a.m_dim10_id is null and
              a.m_dim11_id is null and a.m_dim12_id is null and
              a.m_dim13_id is null and a.m_dim14_id is null and
              a.m_dim15_id is null
/

