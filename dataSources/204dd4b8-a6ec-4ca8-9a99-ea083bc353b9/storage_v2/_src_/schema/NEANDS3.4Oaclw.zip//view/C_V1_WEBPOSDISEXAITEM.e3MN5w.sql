CREATE VIEW C_V1_WEBPOSDISEXAITEM AS
  select a.id,a.c_webposdis_id,a.m_productalias_id,a.qty,a.relationtype
from 	C_WEBPOSDIS t,C_WEBPOSDISEXAITEM a
where t.id=a.c_webposdis_id
and t.webtype=1
and t.isactive='Y'
/

