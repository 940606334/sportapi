CREATE VIEW M_PURINSTORYITEM AS
  select id,ad_client_id,ad_org_id,m_purnotice_id,m_product_id,m_attributesetinstance_id,
   c_store_location_id,qty,ownerid,modifierid,creationdate,modifieddate,isactive,m_productalias_id
from m_purnoticestoryitem
/

