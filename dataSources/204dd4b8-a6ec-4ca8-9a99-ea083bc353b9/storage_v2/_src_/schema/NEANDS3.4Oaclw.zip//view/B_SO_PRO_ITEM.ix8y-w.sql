CREATE VIEW B_SO_PRO_ITEM AS
  select max(b.id) as id,b.ad_client_id,b.ad_org_id,'Y' as  isactive,max(b.creationdate) as creationdate,
max(b.ownerid) as ownerid,max(b.modifieddate) as modifieddate,max(b.modifierid) as modifierid,
b.b_so_id,b.m_product_id,/*max(b.orderno) as orderno,*/
round(avg(b.pricelist)) as pricelist,round(avg(b.priceactual),2) as priceactual,
round(avg(b.discount),2) as discount,
sum(b.qty) as qty,sum(b.qtyoccu) as qtyoccu,sum(b.qtyconsign) as qtyconsign,
sum(b.qtyrem) as qtyrem,sum(b.tot_amt_list) as tot_amt_list,
sum(b.tot_amt_actual) as tot_amt_actual,sum(b.tot_amt_order) as tot_amt_order,
sum(b.adj_times) as adj_times,max(b.confirmdate) as confirmdate
from b_soitem b
group by b.m_product_id,b.ad_client_id,b.ad_org_id,b.b_so_id
/

