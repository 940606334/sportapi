CREATE VIEW M_INVENTORY_PRO_ITEM AS
  select max(id) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,
m_inventory_id,m_product_id,max(orderno) as orderno,
sum(qtybook) as qtybook,sum(qtycount) as qtycount,sum(qtydiff) as qtydiff,max(nvl(pricelist,0)) as pricelist,
sum(tot_amtbook_list) as tot_amtbook_list, sum(tot_amtcount_list) as tot_amtcount_list,
sum(tot_amtdiff_list) as tot_amtdiff_list
from m_inventoryitem
group by ad_client_id,ad_org_id,m_inventory_id,m_product_id
/

