CREATE VIEW V_B_POBOXITEM AS
  select a.id,
       a.b_po_id,
       a.ORDERNO,
       a.qty,
       a.m_matchsize_id,
       a.b_so_id,
       a.m_product_id,
       a.m_color_id,
       b.tot_qty * a.qty as tot_sum,
       '' as packway,
       (select max(t.priceactual)
          from b_soitem t, m_attributesetinstance t1
         where t.b_so_id = a.b_so_id
           and t.m_attributesetinstance_id = t1.id
           and t.m_product_id = a.m_product_id
           and t1.value1_id = a.m_color_id) as priceactual,
       b.tot_qty * a.qty *
       (select max(t.priceactual)
          from b_soitem t, m_attributesetinstance t1
         where t.b_so_id = a.b_so_id
           and t.m_attributesetinstance_id = t1.id
           and t.m_product_id = a.m_product_id
           and t1.value1_id = a.m_color_id) as amt
  from B_POBOXITEM a, m_matchsize b

 where a.m_matchsize_id = b.id
/

