CREATE VIEW TDEFOATTRIBDEF AS
  select nvl(to_number(substr(a.dimflag,4)),0) as attribdefid ,
       to_char(a.name) as attribdefname, nvl(to_number(a.length),0) as length
from  m_dimdef a
/

