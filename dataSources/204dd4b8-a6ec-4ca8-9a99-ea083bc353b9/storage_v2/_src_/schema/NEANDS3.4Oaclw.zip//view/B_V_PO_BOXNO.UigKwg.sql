CREATE VIEW B_V_PO_BOXNO AS
  SELECT ID, AD_CLIENT_ID, AD_ORG_ID, B_PO_BOX_ID, B_SO_ID, BOXNO, C_CUSTOMER_ID,
       M_PRODUCT_ID,M_COLOR_ID, TOT_QTY, PREDATEIN, CONFIRMDATE, DESCRIPTION ,IN_STATUS, INERID, INTIME,
       CLOSE_STATUS, CLOSEID, CLOSETIME, OWNERID, MODIFIERID, CREATIONDATE,
       MODIFIEDDATE, ISACTIVE,ORDERNO,a.printtimes,decode(nvl(a.printtimes,0),0,1,2) as printstatus,a.m_matchsize_id,(select b.c_supplier_id from b_po b where b.id=a.b_po_box_id) as c_supplier_id
FROM B_PO_BOXNO a
where a.status=2
/

