CREATE VIEW RP_SO1 AS
  select b.id,b.ad_client_id,b.ad_org_id,
a.docno,a.b_fair_id,b.b_so_id,a.doctype,a.billdate,a.c_store_id,a.c_dest_id,a.c_period_id,
b.m_product_id,b.m_attributesetinstance_id,
b.pricelist,b.priceactual,b.tot_amt_list,b.tot_amt_actual,b.discount,
b.qty,b.qtyconsign,b.qtyoccu,b.qtyrem,
b.qtyconsign*b.pricelist AMTCONSIN_LIST,b.qtyconsign*b.priceactual AMTCONSIN_ACTUAL,
b.qtyoccu*b.pricelist AMTOCCU_LIST,b.qtyoccu*b.priceactual AMTOCCU_ACTUAL,
b.qtyrem*b.pricelist AMTREM_LIST,b.qtyrem*b.priceactual AMTREM_ACTUAL,
b.status,
b.ownerid,b.modifierid, b.creationdate,b.modifieddate,b.isactive,b.m_productalias_id as m_product_alias_id,
(case  when
(select m.c_customer_id from c_store m where m.id=a.c_store_id)=(select n.c_customer_id from c_store n where n.id=a.c_dest_id) then 2 else 1 end) as billtype,
nvl(t.qty,0) as po_qty,  --[采购订单量],根据表[采购订单明细追踪B_POFLWITEM]计算出由发货订单导入采购订单的各条码累计数量
(b.qty-nvl(t.qty,0)) as cancel_qty, --[取消数量]=订货数量-采购订单量 add by tracy 20101223
(select max(c2.confirmdate)
from b_po c1,b_poitem c2,B_POFLWITEM c3
where c1.status=2 and c1.id=c2.b_po_id and c2.m_product_id=b.m_product_id and c2.m_attributesetinstance_id=b.m_attributesetinstance_id
and c3.b_po_id=c1.id and  c3.b_so_id=a.id
) confirmdate,a.OWNERID as OWNERID2
from b_so a, b_soitem b,
(select sum(c.qty) qty,c.b_so_id ,c.m_product_id,c.m_attributesetinstance_id
from b_po c1,B_POFLWITEM c
where c1.status=2 and c1.id=c.b_po_id and nvl(c.b_so_id,0)>0
group by c.b_so_id,c.m_product_id,c.m_attributesetinstance_id) t
where a.id = b.b_so_id
/*and a.status =2*/
and b.b_so_id=t.b_so_id(+)
and b.m_product_id=t.m_product_id(+)
and b.m_attributesetinstance_id=t.m_attributesetinstance_id(+)
/

