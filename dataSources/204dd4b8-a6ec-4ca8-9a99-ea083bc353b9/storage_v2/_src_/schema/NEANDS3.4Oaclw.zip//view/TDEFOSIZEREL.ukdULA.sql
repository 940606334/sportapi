CREATE VIEW TDEFOSIZEREL AS
  select to_char(b.name) as SizeGId,to_char(a.VALUE)  as  Size1, nvl(to_number(a.MARTIXCOL),0) as  MARTIXCOL
from M_SIZE a,M_ATTRIBUTE b
where a.m_attribute_id=b.id
/

