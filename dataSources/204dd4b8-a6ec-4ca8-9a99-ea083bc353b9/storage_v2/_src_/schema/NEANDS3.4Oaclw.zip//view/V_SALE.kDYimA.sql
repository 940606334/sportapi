CREATE VIEW V_SALE AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.doctype,a.billdate,a.salesrep_id,a.c_store_id,a.c_customer_id,a.description,a.out_status,a.inerid,a.intime,
a.status,a.statuserid,a.statustime,a.b_so_id,a.c_dest_id,a.c_saletype_id,a.outerid,
a.in_status,a.tot_qtyin,a.diffreason,a.dateout,a.datein,a.c_customerup_id,a.saletype,a.salebilltype,a.outtime,
b.m_sale_id,b.orderno,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.qtyout,b.qtyin,b.pricelist,b.priceactual,
b.discount,b.tot_amt_list,b.tot_amt_actual,b.tot_amtout_list,b.tot_amtout_actual,b.tot_amtin_list,b.tot_amtin_actual,a.shipping_remark,
b.M_PRODUCTALIAS_ID
from m_sale a, m_saleitem b
where a.id = b.m_sale_id
order by a.docno desc
/

