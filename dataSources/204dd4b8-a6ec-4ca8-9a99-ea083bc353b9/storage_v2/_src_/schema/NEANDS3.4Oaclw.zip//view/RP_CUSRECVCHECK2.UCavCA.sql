CREATE VIEW RP_CUSRECVCHECK2 AS
  select h."ID",h."AD_CLIENT_ID",h."AD_ORG_ID",h."STATUSTIME" as MODIFIEDDATE,h."DOCNO",h."DOCTYPE",h."BILLDATE",h."C_CUSTOMER_ID",h."C_STORE_ID",h."DESCRIPTION",
h."M_SALE_ID",h."M_RET_SALE_ID",h."TOT_AMT_ACTUAL",h."C_FEETYPE_ID",LAG("TOTAL",1,NULL)
  OVER (partition by c_customer_id
        ORDER BY STATUSTIME,billdate,DOCNO) last_hire,
h."COLLECT_AMT",h."DEDUCT_AMT",h."TOTAL",'Y' as isactive
from
(select k.*,
SUM(k.tot_amt_actual)
    OVER (partition by c_customer_id
          ORDER BY STATUSTIME,billdate,DOCNO
          ROWS 10000000 PRECEDING) as "TOTAL"
from (select
       g.id,g.ad_client_id,g.ad_org_id,
       g.docno,
       g.doctype,
       g.billdate,
       g.c_customer_id,
       g.description,
       g.status,
       null as m_sale_id,
       null as m_ret_sale_id,
       g.tot_amt_actual,
       g.c_feetype_id,
       g.tot_amt_actual as collect_amt,
       0 as deduct_amt,
       to_char(g.STATUSTIME,'YYYY-MM-DD HH24:MI:SS')STATUSTIME,
       null as c_store_id
     from  b_receive g where g.status =2
     union
select
       t.id,t.ad_client_id,t.ad_org_id,
       t.docno,
       t.doctype,
       t.billdate,
       t.c_customer_id,
       t.description,
       t.status,
       t.m_sale_id,
       t.m_ret_sale_id,
       -t.tot_amt_actual as tot_amt_actual,
       t.c_feetype_id,
       0 as collect_amt,
       t.tot_amt_actual as deduct_amt,
      to_char( t.STATUSTIME,'YYYY-MM-DD HH24:MI:SS') STATUSTIME ,
      t.c_store_id
      from  b_receivable t where t.status =2 )k where exists (select 1 from dual where k.c_customer_id=c_customer_id)
  ) h
  order by  billdate,STATUSTIME,DOCNO
/

