CREATE VIEW M_UPD_M_PRODUCTALIAS AS
  select '1'as id,p_type from (
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/
'b_planitem' as p_type from b_planitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'b_poadjitem' as p_type from b_poadjitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'b_poitem' as p_type from b_poitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'b_soadjitem' as p_type from b_soadjitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'b_soitem' as p_type from b_soitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_assignitem' as p_type from m_assignitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_autocompitem' as p_type from m_autocompitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_custranitem' as p_type from m_custranitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_inboxitem' as p_type from m_inboxitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_inventoryitem' as p_type from m_inventoryitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_inventory_shelfitem' as p_type from m_inventory_shelfitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_inventory_unionchangehis' as p_type from m_inventory_unionchangehis t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_other_inoutitem' as p_type from m_other_inoutitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_purchaseitem' as p_type from m_purchaseitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_retailitem' as p_type from m_retailitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_ret_puritem' as p_type from m_ret_puritem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_ret_salediffitem' as p_type from m_ret_salediffitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_ret_saleitem' as p_type from m_ret_saleitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_salediffitem' as p_type from m_salediffitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_saleitem' as p_type from m_saleitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_selfcustranitem' as p_type from m_selfcustranitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_trandiffitem' as p_type from m_trandiffitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_transferdelitem' as p_type from m_transferdelitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_transferdelqtyitem' as p_type from m_transferdelqtyitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_transferitem' as p_type from m_transferitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'fa_storage' as p_type from FA_STORAGE t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'fa_storage_ftp' as p_type from fa_storage_ftp t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'fa_monthstore' as p_type from fa_monthstore t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_saledelqtyitem' as p_type from m_saledelqtyitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_saledelitem' as p_type from m_saledelitem t where t.m_productalias_id is null
union all
select /*t.id,t.m_product_id,t.m_attributesetinstance_id,t.m_productalias_id,*/'m_invoiceitem' as p_type from m_invoiceitem t where t.m_productalias_id is null
) group by p_type
/

