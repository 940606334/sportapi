CREATE VIEW TC_SKU AS
  select a.id, a.no as sku, b.name as style,c.value1_code  as clr,
c.value2_code as size1,
a.description as pname,a.forcode as fcode
from m_product_alias a,m_product b,m_attributesetinstance c
where a.m_product_id = b.id
and a.m_attributesetinstance_id = c.id
/

