CREATE VIEW RP_FA_STORAGESO AS
  select  a.id,a.c_store_id,
a.m_product_id,a.m_attributesetinstance_id,c.no,
a.qty qtystorage,a.QTYPREOUT ,
A.QTYPREIN ,
0 QTYSO,0 QTYREM , b.pricelist,
a.qty*b.pricelist amtstoragelist,a.QTYPREOUT*b.pricelist amtperoutlist ,A.QTYPREIN*b.pricelist amtpreinlist,
0 AS AMTSOACTUAL
from 	FA_STORAGE a ,M_PRODUCT b,M_PRODUCT_ALIAS c
WHERE a.m_product_id=b.id(+) and a.m_product_id=c.m_product_id and a.m_attributesetinstance_id=c.m_attributesetinstance_id
union all
select max(b.id)id ,a.c_store_id,
b.m_product_id,b.m_attributesetinstance_id,c.no,
0 as qtystorage,0 as qtypreout,
0 as qtyperin,
sum(b.QTYREM )qtyso ,SUM(b.QTYREM)QTYREM,d.pricelist,
0 amtstoragelist ,0 amtperoutlist ,0 amtpreinlist,
sum(B.QTYREM*b.priceactual )AMTSOACTUAL
from B_SO a ,B_SOitem b,M_PRODUCT_ALIAS c,M_PRODUCT d
where a.id =b.b_so_id and a.status =2 and  b.m_product_id=c.m_product_id
and b.m_attributesetinstance_id=c.m_attributesetinstance_id
and b.M_PRODUCT_ID=d.id
GROUP BY a.c_store_id,b.ad_client_id,b.ad_org_id,b.m_product_id,b.m_attributesetinstance_id,c.no,d.pricelist
WITH READ ONLY
/

