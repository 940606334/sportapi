CREATE VIEW TDEFOORDERSTYLE AS
  select  a.id as orderid, to_char(c.name) as style,'' as NO
from B_FAIR a,B_FAIRITEM b,  M_PRODUCT c
where a.id(+)=b.b_fair_id  and c.id(+)=b.M_PRODUCT_ID
and to_char(sysdate, 'yyyymmdd')> = to_char(to_date(a.DATESTART,'yyyymmdd'),'YYYYMMDD')
and  to_char(sysdate, 'yyyymmdd') <= to_char(to_date(a.DATEEND,'yyyymmdd'),'YYYYMMDD')
/

