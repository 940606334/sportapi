CREATE VIEW JIANGBF001 AS
  select t.id as name ,t1.id as value from b_fair t ,b_fairitem t1

where t.id=t1.b_fair_id
/

