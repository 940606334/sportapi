CREATE VIEW VM_BRTPADJITEM_DIF AS
  SELECT --F."ID",F."M_PRODUCT_ID",F."NO",F."NAME",F."VALUE",F."FORCODE",F."VALUE1",F."VALUE1_CODE",F."VALUE2",F."VALUE2_CODE",F."PRICELIST",F."ISACTIVE",F."INTSCODE",F."T",ROW_NUMBER() OVER(PARTITION BY ID ORDER BY ID) RN
F."ID",F."DOCNO",F."PRIORITY",F."BEGINDATE",F."CLOSEDATE",F."C_PRICEAREA_ID",F."M_PRODUCT_ID",F."PRICELIST",F."DISCOUNT",F."PRICE",F."ISACTIVE",
F."T",ROW_NUMBER() OVER(PARTITION BY ID ORDER BY ID) RN
FROM (
Select b2a.*, 'b_v_rtpadjitem' T
from ((Select * from b_v_rtpadjitem) Minus (Select * From b_v_rtpadjitem_tmp)) b2a
union all
Select a2b.*, 'b_v_rtpadjitem_tmp' T
from ((Select * from b_v_rtpadjitem_tmp) Minus (Select * From b_v_rtpadjitem)) a2b) F
/

