CREATE VIEW RP_RETAILORG01 AS
  select a.id,a.ad_client_id,a.ad_org_id,a.docno,a.billdate,a.c_store_id,a.salesrep_id,a.c_vip_id,a.description,
a.tot_qty,a.tot_amt_actual,nvl(b.payamount,0) as payamount
from m_retail a,
(select c.m_retail_id,sum(c.payamount) as payamount from m_retailpayitem c
group by c.m_retail_id) b
where a.id = b.m_retail_id(+)
and a.retailbilltype = 'CTR'
and a.status=2
with read only
/

