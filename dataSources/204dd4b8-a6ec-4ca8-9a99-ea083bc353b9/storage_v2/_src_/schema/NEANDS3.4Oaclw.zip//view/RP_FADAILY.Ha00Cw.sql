CREATE VIEW RP_FADAILY AS
  select max(id) as id, max(ad_client_id) as ad_client_id , max(ad_org_id) as ad_org_id, max(isactive) as isactive,
       max(creationdate) as creationdate, max(ownerid) as ownerid, max(modifieddate) as modifieddate,
       max(modifierid) as modifierid, billdate, docno,c_custype, c_store_id,
       sum(tot_amt_list) as tot_amt_list,sum(tot_amtret_list) as tot_amtret_list,
       sum(tot_amt_actual) as tot_amt_actual,sum(tot_amtret_actual) as tot_amtret_actual,
       sum(tot_amtdis_list) as tot_amtdis_list,sum(tot_amt_cost) as tot_amt_cost,sum(qty) as qty,sum(qtyret) as qtyret,
       sum(tot_amtrtl_discount) as tot_amtrtl_discount,sum(tot_amtret_discount) as tot_amtret_discount
from
   (select b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
           a.billdate,a.docno,a.c_store_id,b.tot_amt_list,0 as tot_amtret_list,b.tot_amt_actual,0 as tot_amtret_actual,
           b.tot_amt_list-b.tot_amt_actual as tot_amtdis_list,c.precost*b.qty as tot_amt_cost,
           b.qty as qty,0 as qtyret,'SEF' as c_custype,
           b.tot_amt_list-b.tot_amt_actual as tot_amtrtl_discount, 0 as tot_amtret_discount--added by ken
    from m_retail a,m_retailitem b,m_product c
    where a.id=b.m_retail_id and b.m_product_id=c.id and a.status=2
          and b.qty>0 and exists
              (select 'X'
               from c_store t,C_CUSTOMER s,c_cusrank r
               where t.c_customer_id=s.id and s.c_cusrank_id=r.id and r.name='总部'
                     and a.c_store_id=t.id
              )
    union all
    select b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
           a.billdate,a.docno,a.c_store_id,0 as tot_amt_list,-b.tot_amt_list as tot_amtret_list,
           0 as tot_amt_actual,-b.tot_amt_actual as tot_amtret_actual,
           (b.tot_amt_list-b.tot_amt_actual) as tot_amtdis_list,c.precost*b.qty as tot_amt_cost,
           0 as qty,-b.qty as qtyret,'SEF' as c_custype,
           0 as tot_amtrtl_discount,-(b.tot_amt_list-b.tot_amt_actual) as tot_amtret_discount --added by ken
    from m_retail a,m_retailitem b,m_product c
    where a.id=b.m_retail_id and b.m_product_id=c.id and a.status=2
          and b.qty<0 and exists
              (select 'X'
               from c_store t,C_CUSTOMER s,c_cusrank r
               where t.c_customer_id=s.id and s.c_cusrank_id=r.id and r.name='总部'
                     and a.c_store_id=t.id
              )
    union all
    SELECT b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
           a.dateout as billdate,a.docno,a.c_dest_id as c_store_id,b.tot_amtout_list as tot_amt_list,
           0 as tot_amtret_list,b.tot_amtout_actual as tot_amt_actual,0 as tot_amtret_actual,
           (b.tot_amtout_list-b.tot_amtout_actual) as tot_amtdis_list,c.precost*b.qtyout as tot_amt_cost,
           b.qtyout as qty,0 as qtyret,'CHG' as c_custype,
           b.tot_amtout_list-b.tot_amtout_actual as tot_amtrtl_discount, 0 as tot_amtret_discount--added by ken
    from m_sale a,m_saleitem b,m_product c
    where a.id=b.m_sale_id and b.m_product_id=c.id AND a.out_status=2
          AND a.id in(select t.id
                      from m_sale t
                      where t.description like' 由自营店经销商调货价格审批单：%提交生成%'
                      and t.in_status=2
                      )
    union all
    SELECT b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
           a.dateout as billdate,a.docno,a.c_dest_id as c_store_id,b.tot_amtout_list as tot_amt_list,
           0 as tot_amtret_list,b.tot_amtout_actual as tot_amt_actual,0 as tot_amtret_actual,
           (b.tot_amtout_list-b.tot_amtout_actual) as tot_amtdis_list,c.precost*b.qtyout as tot_amt_cost,
           b.qtyout as qty,0 as qtyret,'NEW' as c_custype,
           b.tot_amtout_list-b.tot_amtout_actual as tot_amtrtl_discount, 0 as tot_amtret_discount--added by ken
    from m_sale a,m_saleitem b,m_product c
    where a.id=b.m_sale_id and b.m_product_id=c.id AND a.out_status=2
          AND a.c_dest_id IN(SELECT a.id
                             FROM c_store a
                             WHERE a.c_customer_id in(select a.id from c_customer a,c_cusattribdef b,c_cusattribvalue c
                                            where a.c_cusattrib1_id=c.id and b.id=c.c_cusattribdef_id and c.dimflag='DIM1'
                                            and c.name='新加盟')
                            )
 and a.id not in (select t.id
from m_sale t
where t.description like' 由自营店经销商调货价格审批单：%提交生成%'
and t.in_status=2)
union all
 SELECT b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.dateout as billdate,a.docno,a.c_dest_id as c_store_id,b.tot_amtout_list as tot_amt_list,0 as tot_amtret_list,b.tot_amtout_actual as tot_amt_actual,0 as tot_amtret_actual,
(b.tot_amtout_list-b.tot_amtout_actual) as tot_amtdis_list,c.precost*b.qtyout as tot_amt_cost,b.qtyout as qty,0 as qtyret,'OLD' as c_custype,
b.tot_amtout_list-b.tot_amtout_actual as tot_amtrtl_discount, 0 as tot_amtret_discount--added by ken
from m_sale a,m_saleitem b,m_product c
where a.id=b.m_sale_id
and b.m_product_id=c.id
AND a.out_status=2
AND a.c_dest_id IN(SELECT a.id
   FROM c_store a
  WHERE a.c_customer_id in(select a.id from c_customer a,c_cusattribdef b,c_cusattribvalue c
                                            where a.c_cusattrib1_id=c.id and b.id=c.c_cusattribdef_id and c.dimflag='DIM1'
                                            and c.name='老加盟'))
and a.id not in (select t.id
from m_sale t
where t.description like' 由自营店经销商调货价格审批单：%提交生成%'
and t.in_status=2)--且不是CHG
union all
SELECT b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.datein as billdate,a.docno,a.c_orig_id as c_store_id,0 as tot_amt_list,b.tot_amtin_list as tot_amtret_list,0 as tot_amt_actual,b.tot_amtin_actual as tot_amtret_actual,
-(b.tot_amtin_list-b.tot_amtin_actual) as tot_amtdis_list,-c.precost*b.qtyin as tot_amt_cost,0 as qty,b.qtyin as qtyret,'NEW' as c_custype,
0 as tot_amtrtl_discount,(b.tot_amtin_list-b.tot_amtin_actual) as tot_amtret_discount --added by ken
FROM m_ret_sale a,m_ret_saleitem b,m_product c
WHERE a.id=b.m_ret_sale_id
AND b.m_product_id=c.id
AND a.in_status=2
AND a.c_orig_id in(SELECT a.id
                             FROM c_store a
                            WHERE a.c_customer_id in(select a.id from c_customer a,c_cusattribdef b,c_cusattribvalue c
                                                                       where a.c_cusattrib1_id=c.id and b.id=c.c_cusattribdef_id and c.dimflag='DIM1'
                                                                                  and c.name='新加盟'))
union all
SELECT b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.datein as billdate,a.docno,a.c_orig_id as c_store_id,0 as tot_amt_list,b.tot_amtin_list as tot_amtret_list,0 as tot_amt_actual,b.tot_amtin_actual as tot_amtret_actual,
-(b.tot_amtin_list-b.tot_amtin_actual) as tot_amtdis_list,-c.precost*b.qtyin as tot_amt_cost,0 as qty,b.qtyin as qtyret,'OLD' as c_custype,
0 as tot_amtrtl_discount,(b.tot_amtin_list-b.tot_amtin_actual) as tot_amtret_discount --added by ken
FROM m_ret_sale a,m_ret_saleitem b,m_product c
WHERE a.id=b.m_ret_sale_id
AND b.m_product_id=c.id
AND a.in_status=2
AND a.c_orig_id in(SELECT a.id
                             FROM c_store a
                            WHERE a.c_customer_id in(select a.id from c_customer a,c_cusattribdef b,c_cusattribvalue c
                                                                       where a.c_cusattrib1_id=c.id and b.id=c.c_cusattribdef_id and c.dimflag='DIM1'
                                                                                  and c.name='老加盟'))
union all

SELECT b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.datein as billdate,a.docno,a.c_orig_id as c_store_id,0 as tot_amt_list,b.tot_amtin_list as tot_amtret_list,0 as tot_amt_actual,b.tot_amtin_actual as tot_amtret_actual,
-(b.tot_amtin_list-b.tot_amtin_actual) as tot_amtdis_list,-c.precost*b.qtyin as tot_amt_cost,0 as qty,b.qtyin as qtyret,'OTH' as c_custype,
0 as tot_amtrtl_discount,(b.tot_amtin_list-b.tot_amtin_actual) as tot_amtret_discount --added by ken
FROM m_ret_sale a,m_ret_saleitem b,m_product c
WHERE a.id=b.m_ret_sale_id
AND b.m_product_id=c.id
AND a.in_status=2
AND a.c_orig_id not in(SELECT a.id
                             FROM c_store a
                            WHERE a.c_customer_id in(select a.id from c_customer a,c_cusattribdef b,c_cusattribvalue c
                                                                       where a.c_cusattrib1_id=c.id and b.id=c.c_cusattribdef_id and c.dimflag='DIM1'
                                                                                  and c.name in('新加盟','老加盟'))
                                           and a.c_customer_id<>(select ID from C_CUSTOMER where c_cusrank_id=(select ID from c_cusrank where name ='总部')))
and a.id not in (select t.id
from m_ret_sale t
where t.description like' 由自营店经销商调货价格审批单：%提交生成%'
and t.in_status=2)
union all
 SELECT b.id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.dateout as billdate ,a.docno,a.c_dest_id as c_store_id,b.tot_amtout_list as tot_amt_list,0 as tot_amtret_list,b.tot_amtout_actual as tot_amt_actual,0 as tot_amtret_actual,
(b.tot_amtout_list-b.tot_amtout_actual) as tot_amtdis_list,c.precost*b.qtyout as tot_amt_cost,b.qtyout as qty,0 as qtyret,'OTH' as c_custype,
(b.tot_amtout_list-b.tot_amtout_actual) as tot_amtrtl_discount,0 as tot_amtret_discount --added by ken
from m_sale a,m_saleitem b,m_product c
where a.id=b.m_sale_id
and b.m_product_id=c.id
AND a.out_status=2
AND a.c_dest_id IN(SELECT a.id
   FROM c_store a
  WHERE a.c_customer_id not in(select a.id from c_customer a,c_cusattribdef b,c_cusattribvalue c
                                            where a.c_cusattrib1_id=c.id and b.id=c.c_cusattribdef_id and c.dimflag='DIM1'
                                            and c.name in('老加盟','新加盟'))
                and a.c_customer_id<>(select ID from C_CUSTOMER where c_cusrank_id=(select ID from c_cusrank where name ='总部')))
and a.id not in (select t.id
from m_sale t
where t.description like' 由自营店经销商调货价格审批单：%提交生成%'
and t.out_status=2)

                                  ) t
--where t.c_custype='OLD'
 group by billdate,c_store_id,docno,c_custype
/

