CREATE VIEW RP_FA_COST_MONTHSTORE AS
  select t.id, t.ad_client_id, t.ad_org_id, t.ownerid, t.modifierid,
       t.creationdate, t.modifieddate, t.isactive, t.c_period_id, t.c_store_id,
       t.m_product_id, t.m_attributesetinstance_id, a.pricelist, t.qtybegin,
       t.qtybegin * a.pricelist as amtlistbeg,
       t.qtybegin * t.percostbegin as amtprecostbeg, t.percostbegin, a.precost,
       t.costbegin, t.qtypurchase,
       PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as MPERCOST,
       t.qtypurchase * a.pricelist as amtlistpurchase,
       t.qtypurchase * t.percostbegin as amtprecostpurchase, t.amtpurchase,
       t.qtyretpur, t.qtyretpur * a.pricelist as amtlistretpur,
       t.qtyretpur * t.percostbegin as amtprecostretpur, t.amtretpur, t.qtysale,
       t.qtysale * a.pricelist as amtlistsale,
       t.qtysale * t.percostbegin as amtprecostsale,
       t.qtysale * a.acost as amtacostsale, t.qtysale *  PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as   AMTMPERCOSTSALE,
       t.amtsale, t.qtyretsale,
       t.qtyretsale * a.pricelist as amtlistretsale,
       t.qtyretsale * t.percostbegin as amtprecostretsale,
       t.qtyretsale * a.acost as amtacostretsale,t.qtyretsale * PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as AMTMPERCOSTRETSALE ,
        t.amtretsale, t.qtyretail,
       t.qtyretail * a.pricelist as amtlistretail,
       t.qtyretail * t.percostbegin as amtprecostretail,
       t.qtyretail * a.acost as amtacostretail, t.qtyretail *PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as AMTMPERCOSTRETAIL ,
       t.amtretail, t.qtytransferout,
       t.qtytransferout * a.pricelist as amtlisttransferout,
       t.qtytransferout * t.percostbegin as amtprecosttransferout,
       t.qtytransferout * a.acost as amtacosttransferout,  t.qtytransferout*PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id)  as AMTMPERCOSTTRANSFEROUT ,
       t.qtytransferin,
       t.qtytransferin * a.pricelist as amtlisttransferin,
       t.qtytransferin * t.percostbegin as amtprecosttransferin,
       t.qtytransferin * a.acost as amtacosttransferin,t.qtytransferin * PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as   AMTMPERCOSTTRANSFERIN ,
       t.qtyinventory,
       t.qtyinventory * a.pricelist as amtlistinventory,
       t.qtyinventory * t.percostbegin as amtprecostinventory,
       t.qtyinventory * a.acost as amtacostinventory, t.qtyinventory *PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as AMTMPERCOSTINVENTORY ,
       t.qtyotherinout,
       t.qtyotherinout * a.pricelist as amtlistoth,
       t.qtyotherinout * t.percostbegin as amtprecostoth,
       t.qtyotherinout * a.acost as amtacostoth, t.qtyotherinout * PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as AMTMPERCOSTOTH ,
       t.percostdiff, t.costdiff,
       t.qtyend, t.qtyend * a.pricelist as amtlistend,
       t.qtyend * t.percostbegin as amtprecostend, t.percostend, t.costend,
       t.qtyinbegin, t.qtyinbegin * a.pricelist as amtlistinbeg,
       t.qtyinbegin * t.percostbegin as amtprecostinbeg, t.costinbegin,
       t.precostbegin, t.yearmonth, t.qtyinend,
       t.qtyinend * a.pricelist as amtlistinend,
       t.qtyinend * t.percostbegin as amtprecostinend, t.costinend,
       t.Qtyretpur*PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as AMTMPERCOSTRETPUR, t.qtyretpur*a.acost as AMTACOSTRETPUR,
                       t.Qtyend*PERCOST_Analyse((select d.yearmonth
                        from c_period d
                        where id = t.c_period_id),
                        t.c_store_id,
                        t.m_product_id) as AMTMPERCOSTEND
from fa_monthstore t, m_product a
where t.m_product_id = a.id
with read only
/

