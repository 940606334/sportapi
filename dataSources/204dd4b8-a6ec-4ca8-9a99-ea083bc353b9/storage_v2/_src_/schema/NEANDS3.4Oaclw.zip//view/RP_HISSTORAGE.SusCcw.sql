CREATE VIEW RP_HISSTORAGE AS
  select t.ad_client_id,t.C_STORE_ID AS id,t.C_STORE_ID,t.M_PRODUCT_ID,t.M_ATTRIBUTESETINSTANCE_ID,t.total,t.changedate,
t.total*t.pricelist as amt_list,t.total*t.percost as amt_cost,t.pricelist,t.percost,'Y' AS isactive,t.m_productalias_id m_product_alias_id

 from
 (select sum(t.qtychange) as total,t.m_product_id AS ID, t.m_product_id,t.m_attributesetinstance_id,t.c_store_id,
t.changedate,t.ad_client_id,a.pricelist,b.percost,t.m_productalias_id from fa_storage_ftp t,m_product a,fa_product_cost b
where t.m_product_id = a.id
and t.m_product_id = b.m_product_id (+)
 group by
  t.m_product_id,t.m_attributesetinstance_id,t.c_store_id,t.changedate,t.ad_client_id,a.pricelist,b.percost,t.m_productalias_id) t
/

