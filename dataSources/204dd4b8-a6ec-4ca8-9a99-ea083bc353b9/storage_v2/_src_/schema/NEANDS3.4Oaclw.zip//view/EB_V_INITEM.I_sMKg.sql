CREATE VIEW EB_V_INITEM AS
  select id ,ad_client_id, ad_org_id, isactive, modifierid, creationdate,
       modifieddate, ownerid, eb_orderso_id as EB_V_IN_id,
 M_PRODUCTALIAS_ID ,
  M_PRODUCT_ID,
    M_ATTRIBUTESETINSTANCE_ID,
QTY , RQTY,QTYOUT,QTYIN ,price ,total_fee ,payment ,IN_STATUS as STATUS
from EB_ORDERSOITEM    WHERE   isactive ='Y'

/

