CREATE VIEW Y_STYLE_BOM_COST_ITEM AS
  select Y_STYLE_BOM_ID as ID,max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,
max(OWNERID) as OWNERID,max(MODIFIERID) as MODIFIERID,
SYSDATE as CREATIONDATE,SYSDATE as MODIFIEDDATE,'Y' as ISACTIVE,
Y_STYLE_BOM_ID,sum(FABCOST) AS FABCOST,SUM(ACCCOST) AS ACCCOST,SUM(PROCOST) AS PROCOST,SUM(FABCOST+ACCCOST+PROCOST) AS TOTALCOST
from
(
--计算面料成本
select max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,max(OWNERID) as OWNERID,max(MODIFIERID) as MODIFIERID,
STYLE_ID as Y_STYLE_BOM_ID,SUM(COST) AS FABCOST,0 AS ACCCOST,0 AS PROCOST
FROM
(select max(a.ad_client_id) as ad_client_id,max(a.ad_org_id) as ad_org_id,max(a.OWNERID) as OWNERID,max(a.MODIFIERID) as MODIFIERID,
a.STYLE_ID,a.material_id,case a.is_size when 'N' THEN nvl(a.FOB,0)*nvl(a.per_num,0) ELSE max(nvl(a.FOB,0)*nvl(b.per_num,0)) END AS COST
from Y_PRODUCT_BOM_PREPARE a,Y_PBP_SIZE b
where exists (select 1 from y_MATERIAL  t where t.id = a.MATERIAL_ID  and t.MATERIAL_TYPE = 'FAB')
and a.id =b.prepare_id(+)
and a.provider<>2
group by a.STYLE_ID,a.material_id,a.is_size,a.FOB,a.per_num
)
GROUP BY STYLE_ID
union all
--计算辅料成本
select max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,max(OWNERID) as OWNERID,max(MODIFIERID) as MODIFIERID,
STYLE_ID as Y_STYLE_BOM_ID,0 AS FABCOST,SUM(COST) AS ACCCOST,0 AS PROCOST
FROM
(select max(a.ad_client_id) as ad_client_id,max(a.ad_org_id) as ad_org_id,max(a.OWNERID) as OWNERID,max(a.MODIFIERID) as MODIFIERID,
a.STYLE_ID,a.material_id,case a.is_size when 'N' THEN nvl(a.FOB,0)*nvl(a.per_num,0) ELSE max(nvl(a.FOB,0)*nvl(b.per_num,0)) END AS COST
from Y_PRODUCT_BOM_PREPARE a,Y_PBP_SIZE b
where exists (select 1 from y_MATERIAL  t where t.id = a.MATERIAL_ID  and t.MATERIAL_TYPE = 'ACC')
and a.id =b.prepare_id(+)
and a.provider<>2
group by a.STYLE_ID,a.material_id,a.is_size,a.FOB,a.per_num
)
GROUP BY STYLE_ID
union all
--计算加工成本
select max(ad_client_id) as ad_client_id,max(ad_org_id) as ad_org_id,max(OWNERID) as OWNERID,max(MODIFIERID) as MODIFIERID,
Y_STYLE_BOM_ID,0 AS FABCOST,0 AS ACCCOST,SUM(nvl(FPRICE,0)) as PROCOST
from Y_STYLE_BOM_PROCHARGE_ITEM
group by Y_STYLE_BOM_ID
)
group by Y_STYLE_BOM_ID
/

