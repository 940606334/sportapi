CREATE VIEW M_V_TRAGOODSHAND AS
  select a.id,a.ad_client_id,a.ad_org_id,a.docno,a.billdate,a.c_store_id,a.c_trastore_id,a.c_customer_id,
a.c_outsaledistype_id,a.saletypein,
a.c_insaledistype_id,a.description,a.tot_qty,a.tot_out_amt,a.tot_in_amt,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,
a.chk_status as status,a.chk_serid as statuserid,a.chk_time as statustime,a.isactive
from M_TRAGOODSHAND a
where status=2
/

