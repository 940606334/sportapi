CREATE VIEW RP_BOXSTOCK AS
  select max(a.id) as id,b.c_customer_id,b.c_store_id,a.m_product_id,a.m_matchsize_id,a.tot_qty,
sum(decode(a.in_status,1,1,0)) as in_qty,
sum(decode(a.in_status,2,1,0)) as out_qty
from b_po_boxno a,b_so b
where a.b_so_id=b.id
and a.status=2
--and b.is_box=1
and a.dx_status=2
and a.out_status=1
and a.close_status=1
group by b.c_customer_id,b.c_store_id,a.m_product_id,a.m_matchsize_id,a.tot_qty
WITH READ ONLY
/

