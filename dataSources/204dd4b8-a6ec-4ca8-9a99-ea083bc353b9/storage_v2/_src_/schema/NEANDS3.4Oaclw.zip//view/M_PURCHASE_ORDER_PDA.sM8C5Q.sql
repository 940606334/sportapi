CREATE VIEW M_PURCHASE_ORDER_PDA AS
  select a.m_purchase_order_id id,a.id item_id, b.tot_qty FROM m_purchase_orderitem a, b_po_boxno b
       WHERE a.b_po_boxno_id = b.id
/

