CREATE VIEW M_MOVE_OCCUPYITEM AS
  SELECT t.id, t.ad_client_id, t.ad_org_id, t.ownerid, t.modifierid,
       t.creationdate, t.modifieddate, t.isactive, t.docno, t.m_productalias_id,
       t.c_store_id,t.qty,t.qtycan,(t.QTYCAN - t.qty) as qtydiff,t.m_stockcondition_id
FROM M_STOCK_OCCUPYITEM t,m_stockcondition m
WHERE  t.QTYCAN < t.qty and t.m_stockcondition_id=m.id
/

