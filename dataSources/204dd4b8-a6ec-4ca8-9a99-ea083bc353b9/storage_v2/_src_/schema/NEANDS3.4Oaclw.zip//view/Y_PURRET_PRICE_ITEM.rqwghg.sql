CREATE VIEW Y_PURRET_PRICE_ITEM AS
  SELECT id, ad_client_id, ad_org_id, y_purret_id, y_material_id, y_color_id,
       fabric_width, fabric_weight, y_spec_id, qty, qtyout, purchase_unit_id,
       purchase_rate, use_unit_id, fprice, famount, famountout, m_product_id,
       ownerid, modifierid, creationdate, modifieddate,
       isactive, tot_qty, amttoprice, y_materialalias_id, pricemodify,
       pricecheck, famountout_pcheck,tax_amt,notax_amt, t.notax_price
FROM y_purret_item t
/

