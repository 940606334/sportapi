CREATE VIEW V_FA_CUSTOMER2 AS
  select ID,AD_CLIENT_ID,AD_ORG_ID,OWNERID,MODIFIERID,CREATIONDATE,MODIFIEDDATE,ISACTIVE,
C_CUSTOMER_ID,AMT_RECEIVABLE,AMT_RECEIVE,ENTERDATE,FEELSALE,FEECHECKED,TQTY,TAMT,TAMTLIST,
TTIMES,TQTYRET,TAMTRET,TTIMESRET,LASTDATE,LASTAMOUNT,FEELTAKE,FEECHECKEDIN,FEEREMAIN,AMT_ODR_REMAIN,
FEE_ODR_CHECKED, FEE_ODR_CHECKEDIN,
FeeRemain - FeeChecked + FeeCheckedIn AS FEEPRE,
FeeRemain - FeeChecked  - FeeLSale AS FEECANSALE,
FeeRemain - FeeChecked  - FeeLTake AS FEECANTAKE,
case nvl(TQty,0) when 0 then 0 else round(TAmt/TQty) end AS AMTQTY,
case nvl(TAmtList,0) when 0 then 0 else round(TAmt/TAmtList,2) end AS AVERDIS,
case TTimes when 0 then 0 else round(TAmt/TTimes) end AS AMTTIMES,
case (to_char(sysdate,'YYYYMM')-substr(EnterDate,1,6)+1) when 0 then 0 else round(TTimes/(to_char(sysdate,'YYYYMM')-substr(EnterDate,1,6)+1)) end AS AVERMTIMES,
case (to_char(sysdate,'YYYYMM')-substr(EnterDate,1,6)+1) when 0 then 0 else round(TQty/(to_char(sysdate,'YYYYMM')-substr(EnterDate,1,6)+1)) end AS AVERMQTY,
case (to_char(sysdate,'YYYYMM')-substr(EnterDate,1,6)+1) when 0 then 0 else round(TAmt/(to_char(sysdate,'YYYYMM')-substr(EnterDate,1,6)+1),2) end AS AVERMAMOUNT,
TAmt - TAMTRET AS TAMTFACT
FROM FA_CUSTOMER
--WITH READ ONLY
/

