CREATE VIEW M_V_CUSPURCHASE_PRO_ITEM AS
  select max(id) as id,ad_client_id,ad_org_id,max(ownerid) as ownerid,
       max(modifierid) as modifierid,max(creationdate) as creationdate,
       max(modifieddate) as modifieddate,'y' as isactive,
       mp.m_sale_id,mp.m_product_id,sum(mp.qtyout) qtyout,sum(mp.qtyin) qtyin,sum(mp.qtydiff) qtydiff,
      avg(mp.pricelist) pricelist,avg(mp.priceactual) priceactual,avg(mp.discount) discount,
      sum(mp.tot_amt_list) tot_amt_list,sum(mp.tot_amt_actual) tot_amt_actual,
      sum(mp.tot_amtout_actual) tot_amtout_actual,sum(mp.tot_amtin_actual) tot_amtin_actual
from m_saleitem mp
group by ad_client_id,ad_org_id,mp.m_sale_id,mp.m_product_id
with read only
/

