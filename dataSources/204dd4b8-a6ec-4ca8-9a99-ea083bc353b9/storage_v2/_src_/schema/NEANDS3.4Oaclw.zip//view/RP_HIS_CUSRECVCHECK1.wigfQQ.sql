CREATE VIEW RP_HIS_CUSRECVCHECK1 AS
  select
       g.id,g.ad_client_id,g.ad_org_id,
       g.docno,
       g.doctype,
       g.billdate,
       g.c_customer_id,
       g.description,
       g.status,
       null as m_sale_id,
       null as m_ret_sale_id,
       g.tot_amt_actual,
       g.c_feetype_id,
       g.tot_amt_actual as collect_amt,
       0 as deduct_amt,
       g.modifieddate,
       g.amt_order

     from  b_receive g where g.status =2

     union
select
       t.id,t.ad_client_id,t.ad_org_id,
       t.docno,
       t.doctype,
       t.billdate,
       t.c_customer_id,
       t.description,
       t.status,
       t.m_sale_id,
       t.m_ret_sale_id,
       -t.tot_amt_actual as tot_amt_actual,
       t.c_feetype_id,
       0 as collect_amt,
       t.tot_amt_actual as deduct_amt,
       t.modifieddate,
       t.amt_order


     from  b_receivable t where t.status =2
/

