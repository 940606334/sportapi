CREATE VIEW RP_STOREBALANCE AS
  SELECT max(t.id) AS id,37 AS ad_client_id
,27 AS ad_org_id,t.c_customer_id
,t.c_store_id,sum(t.amt) AS amt_le,sum(DECODE(t.is_receipts,0,t.collect_amt)) AS amt_in,
sum(DECODE(t.is_receipts,1,t.collect_amt)) AS amt_out
FROM b_storebank t
WHERE t.status=2
GROUP BY t.c_customer_id,t.c_store_id
/

