CREATE VIEW RP_DAYRETAILITEM AS
  select max(b.id) as id,a.c_store_id as rp_dayretail_id,a.c_store_id,b.m_product_id,b.m_attributesetinstance_id,b.m_productalias_id,sum(b.qty) as tot_qty,sum(b.tot_amt_actual) as tot_amt
from m_retail a,m_retailitem b
where a.id=b.m_retail_id
and a.status=2
and a.billdate=to_char(sysdate,'yyyyMMdd')
group by a.c_store_id,b.m_product_id,b.m_attributesetinstance_id,b.m_productalias_id
WITH READ ONLY
/

