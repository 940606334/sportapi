CREATE VIEW M_AUTOCOMP_PRO_ITEM AS
  select max(sameproduct_id) as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,m_autocomp_id,m_product_id,
max(autoqty) as autoqty , sum(origqtycan) as origqtycan,sum(retailqty) as retailqty,sum(qty_comp) as qty_comp
from m_autocompitem a
group by  ad_client_id,ad_org_id,m_autocomp_id,m_product_id
/

