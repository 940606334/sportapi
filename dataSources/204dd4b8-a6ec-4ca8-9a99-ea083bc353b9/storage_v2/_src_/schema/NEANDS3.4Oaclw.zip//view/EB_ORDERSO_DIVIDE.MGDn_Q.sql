CREATE VIEW EB_ORDERSO_DIVIDE AS
  select EO.ID,EO.AD_CLIENT_ID,EO.AD_ORG_ID,EO.OWNERID,EO.MODIFIERID,EO.CREATIONDATE,EO.MODIFIEDDATE,EO.ISACTIVE,
       eo.docno,eo.billdate,eo.doctype,eo.source,eo.c_store_id,eo.eb_orderso_id,eo.mergdocno,
       eo.splidocno,eo.eb_logis_id,eo.shipping_type,eo.div_status as status,eo.div_er,eo.div_time
from eb_orderso eo
where eo.status=2
/

