CREATE VIEW M_IN_STORYITEM AS
  select TO_NUMBER(d.id||ascii('H')) as id,d.id as real_id,d.ad_client_id,d.ad_org_id,d.isactive,d.creationdate,d.ownerid,d.modifieddate,d.modifierid,
       TO_NUMBER(d.m_sale_id||ascii('H')) as m_in_id,d.m_product_id,d.m_attributesetinstance_id,d.c_store_location_id,
       d.qtyin qty,d.m_productalias_id,'H' as billtype
from m_saleinstoryitem d
union all
select TO_NUMBER(b.id||ascii('I')) as id,b.id as real_id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
       TO_NUMBER(b.m_ret_sale_id||ascii('I')) as m_in_id,b.m_product_id,b.m_attributesetinstance_id,b.c_store_location_id,
       b.qtyin qty,b.m_productalias_id,'I' as billtype
from m_ret_saleinstoryitem b
union all
select TO_NUMBER(c.id||ascii('J')) as id,c.id as real_id,c.ad_client_id,c.ad_org_id,c.isactive,c.creationdate,c.ownerid,c.modifieddate,c.modifierid,
       TO_NUMBER(c.m_transfer_id||ascii('J')) as m_in_id,c.m_product_id,c.m_attributesetinstance_id,c.c_store_location_id,
       c.qtyin qty,c.m_productalias_id,'J' as billtype
from m_transferinstoryitem c
union all
select TO_NUMBER(d.id||ascii('K')) as id,d.id as real_id,d.ad_client_id,d.ad_org_id,d.isactive,d.creationdate,d.ownerid,d.modifieddate,d.modifierid,
       TO_NUMBER(d.m_sale_id||ascii('K')) as m_in_id,d.m_product_id,d.m_attributesetinstance_id,d.c_store_location_id,
       d.qtyin qty,d.m_productalias_id,'K' as billtype
from m_saleinstoryitem d
union all
select TO_NUMBER(a.id||ascii('L')) as id,a.id as real_id,a.ad_client_id,a.ad_org_id,a.isactive,a.creationdate,a.ownerid,a.modifieddate,a.modifierid,
       TO_NUMBER(a.m_purchase_id||ascii('L')) as m_in_id,a.m_product_id,a.m_attributesetinstance_id,a.c_store_location_id,
       a.qty,a.m_productalias_id,'L' as billtype
from m_purchasestoryitem a
/

