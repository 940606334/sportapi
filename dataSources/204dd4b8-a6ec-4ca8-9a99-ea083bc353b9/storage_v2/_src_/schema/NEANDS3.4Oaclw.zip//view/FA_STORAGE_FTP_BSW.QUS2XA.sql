CREATE VIEW FA_STORAGE_FTP_BSW AS
  SELECT    a.ID ,a.AD_CLIENT_ID,a.AD_ORG_ID,a.M_PRODUCTALIAS_ID,a.BILLTYPE,
          a.C_PERIOD_ID,a.BILLDATE,a.DOCNO,a.DOCTYPE,a.C_STORE_ID,a.M_PRODUCT_ID ,
          a.M_ATTRIBUTESETINSTANCE_ID,a.PERCOST,a.STATE,a.CHANGEDATE,a.QTY,
          a.COSTAMOUNT,a.QTYAMOUNT,
 (CASE
					 WHEN a.billtype IN ('M_SALEIN','M_RET_SALEIN','M_TRANSFERIN','M_PURCHASEIN') THEN
								a.qty
					 ELSE
									0
						 END) as QTYIN,
 (CASE
					 WHEN a.billtype IN ('M_RET_PUROUT','M_RET_SALEOUT','M_SALEOUT','M_TRANSFEROUT','M_RETAIL') THEN
								a.qty
					 ELSE
									0
						 END)as QTYOUT,
/*((select nvl(SUM(nvl(mo.qty,0)),0)
from M_OTHER_INOUT m,M_OTHER_INOUTITEM mo
where a.m_product_id=mo.m_product_id and a.m_productalias_id=mo.m_productalias_id and
a.c_store_id=m.c_store_id and m.id=mo.m_other_inout_id and m.docno=a.docno and m.status=2
and m.isactive='Y'
)
+
(select nvl(SUM(nvl(mo1.qtydiff,0)),0)
from M_INVENTORY m1,M_INVENTORYITEM mo1
where a.m_product_id=mo1.m_product_id and a.m_productalias_id=mo1.m_productalias_id and
a.c_store_id=m1.c_store_id and m1.id=mo1.m_inventory_id and m1.docno=a.docno and m1.status=2
and m1.isactive='Y'
))
*/
 (CASE
					 WHEN a.billtype IN ('M_OTHER_INOUT','M_INVENTORY') THEN
								a.qty
					 ELSE
									0
						 END)as QTYCHANGE,
           m.PRICELIST,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE
  FROM FA_STORAGE_FTP a,m_Product m
  where a.m_product_id=m.id and a.isactive='Y'
/*  group by a.ID ,a.AD_CLIENT_ID,a.AD_ORG_ID,a.M_PRODUCTALIAS_ID,a.BILLTYPE,
          a.C_PERIOD_ID,a.BILLDATE,a.DOCNO,a.DOCTYPE,a.C_STORE_ID,a.M_PRODUCT_ID ,
          a.M_ATTRIBUTESETINSTANCE_ID,a.PERCOST,a.STATE,a.CHANGEDATE,a.QTY,
          a.COSTAMOUNT,a.QTYAMOUNT,m.PRICELIST,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,
          a.MODIFIEDDATE,a.ISACTIVE*/
with read only
/

