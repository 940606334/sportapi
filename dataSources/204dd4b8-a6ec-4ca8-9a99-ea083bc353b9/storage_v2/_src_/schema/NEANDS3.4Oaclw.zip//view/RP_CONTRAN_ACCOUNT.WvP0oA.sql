CREATE VIEW RP_CONTRAN_ACCOUNT AS
  select a.id,a.ad_client_id,a.ad_org_id,a.docno,a.billdate,a.c_orig_id,a.c_customerup_id,
       a.c_dest_id,a.c_customer_id,a.begindate,a.enddate,substr(c.billdate,1,6) as camount_month,
       b.m_retail_id,b.m_product_id,b.m_attributesetinstance_id,b.m_productalias_id,b.qty_account,
       b.priceactual,b.amt_actual,b.price_account ,b.amt_account,
       percost_analyse(substr(c.billdate,1,6),a.c_orig_id,b.m_product_id) as cost,
       percost_analyse(substr(c.billdate,1,6),a.c_orig_id,b.m_product_id)*b.qty_account as qtycost
from m_contran_account a,m_contran_accountitem b,m_retail c
where a.id=b.m_contran_account_id and b.m_retail_id=c.id and a.isactive='Y' and a.status=2
/

