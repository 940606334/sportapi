CREATE VIEW C_V_INTEGRALMIN AS
  select t.id,t.datebegin,t.dateend,t1.c_store_id,t.name,t.distype,t.content,t.integral,t.isclear,t.ismused,t.status,t.close_status, t.viptype_filter viptypefilter,t.discountlimit,t.allstore
,t.limitqty,t.INTEGRAL_LIMIT,t.vip_filter,t.integral_max,t.is_list_limit,t.MON_CYCLE,t.QTY_CYCLE,t.IS_PAYWAY,t.IFEXE,t.is_mddis,t.inner_day
,t.inner_month,nvl(t.cnt_limit,0) as cnt_limit,nvl(t.qty_limit,0) as qty_limit,t.lowdiscount,nvl(t.amtlimit,0) as amtlimit,t.CYPRODUCT_FILTER as CYPRODUCT_FILTER
,nvl(t.sola_vip_limit,0) as sola_vip_limit,nvl(t.is_counterus,'N') as is_counterus,t.nobarshow
  from C_INTEGRALMIN t, C_INTEGRALMINITEM t1
 where t.id = t1.c_integralmin_id(+)
   and t.distype in ('CON', 'DIS')
   and t.status = 2
   and t.close_status = 1
   and to_char(sysdate,'yyyymmdd') between t.datebegin and t.dateend/* edit by Selina 2017/10/14 1:21:15 */

