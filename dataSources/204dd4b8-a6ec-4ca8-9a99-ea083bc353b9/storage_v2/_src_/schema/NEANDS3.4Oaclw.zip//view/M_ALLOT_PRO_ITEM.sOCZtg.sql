CREATE VIEW M_ALLOT_PRO_ITEM AS
  select sameproduct_id as id,ad_client_id,ad_org_id,max(ownerid) as OWNERID,
max(modifierid) as MODIFIERID,max(creationdate) as CREATIONDATE,
max(modifieddate) as MODIFIEDDATE,'Y' as ISACTIVE,m_allot_id,m_product_id,
max(autoqty) as autoqty , sum(qtycan) as qtycan,sum(qtyrem) as qtyrem,sum(qty_allot) as qty_allot
from m_allotitem
group by sameproduct_id,ad_client_id,ad_org_id,m_allot_id,m_product_id
/

