CREATE VIEW RP_SALE001_2 AS
  select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,a.salebilltype,
a.dateout as BILLDATE,a.DOCNO,a.DOCTYPE,a.B_SO_ID,a.C_CUSTOMERUP_ID,a.C_STORE_ID,a.C_CUSTOMER_ID,a.c_dest_id,
a.DESCRIPTION,b.M_PRODUCT_ID,b.M_ATTRIBUTESETINSTANCE_ID,(select c.tot_amt_actual from b_soitem c where c.b_so_id=a.b_so_id and c.m_product_id=b.m_product_id and c.m_attributesetinstance_id=b.m_attributesetinstance_id) as amtso,
(select c.qty from b_soitem c where c.b_so_id=a.b_so_id and c.m_product_id=b.m_product_id and c.m_attributesetinstance_id=b.m_attributesetinstance_id) as QTYORDERED,b.QTY as QTYSALE,b.QTYOUT as QTYSALEOUT,0 as QTYRETSALE,0 as QTYRETSALEIN,b.PRICELIST,
b.TOT_AMT_LIST as AMTLISTSALE,b.TOT_AMTOUT_LIST as AMTLISTSALEOUT,0 as AMTLISTRETSALE,0 as AMTLISTRETSALEIN,
b.PRICEACTUAL,b.TOT_AMT_ACTUAL as AMTSALE,b.TOT_AMTOUT_ACTUAL as AMTSALEOUT,0 as AMTRETSALE,0 as AMTRETSALEIN,
b.DISCOUNT as DISCOUNTSALE,0 as DISCOUNTRETSALE,a.OUTERID ,null as inerid,
(select id from m_product_alias t where t.m_product_id=b.m_product_id and t.m_attributesetinstance_id=b.m_attributesetinstance_id) as m_product_alias_id,a.C_SALEDISTYPE_ID,
(select nvl(d.acost,0) from m_product d where d.id=b.m_product_id) as acost,b.qty*(select nvl(d.acost,0) from m_product d where d.id=b.m_product_id) as t_qtycost
from M_SALE a, M_SALEITEM b
--left join B_SOITEM c on a.B_SO_ID=c.B_SO_ID and b.M_PRODUCT_ID=c.M_PRODUCT_ID and b.M_ATTRIBUTESETINSTANCE_ID=c.M_ATTRIBUTESETINSTANCE_ID
--left join m_product_alias s on b.m_product_id=s.m_product_id and  b.m_attributesetinstance_id=s.m_attributesetinstance_id
--left join m_product m on b.m_product_id=m.id
where  a.ID=b.M_SALE_ID and a.OUT_STATUS=2
union all
select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,null as salebilltype,
a.datein as BILLDATE,a.DOCNO,a.DOCTYPE,null as B_SO_ID,a.C_CUSTOMERUP_ID,a.c_orig_id as C_STORE_ID,a.C_CUSTOMER_ID,a.c_store_id as c_dest_id,
a.DESCRIPTION,b.M_PRODUCT_ID,b.M_ATTRIBUTESETINSTANCE_ID,0 as amtso,
0 as QTYORDERED,0 as QTYSALE,0 as QTYSALEOUT,b.QTY as QTYRETSALE,b.QTYIN as QTYRETSALEIN,b.PRICELIST,
0 as AMTLISTSALE,0 as AMTLISTSALEOUT,b.TOT_AMT_LIST as AMTLISTRETSALE,b.TOT_AMTIN_LIST as AMTLISTRETSALEIN,
b.PRICEACTUAL,0 as AMTSALE,0 as AMTSALEOUT,b.TOT_AMT_ACTUAL as AMTRETSALE,b.TOT_AMTIN_ACTUAL as AMTRETSALEIN,
0 as DISCOUNTSALE,b.DISCOUNT as DISCOUNTRETSALE,NULL AS OUTERID,a.INerid,(select id from m_product_alias t where t.m_product_id=b.m_product_id and t.m_attributesetinstance_id=b.m_attributesetinstance_id) as m_product_alias_id,
a.C_SALEDISTYPE_ID,(select nvl(d.acost,0) from m_product d where d.id=b.m_product_id) as acost,0 as t_qtycost
from M_RET_SALE a,M_RET_SALEITEM b--,m_product_alias s,m_product m
where a.ID=b.M_RET_SALE_ID
--and b.m_product_id=s.m_product_id(+)
--and b.m_attributesetinstance_id=s.m_attributesetinstance_id(+)
--and b.m_product_id=m.id(+)
and a.IN_STATUS=2
with read only
/

