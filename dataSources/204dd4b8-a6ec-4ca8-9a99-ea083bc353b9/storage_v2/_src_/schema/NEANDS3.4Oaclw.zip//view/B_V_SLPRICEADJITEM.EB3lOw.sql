CREATE VIEW B_V_SLPRICEADJITEM AS
  select t.id,t.docno,t.priority,t.begindate,t.closedate,a.c_customer_id,b.m_product_id,DIS_DT_TYPE,b.nowprice
from B_SLPRICEADJ t,B_SLPRICEADJCUSITEM a,B_SLPRICEADJPDTITEM b
where t.id=a.b_slpriceadj_id
and t.id=b.b_slpriceadj_id
and t.status=2
and t.isactive='Y'
and t.begindate<=to_char(sysdate,'yyyymmdd')
and t.closedate>=to_char(sysdate,'yyyymmdd')
and (t.priority,a.c_customer_id,b.m_product_id,DIS_DT_TYPE) in
(select decode(max(t.priority),999999,1,max(t.priority)) as priority,a.c_customer_id,b.m_product_id,DIS_DT_TYPE
from (select id,decode(priority,1,999999,priority) as priority,begindate,closedate,DIS_DT_TYPE,status,isactive from B_SLPRICEADJ )t,
B_SLPRICEADJCUSITEM a,B_SLPRICEADJPDTITEM b
where t.id=a.b_slpriceadj_id
and t.id=b.b_slpriceadj_id
and t.status=2
and t.isactive='Y'
and t.begindate<=to_char(sysdate,'yyyymmdd')
and t.closedate>=to_char(sysdate,'yyyymmdd')
group by a.c_customer_id,b.m_product_id,t.DIS_DT_TYPE)
/

