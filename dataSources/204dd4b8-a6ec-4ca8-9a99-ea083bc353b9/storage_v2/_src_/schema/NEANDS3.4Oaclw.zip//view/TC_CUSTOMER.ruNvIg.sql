CREATE VIEW TC_CUSTOMER AS
  SELECT to_char(t.id) as vipno, g.id as disc_type,t.cardno as card_no,t.idno as id_no,t.vipname as vip_name,
t.vipename as vip_ename,decode(t.sex,'W',1,0) as sex, to_char(to_date(t.BIRTHDAY,'yyyy-mm-dd'),'mm-dd') as BIRTHDAY  FROM
c_vip t, c_viptype g where g.id= t.c_viptype_id
/

