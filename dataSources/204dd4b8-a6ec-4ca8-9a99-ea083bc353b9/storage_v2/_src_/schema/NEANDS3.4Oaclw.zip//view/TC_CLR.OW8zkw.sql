CREATE VIEW TC_CLR AS
  SELECT t.value as clr,t.name as clr_name FROM M_ATTRIBUTEVALUE t where t.clrsize=1
/

