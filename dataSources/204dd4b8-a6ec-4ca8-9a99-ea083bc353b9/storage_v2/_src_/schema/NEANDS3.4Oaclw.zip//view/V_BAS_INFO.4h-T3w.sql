CREATE VIEW V_BAS_INFO AS
  SELECT b.id,
       b.attribcode AS code,
       b.attribname AS NAME,
       a.name AS TYPE,
       b.description,0 as IMPORTED
FROM m_dimdef a, m_dim b
WHERE a.id = b.m_dimdef_id
--AND b.modifieddate>sysdate-7
/

