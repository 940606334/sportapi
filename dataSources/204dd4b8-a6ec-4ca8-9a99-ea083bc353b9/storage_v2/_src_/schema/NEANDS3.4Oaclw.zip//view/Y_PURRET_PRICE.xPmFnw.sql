CREATE VIEW Y_PURRET_PRICE AS
  SELECT id, ad_client_id, ad_org_id, docno, list_type, billdate, dateout,
       y_supplier_id, y_warehouse_id, address, remark, tot_qty, tot_qtyout,
       tot_famount, tot_famountout, pck_status AS status, out_status, au_state,
       au_pi_id, ownerid, creationdate, pcheckid AS statuserid,
       pchecktime AS statustime, outerid, outtime, modifierid, modifieddate,
       isactive, involveproduct, tot_famountout_pcheck, tax_dis, t.tot_tax_amt,
       t.tot_notax_amt
FROM y_purret t
WHERE t.status = 2
AND t.out_status = 2
/

