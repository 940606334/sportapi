CREATE VIEW C_WEBPOS_MASTERCODE AS
  SELECT m.id, m.ad_client_id, m.ad_org_id,893 as ownerid, 893 as modifierid,
       null as creationdate,null as modifieddate, m.mastercode, m.sku, m.isactive
FROM c_mastercode m
/

