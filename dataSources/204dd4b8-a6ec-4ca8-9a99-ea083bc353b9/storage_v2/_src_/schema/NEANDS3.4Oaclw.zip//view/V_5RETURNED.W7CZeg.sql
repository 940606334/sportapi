CREATE VIEW V_5RETURNED AS
  select t.id,t.ad_client_id,t.ad_org_id,t.ownerid,t.modifierid,t.creationdate,t.modifieddate,t.isactive,
       t.docno,t.billdate,t.c_store_id,t.c_dest_id,t.predateout,t.description,t.au_state,t.au_pi_id,
       t.WX_STATE as STATUS
from M_RETURNED t
where t.IN_STATE=2
and exists(select 1
from M_RETURNED_FXITEM a
where a.m_returned_id=t.id)
/

