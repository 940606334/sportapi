CREATE VIEW RP_STORETICKET AS
  select a.c_store_id as id,37 as ad_client_id,27 as ad_org_id,893 as ownerid,893 as modifierid,sysdate as creationdate,sysdate as modifieddate,'Y' as isactive,
a.docno,a.c_store_id,a.billdate,b.c_payway_id,c.name,sum(nvl(b.payamount,0)) amt
from m_retail a,m_retailpayitem b, c_payway c
where a.id=b.m_retail_id
and b.c_payway_id=c.id
and c.name like '%券'
and c.isreduce='Y'
group by a.c_store_id,a.billdate,a.docno,b.c_payway_id,c.name
with read only
/

