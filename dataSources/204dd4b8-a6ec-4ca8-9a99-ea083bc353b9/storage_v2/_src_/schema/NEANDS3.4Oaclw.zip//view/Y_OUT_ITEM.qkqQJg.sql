CREATE VIEW Y_OUT_ITEM AS
  select a.ID||ascii('A') as id,a.id as real_id,a.AD_CLIENT_ID,a.AD_ORG_ID,a.ISACTIVE,a.CREATIONDATE,a.OWNERID,a.MODIFIEDDATE,a.MODIFIERID,
a.Y_DRAW_ID||ascii('A') as Y_OUT_ID,a.Y_MATERIAL_ID,a.Y_COLOR_ID,a.FABRIC_WIDTH,a.FABRIC_WEIGHT,a.Y_SPEC_ID,a.QTY,a.QTYOUT,
c.name AS UNITNAME,d.m_Product_Id as M_PRODUCT_ID,a.OUT_STATUS as STATUS,a.Y_MATERIALALIAS_ID
from y_DRAW_item a,y_material b,y_unit c,y_draw d
where a.y_material_id=b.id
and b.USE_UNIT_ID =c.id
and a.y_draw_id=d.id
and a.status=2 --and in_status <> 2
UNION ALL
select a.ID||ascii('C') as id,a.id as real_id,a.AD_CLIENT_ID,a.AD_ORG_ID,a.ISACTIVE,a.CREATIONDATE,a.OWNERID,a.MODIFIEDDATE,a.MODIFIERID,
a.Y_PURRET_ID||ascii('C') as Y_OUT_ID,a.Y_MATERIAL_ID,a.Y_COLOR_ID,a.FABRIC_WIDTH,a.FABRIC_WEIGHT,a.Y_SPEC_ID,a.QTY,a.QTYOUT,
c.name AS UNITNAME,a.M_PRODUCT_ID,a.OUT_STATUS as STATUS,a.Y_MATERIALALIAS_ID
from y_PURRET_item a,y_material b,y_unit c
where a.y_material_id=b.id
and b.PURCHASE_UNIT_ID =c.id
and a.status=2 --and in_status <> 2
UNION ALL
select a.ID||ascii('D') as id,a.id as real_id,a.AD_CLIENT_ID,a.AD_ORG_ID,a.ISACTIVE,a.CREATIONDATE,a.OWNERID,a.MODIFIEDDATE,a.MODIFIERID,
a.Y_TRANSFER_ID||ascii('D') as Y_OUT_ID,a.Y_MATERIAL_ID,a.Y_COLOR_ID,a.FABRIC_WIDTH,a.FABRIC_WEIGHT,a.Y_SPEC_ID,a.QTY,a.QTYOUT,
c.name AS UNITNAME,null as M_PRODUCT_ID,a.OUT_STATUS as STATUS,a.Y_MATERIALALIAS_ID
from Y_TRANSFERITEM a,y_material b,y_unit c
where a.y_material_id=b.id
and b.USE_UNIT_ID =c.id
and a.status=2 --and in_status <> 2;
/

