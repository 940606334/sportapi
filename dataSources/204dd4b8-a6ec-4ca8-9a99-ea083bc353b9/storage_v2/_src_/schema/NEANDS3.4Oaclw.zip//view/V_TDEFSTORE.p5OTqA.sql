CREATE VIEW V_TDEFSTORE AS
  select id,name ||'('|| description ||')' as storename from c_store
/

