CREATE VIEW RP_Y_PURCHASE AS
  select a.ad_client_id,a.ad_org_id,a.modifierid,a.modifieddate,a.creationdate,a.ownerid,a.isactive,
a.docno,a.billdate,a.datein,a.deliverydate,a.remark,b.m_product_id,a.y_warehouse_id,a.y_supplier_id,a.status,
b.y_material_id,b.y_color_id,b.fabric_width,b.fabric_weight,b.y_spec_id,b.purchase_unit_id,
b.qty,b.qtyin,b.fprice,b.famount,b.famountin,a.m_dim1_id,b.Y_MATERIALALIAS_ID,nvl(b.send_count,0) as send_count,
nvl(b.send_count,0)-b.qty as send_diff_qty,nvl(b.send_count,0)-b.qtyin as send_diff_qtyin
 from y_purchase a,y_purchase_item b
 where a.id=b.y_purchase_id
/

