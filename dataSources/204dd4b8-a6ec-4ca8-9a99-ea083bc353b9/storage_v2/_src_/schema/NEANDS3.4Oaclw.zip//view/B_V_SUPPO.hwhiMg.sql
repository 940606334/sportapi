CREATE VIEW B_V_SUPPO AS
  select max(b.id) as id, max(a.ad_client_id) as ad_client_id,
       max(a.ad_org_id) as ad_org_id, a.id as b_po_id, a.billdate,
       a.c_store_id, a.c_supplier_id, a.description,  b.m_product_id,
       b.predatein, b.confirmdate, sum(B.QTY)QTY, sum(B.QTYMODIFY)QTYMODIFY, sum(B.QTYINIT)QTYINIT,
        sum(B.QTYOCCU)QTYOCCU,
       sum(B.QTYCONSIGN)QTYCONSIGN, sum(B.QTYREM)QTYREM,a.status
from b_po a, b_poitem b
where a.id = b.b_po_id   and a.isactive = 'Y'
group by a.id, b.m_product_id, a.billdate, a.c_store_id, a.c_supplier_id,a.status,
         a.description, b.b_po_id, b.predatein, b.confirmdate
/

