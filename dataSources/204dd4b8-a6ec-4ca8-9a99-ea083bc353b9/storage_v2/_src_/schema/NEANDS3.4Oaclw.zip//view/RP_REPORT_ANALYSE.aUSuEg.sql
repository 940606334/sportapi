CREATE VIEW RP_REPORT_ANALYSE AS
  select p.id ,p.ad_client_id ,p.ad_org_id,p.ownerid,p.modifierid,p.creationdate,p.modifieddate,p.isactive,
 u.id user_id ,c.id c_store_id , TO_NUMBER(to_char(P.creationdate,'YYYYMMDD')) as createdate ,to_char(p.creationdate, 'HH24') hour,to_char(p.creationdate, 'MI') minute,
       to_char(p.creationdate, 'HH24MI') hourmi,  round((p.modifieddate - p.creationdate) * 60 * 24 * 60)  duration,
     a.p_string filter, a2.p_string rptname
       from  ad_pinstance p, ad_pinstance_para a, ad_pinstance_para a2, users u,
     c_store c
where a.ad_pinstance_id = p.id and a.name = 'filter' and
      a2.ad_pinstance_id = p.id and a2.name = 'cxtab' and u.id = p.ownerid and
      c.id = u.c_store_id and p.creationdate > sysdate - 30
 WITH READ ONLY
/

