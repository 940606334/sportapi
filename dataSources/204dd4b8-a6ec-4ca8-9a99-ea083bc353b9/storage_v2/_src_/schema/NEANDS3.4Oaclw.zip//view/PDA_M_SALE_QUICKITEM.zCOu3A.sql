CREATE VIEW PDA_M_SALE_QUICKITEM AS
  select a.m_sale_quick_id,b.boxno,c.name,d.name ddlname,b.tot_qty from M_SALE_QUICKITEM a,b_po_boxno b,M_PRODUCT c,c_customer d
where a.b_po_boxno_id=b.id and b.m_product_id=c.id and b.c_customer_id=d.id
/

