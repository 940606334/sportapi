CREATE VIEW V_3RETURNED AS
  select t.id,t.ad_client_id,t.ad_org_id,t.ownerid,t.modifierid,t.creationdate,t.modifieddate,t.isactive,
       t.docno,t.billdate,t.c_store_id,t.c_dest_id,t.predateout,t.description,t.tot_lines,t.tot_qty,t.au_state,t.au_pi_id,
       t.JX_STATE as STATUS,t.jxuserid as STATUSERID,jxTIME as STATUSTIME,M_RET_SALE_ID,TOT_JXQTY,TOT_JXAMT,t.c_customerup_id,t.c_customer_id,t.PRICEDIS,t.CC_TYPE
from M_RETURNED t
where t.cl_state=2
/

