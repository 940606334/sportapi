CREATE VIEW RP_TRANSFER001 AS
  select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,a.dateout as changedate,--a.datein,
a.DOCNO,a.c_Orig_Id,a.C_DEST_ID,a.DESCRIPTION,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID, 0 as   qty,
  b.QTYOUT  QTYOUT ,0 as QTYIN,(case when a.in_status=1 then b.QTYOUT else 0 end)  preqtyin,0 as qtydiff,(select m.pricelist from m_product m where b.m_product_id=m.id) as PRICELIST,
  0 TOT_AMTQTY_LIST ,
  b.qtyout*(select m.pricelist from m_product m where b.m_product_id=m.id)  TOT_AMTOUT_LIST ,0 as TOT_AMTIN_LIST,
(case when a.in_status=1 then b.qtyout*(select m.pricelist from m_product m where b.m_product_id=m.id) else 0 end) as TOT_AMTPREIN_LIST,0 as TOT_AMTDIFF_LIST,
(select s.id from m_product_alias s where s.m_product_id=b.m_product_id and s.m_attributesetinstance_id=b.m_attributesetinstance_id) as m_product_alias_id,(select m.acost from m_product m where m.id=b.m_product_id) as ACOST,PERCOST_Analyse(substr(a.dateout,1,6),a.C_DEST_ID,b.m_product_id) as percost,
(select m.acost from m_product m where m.id=b.m_product_id)*b.QTYOUT as tot_amtqty_acost,
PERCOST_Analyse(substr(a.dateout,1,6),a.C_DEST_ID,b.m_product_id)*b.QTYOUT as tot_amtqty_percost,a.BILLDATE
from M_TRANSFER a,M_TRANSFERITEM b--,m_product_alias s--,m_product m
where a.ID=b.M_TRANSFER_ID
--and b.m_product_id=s.m_product_id
--and b.m_attributesetinstance_id=s.m_attributesetinstance_id
--AND B.M_PRODUCT_ID=m.id
and a.OUT_STATUS=2--and a.IN_STATUS<>2
union all
select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,--a.dateout,
a.datein as changedate,
a.DOCNO,a.c_Orig_Id,a.C_DEST_ID,a.DESCRIPTION,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,0 AS  QTY,0 as QTYOUT,b.QTYIN,0 as preqtyin,(b.QTYOUT-b.QTYIN) as qtydiff,(select m.pricelist from m_product m where b.m_product_id=m.id) as PRICELIST,
0 as TOT_AMTQTY_LIST, 0 as TOT_AMTOUT_LIST,b.qtyin*(select m.pricelist from m_product m where b.m_product_id=m.id)  TOT_AMTIN_LIST,0 as TOT_AMTPREIN_LIST,(b.qtyout-b.qtyin)*(select m.pricelist from m_product m where b.m_product_id=m.id) as TOT_AMTDIFF_LIST,
(select s.id from m_product_alias s where s.m_product_id=b.m_product_id and s.m_attributesetinstance_id=b.m_attributesetinstance_id) as m_product_alias_id,(select m.acost from m_product m where m.id=b.m_product_id) as ACOST,PERCOST_Analyse(substr(a.datein,1,6),a.C_DEST_ID,b.m_product_id) as percost,
0 as tot_amtqty_acost,0 as tot_amtqty_percost,a.BILLDATE
from M_TRANSFER a,M_TRANSFERITEM b--,m_product_alias s--,m_product m
where a.ID=b.M_TRANSFER_ID
--and b.m_product_id=s.m_product_id
--and b.m_attributesetinstance_id=s.m_attributesetinstance_id
--and b.m_product_id=m.id--and a.OUT_STATUS=2
and a.IN_STATUS=2
union all
select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,--a.dateout,
a.billdate  as changedate,
a.DOCNO,a.c_Orig_Id,a.C_DEST_ID,a.DESCRIPTION,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,b.qty as QTY,0 QTYOUT,0 QTYIN,0 as preqtyin,0 as qtydiff,(select m.pricelist from m_product m where b.m_product_id=m.id) as PRICELIST,
b.qty*(select m.pricelist from m_product m where b.m_product_id=m.id) as TOT_AMTQTY_LIST, 0 as TOT_AMTOUT_LIST,0 TOT_AMTIN_LIST,0 as TOT_AMTPREIN_LIST,0 as TOT_AMTDIFF_LIST,
(select s.id from m_product_alias s where s.m_product_id=b.m_product_id and s.m_attributesetinstance_id=b.m_attributesetinstance_id) as m_product_alias_id,(select m.acost from m_product m where m.id=b.m_product_id) as ACOST,PERCOST_Analyse(substr(a.billdate,1,6),a.C_DEST_ID,b.m_product_id) as percost,
0 as tot_amtqty_acost,0 as tot_amtqty_percost,a.BILLDATE
from M_TRANSFER a,M_TRANSFERITEM b--,m_product_alias s--,m_product m
where a.ID=b.M_TRANSFER_ID
--and b.m_product_id=s.m_product_id
--and b.m_attributesetinstance_id=s.m_attributesetinstance_id
--AND B.M_PRODUCT_ID=m.id
and a.STATUS=2
and a.out_STATUS=1
with read only
--添加BILLDATE取值为调拨单的[单据日期]凌坤20110624
/

