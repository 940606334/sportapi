CREATE VIEW V_PO_BOXITEM AS
  select b.id,a.ad_client_id,a.ad_org_id,a.id as b_po_boxno_id,b.m_product_id,b.m_attributesetinstance_id,b.m_productalias_id,b.boxqty,a.boxtype
from b_po_boxno a,b_so_matchsizeitem b
where a.b_so_matchsize_id=b.b_so_matchsize_id
--and a.status=2
union all
select a.id,a.ad_client_id,a.ad_org_id,a.id as b_po_boxno_id,b.m_product_id,b.m_attributesetinstance_id,b.m_productalias_id,b.qty as boxqty,a.boxtype
from b_po_boxno a,b_po_boxitem b
where a.id=b.b_po_boxno_id
and   a.status=2
and   a.boxtype in (4,5)
--and a.boxtype in(1,4)
WITH READ ONLY
/

