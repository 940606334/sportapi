CREATE VIEW V_M_TRANSFERMOVE AS
  select b.id,b.ad_client_id,b.ad_org_id,a.docno,a.movetype,a.billdate,a.c_org_id,a.m_transfer_id,
       a.m_ret_sale_id,to_char(a.statustime,'yyyymmdd') as submitdate,b.m_productalias_id,b.m_product_id,
       b.C_STORE_LOCATION_ID,b.C_STOREIN_LOCATION_ID,b.ORI_QTY,b.QTYOUT,a.STATUSERID,
       to_char(a.STATUSTIME,'hh24:mm:ss') as statustime,a.STATUS,b.creationdate,b.ownerid,b.modifieddate,b.modifierid
from M_TRANSFERMOVE a,M_TRANSFERMOVEITEM b
where a.id=b.m_transfermove_id
and a.isactive='Y'
order by a.billdate desc
/

