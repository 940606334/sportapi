CREATE VIEW RP_EB_BYER AS
  SELECT A.ID, A.AD_CLIENT_ID, A.AD_ORG_ID, A.OWNERID, A.Modifierid, A.CREATIONDATE,
       A.MODIFIEDDATE, A.ISACTIVE,a.dateoutin ,a.c_store_id, A.RECEIVER_NAME, A.RECEIVER_ADDRESS, A.RECEIVER_MOBILE,
       A.RECEIVER_PHONE, a.Buyer_Email AS BUYER_EMAIL, b.m_product_id,d.id as M_PRODUCTALIAS_ID ,b.m_attributesetinstance_id, SUM(b.qty) as qty, 0 as qtyin,
       SUM(b.qtyout) as qtyout,
       PERCOST_Analyse(substr(a.dateoutin, 1, 6), a.c_Store_Id, b.m_Product_Id) AS PERCOST,
       C.PRICELIST AS PRICELIST, sum(C.PRICELIST * (B.QTYOUT - B.QTYIN)) AS TOT_AMT_LIST,
       SUM(B.PAYMENT) AS TOT_AMT_ACTUAL, 0 AS RETAMT
  FROM EB_ORDERSO A, EB_ORDERSOITEM B, M_PRODUCT C,m_product_alias d
 WHERE A.ID = B.EB_ORDERSO_ID
   AND B.M_PRODUCT_ID = C.ID
   and d.m_product_id=b.m_product_id
   and b.m_attributesetinstance_id=d.m_attributesetinstance_id
   AND A.DOCTYPE <> 'RET'
   AND A.OUT_STATUS=2
 GROUP BY A.ID, A.AD_CLIENT_ID, A.AD_ORG_ID, A.OWNERID, A.Modifierid, A.CREATIONDATE,
          A.MODIFIEDDATE, A.ISACTIVE,a.dateoutin,a.c_store_id, A.RECEIVER_NAME, A.RECEIVER_ADDRESS,
          A.RECEIVER_MOBILE, A.RECEIVER_PHONE, a.Buyer_Email, b.m_product_id,d.id,b.m_attributesetinstance_id,C.PRICELIST
UNION ALL
SELECT A.ID, A.AD_CLIENT_ID, A.AD_ORG_ID, A.OWNERID, A.Modifierid, A.CREATIONDATE,
       A.MODIFIEDDATE, A.ISACTIVE,a.dateoutin ,a.c_store_id, A.RECEIVER_NAME, A.RECEIVER_ADDRESS, A.RECEIVER_MOBILE,
       A.RECEIVER_PHONE, a.Buyer_Email AS BUYER_EMAIL, b.m_product_id,d.id as M_PRODUCTALIAS_ID,b.m_attributesetinstance_id, 0 as qty, SUM(b.qtyin) as qtyin,
       0 as qtyout,
       PERCOST_Analyse(substr(a.dateoutin, 1, 6), a.c_Store_Id, b.m_Product_Id) AS PERCOST,
       C.PRICELIST AS PRICELIST, sum(C.PRICELIST * (B.QTYOUT - B.QTYIN)) AS TOT_AMT_LIST,
       0 AS TOT_AMT_ACTUAL, SUM(B.PAYMENT) AS RETAMT
  FROM EB_ORDERSO A, EB_ORDERSOITEM B, M_PRODUCT C,m_product_alias d
 WHERE A.ID = B.EB_ORDERSO_ID
   AND B.M_PRODUCT_ID = C.ID
      and d.m_product_id=b.m_product_id
   and b.m_attributesetinstance_id=d.m_attributesetinstance_id
   AND A.DOCTYPE = 'RET'
   AND A.IN_STATUS=2
 GROUP BY A.ID, A.AD_CLIENT_ID, A.AD_ORG_ID, A.OWNERID, A.Modifierid, A.CREATIONDATE,
          A.MODIFIEDDATE, A.ISACTIVE,a.dateoutin,a.c_store_id, A.RECEIVER_NAME, A.RECEIVER_ADDRESS,
          A.RECEIVER_MOBILE, A.RECEIVER_PHONE, a.Buyer_Email, b.m_product_id,d.id,b.m_attributesetinstance_id,C.PRICELIST
/

