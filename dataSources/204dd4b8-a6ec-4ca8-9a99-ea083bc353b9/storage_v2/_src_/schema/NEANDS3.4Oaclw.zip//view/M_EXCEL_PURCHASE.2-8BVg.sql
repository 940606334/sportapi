CREATE VIEW M_EXCEL_PURCHASE AS
  select g.name,e.value,f.value1,sum(t.qtyin) as qty,g.m_sizegroup_id from m_purchaseitem t,m_product g,m_attributesetinstance f
,m_attributevalue e,m_attributeinstance k where t.m_product_id=g.id
and t.m_attributesetinstance_id=f.id and k.m_attributesetinstance_id=f.id and  k.m_attributevalue_id= e.id  and g.m_sizegroup_id=e.m_attribute_id
 group by e.value,g.name,f.value1,m_sizegroup_id
 order by g.name
/

