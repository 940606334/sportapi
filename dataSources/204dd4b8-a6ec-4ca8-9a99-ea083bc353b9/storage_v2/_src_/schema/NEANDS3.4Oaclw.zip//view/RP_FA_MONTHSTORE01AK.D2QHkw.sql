CREATE VIEW RP_FA_MONTHSTORE01AK AS
  select t.id,
       t.ad_client_id,
       t.ad_org_id,
       t.ownerid,
       t.modifierid,
       t.creationdate,
       t.modifieddate,
       t.isactive,
       t.c_period_id,
       t.c_store_id,
       t.m_product_id,
       t.m_attributesetinstance_id,
       a.pricelist,
       t.qtybegin,
       t.qtybegin * a.pricelist as amtlistbeg,
       t.qtybegin * a.precost as amtcostbeg,
       t.percostbegin,
       t.costbegin,
       t.qtypurchase,
       t.qtypurchase * a.pricelist as amtlistpurchase,
       t.qtypurchase * a.precost as amtcostpurchase,
       t.amtpurchase,
       t.qtyretpur,
       t.qtyretpur * a.pricelist as amtlistretpur,
       t.qtyretpur * a.precost as amtcostretpur,
       t.amtretpur,
       t.qtysale,
       t.qtysale * a.pricelist as amtlistsale,
       t.qtysale * a.precost as amtcostsale,
       t.amtsale,
       t.qtyretsale,
       t.qtyretsale * a.pricelist as amtlistretsale,
       t.qtyretsale * a.precost as amtcostretsale,
       t.amtretsale,
       t.qtyretail,
       t.qtyretail * a.pricelist as amtlistretail,
       t.qtyretail * a.precost as amtcostretail,
       t.amtretail,
       t.qtytransferout,
       t.qtytransferout * a.pricelist as amtlisttransferout,
       t.qtytransferout * a.precost as amtcosttransferout,
       t.qtytransferin,
       t.qtytransferin * a.pricelist as amtlisttransferin,
       t.qtytransferin * a.precost as amtcosttransferin,
       t.qtyinventory,
       t.qtyinventory * a.pricelist as amtlistinventory,
       t.qtyinventory * a.precost as amtcostinventory,

       (nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v,C_OTHER_INOUTTYPE w
       where u.id=v.m_other_inout_id and u.C_OTHER_INOUTTYPE_ID = w.id
       and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and w.name <> '其他出库' and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0)+
       nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v
       where u.id=v.m_other_inout_id and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and
       u.c_other_inouttype_id is null and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0)) as qtyotherinout,

       nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v,C_OTHER_INOUTTYPE w
       where u.id=v.m_other_inout_id and u.C_OTHER_INOUTTYPE_ID = w.id
       and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and w.name = '其他出库' and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0) as QTYOTHERINOUT2,

       (nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v,C_OTHER_INOUTTYPE w
       where u.id=v.m_other_inout_id and u.C_OTHER_INOUTTYPE_ID = w.id
       and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and w.name <> '其他出库' and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0)+
       nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v
       where u.id=v.m_other_inout_id and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and
       u.c_other_inouttype_id is null and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0)) * a.pricelist as amtlistoth,

       nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v,C_OTHER_INOUTTYPE w
       where u.id=v.m_other_inout_id and u.C_OTHER_INOUTTYPE_ID = w.id
       and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and w.name = '其他出库' and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0) * a.pricelist as amtlistoth2,

       (nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v,C_OTHER_INOUTTYPE w
       where u.id=v.m_other_inout_id and u.C_OTHER_INOUTTYPE_ID = w.id
       and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and w.name <> '其他出库' and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0)+
       nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v
       where u.id=v.m_other_inout_id and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and
       u.c_other_inouttype_id is null and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0)) * a.precost as amtcostoth,

       nvl((select sum(nvl(v.qty,0)) from M_OTHER_INOUT u,M_OTHER_INOUTITEM v,C_OTHER_INOUTTYPE w
       where u.id=v.m_other_inout_id and u.C_OTHER_INOUTTYPE_ID = w.id
       and v.m_product_id=t.m_product_id and v.m_attributesetinstance_id = t.m_attributesetinstance_id and u.c_store_id=t.c_store_id and t.yearmonth=substr(u.billdate,1,6)
       and w.name = '其他出库' and u.status=2 GROUP BY v.m_product_id,v.m_attributesetinstance_id),0) * a.precost as amtcostoth2,

       t.percostdiff,
       t.costdiff,
       t.qtyend,
       t.qtyend * a.pricelist as amtlistend,
       t.qtyend * a.precost as amtcostend,
       t.percostend,
       t.costend,
       t.qtyinbegin,
       t.qtyinbegin * a.pricelist as amtlistinbeg,
       t.qtyinbegin * a.precost as amtcostinbeg,
       t.costinbegin,
       t.precostbegin,
       t.yearmonth,
       t.qtyinend,
       t.qtyinend * a.pricelist as amtlistinend,
       t.qtyinend * a.precost as amtcostinend,
       t.costinend
  from fa_monthstore t, m_product a
 where t.m_product_id = a.id
with read only
/

