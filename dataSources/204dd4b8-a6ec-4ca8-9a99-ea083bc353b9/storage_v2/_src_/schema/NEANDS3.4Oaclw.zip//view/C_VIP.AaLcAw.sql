CREATE VIEW C_VIP AS
  SELECT id, ad_client_id, ad_org_id, isactive, modifierid, creationdate,
       modifieddate, ownerid, cardno, c_viptype_id,c_viptype_id as viptype_id, idno, vipname, vipename, sex,
       birthday, substr(birthday, 5, 2) birthmonth,substr(birthday, 5, 4) birthmad, validdate, creditremain,
       country, c_city_id, c.c_opencardtype_id, c.lm_card, address, post, phone,
       mobil, email, c_store_id, c_customer_id, c_customerup_id, integral,
       pass_word, enterdate, babyname,
       (CASE
            WHEN nvl(validdate, '30011025') >=
                 to_number(to_char(SYSDATE, 'YYYYMMDD')) and c.opencard_status=2 THEN
             'Y'
            ELSE
             'N'
        END) AS vipstate, best_time, building, saler, storecardno,
       opencard_status, opencarderid, opencardtime, description, description2,
       oldstore, c_servicearea_id,
       nvl(trunc(months_between(to_date(to_char(SYSDATE, 'YYYYMMDD'), 'YYYYMMDD'),
                                 to_date(to_char(birthday), 'YYYYMMDD')) / 12), 0) AS age,
       opencarddate, c.isup, c.isoff, c.dateup, c.dateoff, c.imageurl,
       c.hr_employee_id, c.retail_filter, c.ispreclient, c.ispreparents,
       c.prebirthdate
       --these three paramaters are added by czl on 2011.05.6
      , c.parentsposition, c.parentsprofessional, c.microaccount,
       c.babybirth AS babybirthday, c.babyidno,
       /*nvl(trunc(months_between(to_date(to_char(SYSDATE, 'YYYYMMDD'), 'YYYYMMDD'),
                                 to_date(to_char(c.babybirth), 'YYYYMMDD')) / 12),
            0) AS babyage,*/ s_babyname, sex2, education, hmonincome, int_ch_gift,
       when_come, inf_source, linkstyles, marital, hometown, msnqq, weibo,
       homeaddress, companyname, companyaddress, job, position, monthincome,
       (select case
       when t.lastdate is null then 5
       when sysdate-to_date(t.LASTDATE,'yyyyMMdd')<=90 then 1
       when sysdate-to_date(t.LASTDATE,'yyyyMMdd')<=180 then 2
        when sysdate-to_date(t.LASTDATE,'yyyyMMdd')<=360 then 3
          else 4 end
       from fa_vipacc t
       where t.c_vip_id=c.id) as VIP_STATUS,
       c.c_integralarea_id ,m_retail_id,INTL_STATUS--added by hzy 2012-10-26
FROM c_client_vip c
--增加IMAGEURL、HR_EMPLOYEE_ID字段凌坤2011.5.13
--增加c.PARENTSPOSITION,c.PARENTSPROFESSIONAL,c.MICROACCOUNT,c.BABYBIRTH as BABYBIRTHDAY,c.BABYIDNO，BABYAGE字段凌坤20110615
--增加字段S_BABYNAME,SEX2，EDUCATION，HMONINCOME，INT_CH_GIFT ，WHEN_COME，INF_SOURCE，LINKSTYLES 陈婷婳20110809
/

