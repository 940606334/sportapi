CREATE VIEW RP_BI_WSM_001 AS
  select e.c_store_id,e.m_product_id,nvl(sum(f.qty),0) as qty
from (
    select a.id as c_store_id,b.id as m_product_id
    from c_store a,m_product b
    where a.isretail='Y' and a.isactive='Y'
    and not exists
        (select 1
         from m_retail c,m_retailitem d
         where c.id=d.m_retail_id and
               c.billdate between to_char(NEXT_DAY(sysdate,'星期一')-14,'YYYYMMDD') and to_char(NEXT_DAY(sysdate,'星期一')-8,'YYYYMMDD')
               and c.status=2 and a.id=c.c_store_id
               and b.id=d.m_product_id
        )
    ) e,fa_storage f
where e.c_store_id=f.c_store_id(+) and e.m_product_id=f.m_product_id(+)
group by e.c_store_id,e.m_product_id
/

