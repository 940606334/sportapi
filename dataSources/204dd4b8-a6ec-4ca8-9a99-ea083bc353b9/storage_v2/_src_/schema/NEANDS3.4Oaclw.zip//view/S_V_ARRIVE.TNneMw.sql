CREATE VIEW S_V_ARRIVE AS
  select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,a.c_supplier_id,a.deliverydate,b.s_material_id,
  b.priceactual,b.tot_amtout_actual,a.receiptdate,b.qtyin,b.qtyout,b.tot_amtin_actual,a.c_supplier2_id,
  (select sum(TOT_AMTOUT_ACTUAL) from s_purchase where status=2 and c_supplier_id=a.c_supplier_id group by c_supplier_id) as tot_amt,
  (select sum(tot_amt_actual) as a_amt from B_pay where status=2 and a.c_supplier_id=c_supplier_id  group by c_supplier_id) as a_amt,

  (select t1.TOT_AMTOUT_ACTUAL-nvl(a_amt,0) from
  (select c_supplier_id,sum(TOT_AMTOUT_ACTUAL) as TOT_AMTOUT_ACTUAL from s_purchase where status=2  group by c_supplier_id) t1 left outer join
  (select c_supplier_id,sum(tot_amt_actual) as a_amt from B_pay where status=2  group by c_supplier_id) t2
  on t1.c_supplier_id=t2.c_supplier_id where t1.c_supplier_id=a.c_supplier_id)-
  (select nvl(sum(b1.tot_amt_actual),0) as Chargeback
from  B_PAYABLE b1,c_feetype b2
where b1.c_feetype_id=b2.id and b1.status=2 and b2.ISFEEMIN='Y' and ISSYSTEM='N' and b1.c_supplier_id=a.c_supplier_id) as pay,
 (select nvl(sum(b1.tot_amt_actual),0) as Chargeback
from  B_PAYABLE b1,c_feetype b2
where b1.c_feetype_id=b2.id and b1.status=2 and b2.ISFEEMIN='Y' and ISSYSTEM='N' and b1.c_supplier_id=a.c_supplier_id) as Chargeback




   from s_purchase a,s_purchaseitem b where a.id=b.s_purchase_id and a.status=2

 with read only
/

