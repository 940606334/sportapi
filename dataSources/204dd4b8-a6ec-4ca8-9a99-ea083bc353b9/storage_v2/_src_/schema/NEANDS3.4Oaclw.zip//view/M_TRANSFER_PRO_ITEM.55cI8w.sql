CREATE VIEW M_TRANSFER_PRO_ITEM AS
  select max(id) as id,ad_client_id,ad_org_id,max(ownerid) as ownerid,
       max(modifierid) as modifierid,max(creationdate) as creationdate,
       max(modifieddate) as modifieddate,'y' as isactive,
       mp.m_transfer_id,mp.m_product_id,sum(mp.qty) qty,sum(mp.qtyout) qtyout,sum(mp.qtyin) qtyin,
       sum(mp.qtydiff) qtydiff,avg(mp.pricelist) pricelist,sum(mp.tot_amtqty_list ) tot_amt_list ,
       sum(mp.tot_amtout_list) tot_amtout_actual,sum(mp.tot_amtin_list) tot_amtin_actual
from m_transferitem  mp
group by ad_client_id,ad_org_id,mp.m_transfer_id,mp.m_product_id
with read only
/

