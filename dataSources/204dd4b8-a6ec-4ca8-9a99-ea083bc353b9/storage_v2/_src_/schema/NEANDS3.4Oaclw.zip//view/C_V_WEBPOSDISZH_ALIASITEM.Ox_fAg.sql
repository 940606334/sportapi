CREATE VIEW C_V_WEBPOSDISZH_ALIASITEM AS
  select a.id,a.c_webposdis_id,GET_FITLER_SQL(a.ALIAS_FILTER) as ALIAS_FILTER,a.comparetype,a.qty,a.relationtype,a.comparetypeamt,a.tot_amt_actual
from C_WEBPOSDIS t,C_WEBPOSDISZH_ALIASITEM a
where t.id=a.c_webposdis_id
and t.isactive='Y'and t.close_status=1
and t.STATUS = 2
and to_char(sysdate+1,'yyyymmdd')>=DATEBEGIN
and to_char(sysdate,'yyyymmdd')<=DATEEND/* edit by Selina 2017/2/24 15:19:09 */

