CREATE VIEW RP_RETAIL_NOCOST AS
  select b.id,
       b.ad_client_id,
       b.ad_org_id,
       b.ownerid,
       b.isactive,
       a.billdate,
       a.docno,
       a.retailbilltype,
       a.ownerid as creater,--add by chenzheling
       a.c_store_id,
       a.description,
       a.c_vip_id,
       b.salesrep_id,
       b.m_product_id,
       b.m_attributesetinstance_id,
       b.qty,
       b.pricelist,
       b.tot_amt_list,
       b.priceactual,
       b.tot_amt_actual,
       b.discount,
       b.type,
       a.refno,
       n.id as m_product_alias_id,
       b.description item_description,b.c_markbaltype_id/*,
       (select t2.TOT_AMT_MARK
       from C_STOREMARK t1,C_STOREMARKITEM t2
       where t1.id=t2.C_STOREMARK_ID
       and   t1.c_store_id=a.c_store_id
       and   t1.yearmonth=substr(a.billdate,1,6)
       and   t2.monthdate=a.billdate) TOT_AMT_MARK,

       b.tot_amt_actual/(select t2.TOT_AMT_MARK
       from C_STOREMARK t1,C_STOREMARKITEM t2
       where t1.id=t2.C_STOREMARK_ID
       and   t1.c_store_id=a.c_store_id
       and   t1.yearmonth=substr(a.billdate,1,6)
       and   t2.monthdate=a.billdate) com_rate*/
  from m_retail        a,
       m_retailitem    b,
       m_product_alias n
 where a.id = b.m_retail_id
   and b.m_product_id=n.m_product_id
   and b.m_attributesetinstance_id=n.m_attributesetinstance_id
   and a.status = 2
   with read only
/

