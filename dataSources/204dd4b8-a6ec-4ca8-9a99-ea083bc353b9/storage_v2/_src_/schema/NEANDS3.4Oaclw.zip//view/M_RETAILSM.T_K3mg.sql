CREATE VIEW M_RETAILSM AS
  select d.id, d.ad_client_id,d.ad_org_id,d.ownerid,d.modifierid,d.modifieddate,d.creationdate,d.isactive,
    m.docno ,m.doctype, m.billdate, m.c_retailtype_id,m.c_store_id, m.c_vip_id ,m.description ,
    d.m_productalias_id ,	d.m_product_id,d.m_attributesetinstance_id ,
    d.qty,d.pricelist , m.discount ,d.priceactual,d.salesrep_id, d.tot_amt_actual ,d.tot_amt_list ,
    d.c_markbaltype_id
from m_retail m,m_retailitem d
where m.id=d.m_retail_id and m.status=2
/

