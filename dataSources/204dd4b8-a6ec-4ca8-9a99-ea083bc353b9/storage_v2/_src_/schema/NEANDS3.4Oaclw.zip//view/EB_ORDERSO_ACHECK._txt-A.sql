CREATE VIEW EB_ORDERSO_ACHECK AS
  SELECT id AS id, ad_client_id, ad_org_id, isactive, modifierid, creationdate, modifieddate,
       ownerid, DOCNO, DOCTYPE, BILLDATE, C_STORE_ID, C_CUSTOMER_ID, C_CUSTOMERUP_ID,
       DESCRIPTION, TID, BUYER_MEMO, SELLER_MEMO, SHIPPING_TYPE, price, num, total_fee,
       TYPE, post_fee, SELL_STATUS,OUT_STATUS , outtime AS statustime,
       outerid AS statuserid, IN_STATUS, intime, inerid, BOX_STATUS, boxtime, boxerid,
       SHIPPING_FEE, EB_ORDERSO_ID, MERGDOCNO, SPLIDOCNO, EB_LOGIS_ID, a.tstore,
       a.seller_tel, a.seller_address, a.isvirtual, a.tvirtualid, a.fastno, a.SOURCE,
       a.ACHECKED AS STATUS, a.ACHECKER, a.ACHECKDATE, a.ctype, a.RECEIVER_ADDRESS, a.RECEIVER_NAME,
       a.BUYER_MESSAGE, a.BUYER_NICK, a.ALIPAY_NO, a.MODIFIEDER, a.CREATEDER, a.PAYMENT,
       a.DISCOUNT_FEE, a.RECEIVED_PAYMENT, a.ADJUST_FEE, a.RECEIVER_MOBILE,
       a.RECEIVER_PHONE, a.RECEIVER_ZIP, a.REAL_POINT_FEE, a.POINT_FEE, a.CONSIGN_TIME,
       a.END_TIME, a.PAY_TIME, a.MODIFIED, a.CREATED, a.c_orig_id, a.VEERID, a.VE_STATUS,
       a.VETIME, a.qtyfcan,a.dateoutin as dateout,a.seller_message,a.ACHECK_REMARK
  FROM EB_ORDERSO a
 WHERE a.status = 2
   AND a.isactive = 'Y'
   AND a.VE_STATUS = 2
	 AND a.OUT_STATUS = 2


/*select a.id,a.ad_client_id,a.ad_org_id,a.isactive,a.modifierid,a.creationdate,a.modifieddate,a.ownerid,
       a.DOCNO,a.DOCTYPE,a.BILLDATE,a.C_STORE_ID,a.C_CUSTOMER_ID,a.C_CUSTOMERUP_ID,a.DESCRIPTION,a.TID,
       a.BUYER_MEMO,a.SELLER_MEMO,a.SHIPPING_TYPE,a.price,a.num,a.total_fee,a.TYPE,a.post_fee,a.SELL_STATUS,
       a.STATUS as out_status,a.statustime,a.statuserid,a.IN_STATUS,a.intime,a.inerid,a.BOX_STATUS,a.boxtime,a.boxerid,
       a.SHIPPING_FEE,a.EB_ORDERSO_ID,a.MERGDOCNO,a.SPLIDOCNO,a.EB_LOGIS_ID,a.tstore,a.seller_tel,a.seller_address,
       a.isvirtual,a.tvirtualid,a.fastno,a.SOURCE,a.ACHECKED as status,a.ACHECKER,a.ACHECKDATE,a.ctype,a.RECEIVER_ADDRESS,
       a.RECEIVER_NAME,a.BUYER_MESSAGE,a.BUYER_NICK,a.ALIPAY_NO,a.MODIFIEDER,a.CREATEDER,a.PAYMENT,a.DISCOUNT_FEE,
       a.RECEIVED_PAYMENT,a.ADJUST_FEE,a.RECEIVER_MOBILE,a.RECEIVER_PHONE,a.RECEIVER_ZIP,a.REAL_POINT_FEE,
       a.POINT_FEE,a.CONSIGN_TIME,a.END_TIME,a.PAY_TIME,a.MODIFIED,a.CREATED,a.c_orig_id,a.VEERID,a.VE_STATUS,
       a.VETIME,a.qtyfcan,a.dateout,a.seller_message,null as ACHECK_REMARK
from EB_V_OUT a,EB_ORDERSO b
where b.docno = a.DOCNO
and b.status = 2
and b.VE_STATUS = 2
and b.OUT_STATUS = 2*/

