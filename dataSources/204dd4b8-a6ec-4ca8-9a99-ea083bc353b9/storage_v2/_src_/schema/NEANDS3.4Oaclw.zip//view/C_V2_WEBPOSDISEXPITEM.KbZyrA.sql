CREATE VIEW C_V2_WEBPOSDISEXPITEM AS
  select a.id,a.c_webposdis_id,GET_FITLER_SQL(a.exproduct_filter) as exproduct_filter,a.qty,a.relationtype
from C_WEBPOSDIS t,C_WEBPOSDISEXPITEM a
where t.id=a.c_webposdis_id
and t.webtype=2 and t.close_status=1
and t.isactive='Y'/* edit by Selina 2017/2/24 15:16:36 */

