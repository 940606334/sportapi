CREATE VIEW Y_IN AS
  SELECT a.id || ascii('A') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.ownerid, a.modifierid, a.creationdate, a.modifieddate, a.isactive,
       'Y_PURCHASEIN' AS billtype, a.docno, a.list_type, a.billdate, a.datein,
       b.NAME AS origname, a.y_warehouse_id, a.remark, a.in_status AS status,
       a.au_state, a.au_pi_id, a.tot_qty, a.tot_qtyin, a.statuserid,
       a.statustime, NULL AS outerid, NULL AS outtime, a.inerid, a.intime,
       a.involveproduct AS involveproduct, a.m_dim1_id AS m_dim1_id,
       a.oc_status AS oc_status, a.ocer AS ocer, a.octime AS octime,
       a.check_status, a.checkerid, a.checktime, a.datewh, a.tot_fgood_qty,
       a.tot_good_qty, a.tot_defect_qty
FROM y_purchase a, c_supplier b
WHERE a.y_supplier_id = b.id AND a.status = 2 --and a.in_status = 1
UNION ALL
SELECT a.id || ascii('C') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.ownerid, a.modifierid, a.creationdate, a.modifieddate, a.isactive,
       'Y_DRAWRETIN' AS billtype, a.docno, a.list_type, a.billdate, a.datein,
       b.NAME AS origname, a.y_warehouse_id, a.remark, a.in_status AS status,
       a.au_state, a.au_pi_id, a.tot_qty, a.tot_qtyin, a.statuserid,
       a.statustime, NULL AS outerid, NULL AS outtime, a.inerid, a.intime,
       NULL AS involveproduct, a.m_dim1_id AS m_dim1_id, NULL AS octime,
       NULL AS oc_status, NULL AS ocer, NULL AS check_status, NULL AS checkerid,
       NULL AS checktime, NULL AS datewh, 0 AS tot_fgood_qty, 0 AS tot_good_qty,
       0 AS tot_defect_qty
FROM y_drawret a, y_warehouse b
WHERE a.y_origwarehouse_id = b.id(+) AND a.status = 2 --and a.in_status = 1
UNION ALL
SELECT a.id || ascii('D') AS id, a.id AS real_id, a.ad_client_id, a.ad_org_id,
       a.ownerid, a.modifierid, a.creationdate, a.modifieddate, a.isactive,
       'Y_TRANSFERIN' AS billtype, a.docno, BILLTYPE as list_type,
       DATEOUT as billdate, a.datein, b.NAME AS origname,
       Y_DESTWAREHOUSE_ID as y_warehouse_id, DESCRIPTION AS REMARK,
       a.in_status AS status, a.au_state, a.au_pi_id, a.tot_qty, a.tot_qtyin,
       a.statuserid, a.statustime, a.outerid, a.outtime, a.inerid, a.intime,
       NULL AS involveproduct, NULL AS M_DIM1_ID, NULL AS octime,
       NULL AS oc_status, NULL AS ocer, NULL AS check_status, NULL AS checkerid,
       NULL AS checktime, NULL AS datewh, 0 AS tot_fgood_qty, 0 AS tot_good_qty,
       0 AS tot_defect_qty
FROM Y_TRANSFER a, y_warehouse b
WHERE a.Y_WAREHOUSE_ID = b.id(+) AND a.status = 2 and a.out_status=2--and a.in_status = 1;
/

