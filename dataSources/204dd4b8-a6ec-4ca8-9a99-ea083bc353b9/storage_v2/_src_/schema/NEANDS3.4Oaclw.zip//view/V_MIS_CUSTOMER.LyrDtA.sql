CREATE VIEW V_MIS_CUSTOMER AS
  SELECT t.id || 0 AS id,
       t.code AS contactnum,
       t.name AS contactname_l,
       a.name AS area,
       (SELECT code FROM c_customer WHERE id = t.c_customerup_id) AS contactcode,
       t.contacter AS principal,
       (SELECT decode(id, 1, 0, 6, 1, 2)
        FROM c_cusrank
        WHERE id = t.c_cusrank_id) AS contactlve,0 as IMPORTED
FROM c_customer t, c_area a
WHERE t.c_area_id = a.id(+)
     --and t.modifieddate>sysdate-7
AND t.isactive = 'Y'
UNION ALL
SELECT b.id || 1,
       b.code,
       b.name,
       a.name,
       (SELECT code FROM c_customer WHERE id = b.c_customerup_id) AS contactcode,
       b.contactor AS principal,
       (SELECT decode(id, 1, 0, 6, 1, 2)
        FROM c_cusrank
        WHERE id = t.c_cusrank_id) AS contactlve,0 as IMPORTED
FROM c_store b, c_area a, c_customer t
WHERE b.c_customer_id = t.id
AND b.c_area_id = a.id(+)
     --and b.modifieddate>sysdate-7
AND t.isactive = 'Y'
/

