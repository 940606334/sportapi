CREATE VIEW RP_YSSTORE AS
  SELECT rownum AS a, h.id,h.ad_client_id,h.ad_org_id,h.c_store_id,h.billdate,h.type,h.docno,
       h.description,h.qty,h.priceactual,h.collect_amt,h.deduct_amt,h.discount_amt,h.total,
       lag("TOTAL", 1, NULL) over(PARTITION BY c_store_id ORDER BY billdate,statustime,docno,type) last_hire,h.statustime
FROM (SELECT k.*,
              SUM(k.tot_amt_actual) over(PARTITION BY c_store_id ORDER BY billdate,statustime,docno,type rows 10000000 preceding) AS "TOTAL"
                  from(
                  select id,ad_client_id,ad_org_id,c_store_id,billdate,type,docno,description,sum(qty) as qty,
                     sum(priceactual) priceactual,sum(tot_amt_actual) as tot_amt_actual,sum(deduct_amt) as deduct_amt,
                     sum(collect_amt) as collect_amt,sum(discount_amt) as discount_amt,statustime
       FROM (SELECT g.id, g.ad_client_id, g.ad_org_id,g.c_store_id,g.billdate,b.description as type,
                    g.docno,g.description,0 as qty,0 as priceactual,-g.collect_amt as tot_amt_actual,
                    0 as deduct_amt,-g.collect_amt as collect_amt,0 as discount_amt,g.statustime
              FROM B_STOREBANK g,C_STORECOSTTYPE b
              WHERE g.status = 2
              and   g.isactive='Y'
              and   g.is_receipts=0
              and   g.c_storecosttype_id=b.id
              UNION
              SELECT t.id, t.ad_client_id, t.ad_org_id,t.c_store_id,t.billdate,t.type,
                     t.docno,t.description,t.qty,t.priceactual,t.tot_amt_actual,t.deduct_amt,
                     t.collect_amt,t.discount_amt,t.statustime
              FROM (
                     SELECT distinct a.id,a.ad_client_id,a.ad_org_id,a.c_store_id,a.billdate,tt.description as type,
                            a.docno,a.description,a.tot_qty as qty,a.tot_amt_actual as priceactual,a.tot_amt_actual,
                            a.tot_amt_actual as deduct_amt,0 as collect_amt,0 as discount_amt,a.statustime
                     FROM m_retail a,AD_LIMITVALUE tt
                     WHERE a.status=2
                     and   a.isactive='Y'
                     and trim(a.RETAILBILLTYPE)=tt.value
                     and tt.ad_limitvalue_group_id=662
                     UNION
                     --优惠金额
                     SELECT  a.id,a.ad_client_id,a.ad_org_id,a.c_store_id,a.billdate,b.description as type,
                            a.docno,a.description,0 as qty,0 as priceactual,-nvl(a.dis_amt,0) as tot_amt_actual,
                            0 as deduct_amt,0 as collect_amt,nvl(a.dis_amt,0) as discount_amt,a.statustime
                     FROM B_STOREBANK a,C_STORECOSTTYPE b
                     WHERE a.status=2
                     and   a.isactive='Y'
                     and   a.is_receipts=0
                     and   a.c_storecosttype_id=b.id
                     UNION
                     --店铺应收单
                     SELECT a.id,a.ad_client_id,a.ad_org_id,a.c_store_id,a.billdate,b.description as type,
                            a.docno,a.description,0 as qty,0 as priceactual,a.COLLECT_AMT as tot_amt_actual,
                            COLLECT_AMT as deduct_amt,0 as collect_amt,0 as discount_amt,a.statustime
                     FROM B_STOREBANK a,C_STORECOSTTYPE b
                     WHERE a.status=2
                     and   a.isactive='Y'
                     and   a.is_receipts=1
                     and   a.c_storecosttype_id=b.id
                     order by billdate,statustime,docno,type) t)
                     group by id,ad_client_id,ad_org_id,c_store_id,billdate,type,docno,description,statustime
                     order by billdate,statustime,docno,type) k
       WHERE EXISTS (SELECT 1 FROM dual WHERE k.c_store_id = c_store_id)) h
ORDER BY billdate,statustime,docno,type
/

