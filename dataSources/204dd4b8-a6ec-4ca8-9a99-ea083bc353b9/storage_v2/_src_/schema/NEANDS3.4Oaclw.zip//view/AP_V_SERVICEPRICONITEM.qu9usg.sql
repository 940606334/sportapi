CREATE VIEW AP_V_SERVICEPRICONITEM AS
  SELECT id, ad_client_id, ad_org_id, ownerid, modifierid, creationdate,
       modifieddate, isactive, ap_servicesapply_id AS ap_v_servicepricon_id,
       m_product_id, m_productalias_id, ap_units, delqty, ap_qualityreason_id,
       deladvice, ap_liability_id, description, qty, del_status,
       m_attributesetinstance_id, factorydate, to_ret, repairdate, c_supplier_id,
       ret_discount, backdate, to_backdate, back_cusdate, hr_v_employeescoat_id,
       reworkatm, end_ret, m_transfer_id, m_ret_sale_id, ap_store, dateout,
       datein, c_vip_id, image, ship_addr, dest_addr, fastamt, handleadvice,
       confirmadvice,ISSALE,QUESTION
FROM ap_servicesapplydelitem
/

