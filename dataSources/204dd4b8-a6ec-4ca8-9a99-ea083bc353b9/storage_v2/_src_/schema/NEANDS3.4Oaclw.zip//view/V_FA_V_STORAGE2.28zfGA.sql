CREATE VIEW V_FA_V_STORAGE2 AS
  SELECT a.ID, a.c_store_id,(select e.m_storageno_id from M_STORAGESKU e where e.c_store_id = a.c_store_id and e.m_product_id = a.m_product_id) as m_storageno_id,
               a.m_product_id, a.m_attributesetinstance_id, a.qty, a.qtypreout,
               a.qtyprein,a.m_productalias_id,0 as pricelist,a.isactive
        FROM fa_storage a
        WHERE (a.QTY <> 0 OR a.QTYPREOUT <> 0 OR a.QTYPREIN <> 0)
with read only
/

