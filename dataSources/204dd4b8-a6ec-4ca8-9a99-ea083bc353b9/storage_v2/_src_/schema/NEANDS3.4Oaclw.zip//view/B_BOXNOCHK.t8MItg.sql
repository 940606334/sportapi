CREATE VIEW B_BOXNOCHK AS
  select  a.id,a.ad_client_id,a.ad_org_id,a.b_po_box_id,a.boxno,a.tot_qty,a.description,a.test_status as status,a.statuserid,a.statustime,
a.in_status,a.inerid,a.intime,a.isactive,a.modifierid,a.modifieddate,a.ownerid,a.creationdate,a.testid,a.testtime,a.b_so_id,a.out_status,a.boxtype,a.testdate,
a.m_product_id,a.m_color_id,a.m_box_jh_id
from B_PO_BOXNO a
Where a.isactive='Y'
and STATUS=2
and a.close_status=1
/

