CREATE VIEW M_STOCKCONDITION_UNITEM AS
  select mso.docno,mso.m_stockcondition_id,max(mso.id) id,max(mso.ad_client_id) ad_client_id ,max(mso.ad_org_id) ad_org_id,
       max(mso.ownerid) ownerid,max(mso.modifierid) modifierid,
       max(mso.creationdate) creationdate,max(mso.modifieddate) modifieddate,'Y' as isactive
from M_STOCK_OCCUPYITEM mso
where exists (
      select distinct mso.m_stockcondition_id,mso.docno
      from M_STOCK_OCCUPYITEM ms
      where ms.qtycan<ms.qty and ms.m_stockcondition_id=mso.m_stockcondition_id and
            ms.docno=mso.docno
  )
group by mso.docno,mso.m_stockcondition_id
/

