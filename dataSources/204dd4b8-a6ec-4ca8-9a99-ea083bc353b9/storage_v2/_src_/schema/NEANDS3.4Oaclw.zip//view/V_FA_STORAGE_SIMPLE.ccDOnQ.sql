CREATE VIEW V_FA_STORAGE_SIMPLE AS
  select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,
a.c_store_id,a.m_product_id,a.m_attributesetinstance_id,a.qty,a.qtypreout,a.qtyprein,
(nvl(a.qty, 0) - nvl(a.qtypreout, 0) + nvl(a.qtyprein, 0)) as qtyvalid,
case when nvl(a.qty, 0) >= nvl(a.qty, 0) - nvl(a.qtypreout, 0)-nvl(a.QTY_FREEZE,0)
then nvl(a.qty, 0) - nvl(a.qtypreout, 0)-nvl(a.QTY_FREEZE,0)
else nvl(a.qty, 0) end as qtycan/*可配*/,
b.pricelist,b.pricelist * a.qty as amt_priceqty,
b.pricelist * a.qtypreout as amt_priceqtypreout,
b.pricelist * a.qtyprein as amt_priceqtyprein,
b.pricelist * (nvl(a.qty, 0) - nvl(a.qtypreout, 0) + nvl(a.qtyprein, 0)) as amt_priceqtyvalid,
a.m_productalias_id
from fa_storage a, m_product b
where a.m_product_id = b.id
and (a.qty<>(select decode(ad_param_value(a.ad_client_id, 'portal.4078', 'true'),'false',0,0.01) qty from dual)
or a.qtypreout<>0
or a.qtyprein<>0)
with read only
/

