CREATE VIEW RP_RETAILMARK04 AS
  select b.id,b.ad_client_id,b.ad_org_id,b.c_store_id,c.monthdate,c.tot_amt_mark,0 as day_amt
from c_storemark b,c_storemarkitem c
where b.id=c.c_storemark_id and b.isactive='Y'
union all
select a.id,a.ad_client_id,a.ad_org_id,a.c_store_id,a.billdate as monthdate,0 as tot_amt_mark,a.tot_amt_actual as day_amt
from m_retail a
where a.status=2
with read only
/

