CREATE VIEW M_PUR_CHECKITEM AS
  SELECT id, ad_client_id, ad_org_id, isactive, creationdate, ownerid,
       modifieddate, modifierid, m_purchase_id AS m_pur_check_id, orderno,
       m_product_id, m_attributesetinstance_id, qty, qtyin, pricelist,
       priceactual, pricedeclare, tariff, tariffdiscount, tax, taxdiscount,
       discount, description, tot_amt_list, tot_amt_actual, tot_amt_declare,
       tot_amt_tariff, tot_amt_tax, tot_amt_pay, tot_amtin_list,
       tot_amtin_actual, tot_amtin_tariff, tot_amtin_declare, tot_amtin_tax,
       tot_amtin_pay,  qtydiff, pricecheck, tot_amtin_pcheck,
       qtyconsign, qtyrem, qtyoccu, addsdesc, precost, tot_amt_precost,
       tot_amtin_precost, m_productalias_id, dateguarantee, pricemodify,
       amt_deduction, amt_fee, tot_amtin_pchecktax, c_cur_amt, tax_amt,
       tax_amtcount, tot_amt_curactual, tot_amt_cur, tot_amt_other, tax_dis,
       qty_inved, qtyinved, amtinved, isacc, good_qty, defect_qty, notax_amt,
       isinv, y_price_actual, y_tot_amt_actual, fgood_qty, defectremark,
       deladvice, check_description
FROM m_purchaseitem
/

