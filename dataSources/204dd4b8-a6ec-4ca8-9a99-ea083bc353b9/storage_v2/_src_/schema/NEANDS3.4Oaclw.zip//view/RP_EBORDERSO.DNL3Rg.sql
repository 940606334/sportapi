CREATE VIEW RP_EBORDERSO AS
  SELECT a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.creationdate, a.modifierid,
			 a.modifieddate, a.ISACTIVE, a.doctype, a.dateoutin, a.c_store_id, a.C_ORIG_ID,
			 b.m_product_id, b.m_attributesetinstance_id, s.id AS M_PRODUCTALIAS_ID,
			 /*start here*/ c.pricelist,
			 PERCOST_Analyse(substr(a.dateoutin, 1, 6), a.c_store_id, b.m_product_id) AS PERCOST,
			 SUM(b.qtyout) AS qty, 0 AS qtyin,
			 SUM(DECODE(NVL(b.qty, 0), 0, 0, (decode(b.qty,0,0,b.payment / b.qty)) * b.qtyout)) AS TOT_PAYMENT,
			 (PERCOST_Analyse(substr(a.dateoutin, 1, 6), a.c_store_id, b.m_product_id) *
				SUM(b.qtyout)) AS TOT_COST, c.pricelist * SUM(b.qtyout) AS STANDARD_PRICE,
			 /*end here*/ 0 AS TOT_AMTRET_ACTUAL, 0 AS BACK_COST, 0 AS BACK_PRICE, d.oriname,
			 a.veerid,
			 decode(SUM(b.qty), 0, 0, AVG(decode(b.qty, 0, 0, b.payment / b.qty))) AS PRICEACTUAL,
			 SUM(b.payment) AS TOT_AMT_LIST,
			 decode(SUM(b.qty),
							 0,
							 0,
							 SUM(b.qtyout) * AVG(decode(b.qty, 0, 0, b.payment / b.qty))) AS TOT_AMT_ACTUAL,
			 a.promotion, a.ADJUST_FEE,a.id as eb_orderso_id,a.ACTCOUPONAMT
	FROM eb_orderso a, eb_ordersoitem b, m_product c, m_product_alias s, EB_STORECOMPARE d
 WHERE a.id = b.eb_orderso_id
	 AND b.m_product_id = c.id
	 AND b.m_product_id = s.m_product_id
	 AND b.m_attributesetinstance_id = s.m_attributesetinstance_id
	 AND a.doctype <> 'RET'
	 AND a.isactive = 'Y'
	 AND a.out_status = 2
	 AND a.tstore = d.oricode(+)
 GROUP BY b.m_product_id, a.doctype, a.id, a.ad_client_id, a.ad_org_id, a.ownerid,
					a.creationdate, a.modifierid, a.modifieddate, a.ISACTIVE, a.dateoutin,
					a.c_store_id, a.C_ORIG_ID, c.pricelist, b.m_attributesetinstance_id, s.id,
					d.oriname, a.veerid, a.promotion, a.ADJUST_FEE, b.EB_ORDERSO_ID,a.id,a.ACTCOUPONAMT
UNION ALL
SELECT a.id, a.ad_client_id, a.ad_org_id, a.ownerid, a.creationdate, a.modifierid,
			 a.modifieddate, a.ISACTIVE, a.doctype, a.dateoutin, a.c_store_id, a.C_ORIG_ID,
			 b.m_product_id, b.m_attributesetinstance_id, s.id AS M_PRODUCTALIAS_ID,
			 /*START HERE*/ c.pricelist,
			 PERCOST_Analyse(substr(a.dateoutin, 1, 6), a.c_store_id, b.m_product_id) AS PERCOST,
			 0 AS qty, SUM(b.qtyin) AS qtyin, 0 AS TOT_PAYMENT, 0 AS TOT_COST,
			 0 AS STANDARD_PRICE, SUM(decode(b.qty,0,0,b.payment/b.qty)*b.qtyin) AS TOT_AMTRET_ACTUAL,
			 (PERCOST_Analyse(substr(a.dateoutin, 1, 6), a.c_store_id, b.m_product_id) *
				SUM(b.qtyin)) AS BACK_COST, SUM(b.qtyin) * c.pricelist AS BACK_PRICE,
			 /*end here*/ d.oriname, a.veerid, 0 AS PRICEACTUAL, 0 AS TOT_AMT_LIST,
			 0 AS TOT_AMT_ACTUAL, a.promotion, a.ADJUST_FEE,a.id as eb_orderso_id,a.ACTCOUPONAMT
	FROM eb_orderso a, eb_ordersoitem b, m_product c, m_product_alias s, EB_STORECOMPARE d
 WHERE a.id = b.eb_orderso_id
	 AND b.m_product_id = c.id
	 AND b.m_product_id = s.m_product_id
	 AND b.m_attributesetinstance_id = s.m_attributesetinstance_id
	 AND a.doctype = 'RET'
	 AND a.isactive = 'Y'
	 AND a.in_status = 2
	 AND a.tstore = d.oricode(+)
 GROUP BY b.m_product_id, a.doctype, a.id, a.ad_client_id, a.ad_org_id, a.ownerid,
					a.creationdate, a.modifierid, a.modifieddate, a.ISACTIVE, a.dateoutin,
					a.c_store_id, a.C_ORIG_ID, c.pricelist, b.m_attributesetinstance_id, s.id,
					d.Oriname, a.veerid, a.promotion, a.ADJUST_FEE, b.EB_ORDERSO_ID,a.id,a.ACTCOUPONAMT
--从表eb_orderso增加ACTCOUPONAMT字段凌坤20110711
/

