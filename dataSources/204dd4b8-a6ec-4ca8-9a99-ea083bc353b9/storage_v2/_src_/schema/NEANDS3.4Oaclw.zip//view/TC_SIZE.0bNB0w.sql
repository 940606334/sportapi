CREATE VIEW TC_SIZE AS
  SELECT t.value as size1,t.name as size_name FROM M_ATTRIBUTEVALUE t where t.clrsize=2
/

