CREATE VIEW C_VIP_IMP AS
  SELECT id, ad_client_id, ad_org_id, isactive, modifierid, creationdate,
       modifieddate, ownerid, cardno, c_viptype_id, idno, vipname, vipename, sex,
       birthday, substr(birthday, 5, 2) birthmonth, validdate, creditremain,
       country, c_city_id, c.c_opencardtype_id, c.lm_card, address, post, phone,
       mobil, email, c_store_id, c_customer_id, c_customerup_id, integral,
       pass_word, enterdate, babyname,
       (CASE
            WHEN nvl(validdate, '30011025') >=
                 to_number(to_char(SYSDATE, 'YYYYMMDD')) and c.opencard_status=2 THEN
             'Y'
            ELSE
             'N'
        END) AS vipstate, best_time, building, saler, storecardno,
       opencard_status, opencarderid, opencardtime, description, description2,
       oldstore, c_servicearea_id,
       nvl(trunc(months_between(to_date(to_char(SYSDATE, 'YYYYMMDD'), 'YYYYMMDD'),
                                 to_date(to_char(birthday), 'YYYYMMDD')) / 12), 0) AS age,
       opencarddate, c.isup, c.isoff, c.dateup, c.dateoff, c.imageurl,
       c.hr_employee_id, c.retail_filter, c.ispreclient, c.ispreparents,
       c.prebirthdate
       --these three paramaters are added by czl on 2011.05.6
      , c.parentsposition, c.parentsprofessional, c.microaccount,
       c.babybirth AS babybirthday, c.babyidno,
       nvl(trunc(months_between(to_date(to_char(SYSDATE, 'YYYYMMDD'), 'YYYYMMDD'),
                                 to_date(to_char(c.babybirth), 'YYYYMMDD')) / 12),
            0) AS babyage, s_babyname, sex2, education, hmonincome, int_ch_gift,
       when_come, inf_source, linkstyles, marital, hometown, msnqq, weibo,
       homeaddress, companyname, companyaddress, job, position, monthincome,
       c.c_integralarea_id --added by hzy 2012-10-26
FROM c_client_vip c
/

