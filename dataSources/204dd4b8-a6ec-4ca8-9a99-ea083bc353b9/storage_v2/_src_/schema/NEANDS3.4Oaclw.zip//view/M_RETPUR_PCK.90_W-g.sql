CREATE VIEW M_RETPUR_PCK AS
  SELECT id, ad_client_id, ad_org_id, ownerid, modifierid, creationdate,
       modifieddate, isactive, docno, doctype, billdate, salesrep_id, c_store_id,
       c_supplier_id, description, au_state, au_pi_id, avg_discount, tot_lines,
       tot_qty, tot_amt_list, tot_amt_actual, c_period_id, out_status,
       tot_qtyout, tot_amtout_list, tot_amtout_actual, dateout, datein,
       /* statuserid, statustime,*/ inerid, intime, outerid, outtime, box_status,
       diffreason, c_customer_id, m_purchase_id, c_tranway_jz_id, tranwayno,
       tranway_pay, b_po_id, c_department_id, pickerid, groupno, isbox,
       c_cargotype_id, printtimes, printintimes, printouttimes, sendqty,
       subsendqty, c_ret_purtype_id, exchangerate, tax_dis, pursource,
       c_currency_id, tot_qty_inved, isuf, iscost, out_au_state, out_au_pi_id,
       tot_qtyinved, tot_amtinved, isback, b_rwpuraccount_id, isagt,
       tot_amt_price, amt_deduction, pck_status AS status,
       pcheckid AS statuserid, pchecktime AS statustime, a.tot_tax_amt,
       a.tot_notax_amt
FROM m_ret_pur a
WHERE a.out_status = 2
AND a.status = 2
/

