CREATE VIEW B_V_RTPADJITEM_OLD AS
  select a.id,t.docno,t.priority,t.begindate,t.closedate,a.c_pricearea_id,a.m_product_id,a.pricelist,a.discount,a.price,t.isactive
from B_RTPADJ t,B_RTPADJitem a
where t.id=a.b_rtpadj_id
and t.status=2
and t.isactive='Y'
and to_date(t.begindate,'yyyymmdd')<=sysdate+1
and to_date(t.closedate,'yyyymmdd')>=sysdate
and (a.c_pricearea_id,a.m_product_id,substr('00000000000000000000'||DECODE(t.priority, 1, t.priority + 999999999999, t.priority),-20,20)||'-'||substr('0000000000'||t.ID,-10,10) ) in
(select a.c_pricearea_id,a.m_product_id,
MAX(substr('00000000000000000000'||DECODE(t.priority, 1, t.priority + 999999999999, t.priority),-20,20)||'-'||substr('0000000000'||t.ID,-10,10) ) over(partition  by c_pricearea_id,a.m_product_id)
from B_RTPADJ t,B_RTPADJitem a
where t.id=a.b_rtpadj_id
and t.status=2
and t.isactive='Y'
and to_date(t.begindate,'yyyymmdd')<=sysdate+1
and to_date(t.closedate,'yyyymmdd')>=sysdate
)
/

