CREATE VIEW C_CLIENTCSCARD_QUERY AS
  SELECT max(ccs.id) id,max(ccs.ad_client_id) ad_client_id, max(ccs.ad_org_id) ad_org_id, max(ccs.ownerid) ownerid, max(ccs.modifierid) modifierid,
       max(ccs.creationdate) creationdate, max(ccs.modifieddate) modifieddate, max(ccs.isactive) isactive,ccs.c_client_consumecard_id,
       sum(ccs.TOT_AMT) as TOT_AMT_RECEIVABLE,
       sum(ccs.TOT_AMT_RECEIVE) as TOT_AMT_RECEIVED,
       sum(ccs.TOT_AMT_REMAIN) as TOT_REMAIN
FROM C_CSCARD_SALE ccs
where ccs.status = 2
group by ccs.c_client_consumecard_id
/

