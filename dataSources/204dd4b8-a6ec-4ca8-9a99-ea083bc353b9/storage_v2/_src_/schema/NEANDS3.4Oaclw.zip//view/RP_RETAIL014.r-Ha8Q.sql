CREATE VIEW RP_RETAIL014 AS
  select id, ad_client_id, ad_org_id, isactive, creationdate, ownerid,
       modifieddate, modifierid, billdate, docno, retailbilltype, c_customer_id,
       c_store_id, description, c_vip_id, salesrep_id, m_product_id,
       m_attributesetinstance_id, qtyrtl, qtyret, pricelist, qty,
       tot_amtrtl_list, tot_amtrtl_actual, tot_amtrtl_discount, tot_amtret_list,
       tot_amtret_actual, tot_amtret_discount, tot_amt_list, tot_amt_actual,
       tot_amt_actual1, tot_amt_actual2, tot_amt_discount, rtldis, retdis,
       percost, tot_amtrtl_cost, tot_amtret_cost, tot_amt_cost1, tot_amt_cost2,
       tot_amtcost_diff
from (
       --老加盟65折
       select b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate,
               b.ownerid, b.modifieddate, b.modifierid, a.BILLDATE, a.DOCNO,
               a.retailbilltype, a.c_customer_id, a.C_STORE_ID, a.DESCRIPTION,
               a.C_VIP_ID, b.SALESREP_ID, b.M_PRODUCT_ID,
               b.M_ATTRIBUTESETINSTANCE_ID, b.QTY as qtyrtl, null as qtyret,
               b.PRICELIST, b.TOT_AMT_LIST as tot_amtrtl_list, 0 as tot_amtret_list,
               b.tot_amt_list - b.tot_amt_actual as tot_amtrtl_discount,
               b.PRICEACTUAL, b.tot_amt_list * 0.65 as tot_amtrtl_actual,
               0 as tot_amtret_actual, 0 as tot_amtret_discount, b.qty,
               b.tot_amt_list, b.tot_amt_actual,
               b.TOT_AMT_list * 0.65 as tot_amt_actual1, 0 as tot_amt_actual2,
               b.tot_amt_list * 0.65 as tot_amt_discount, b.discount as rtldis,
               0 as retdis, d.precost as PERCOST,
               d.precost * b.QTY as tot_amtrtl_cost, 0 as tot_amtret_cost,
               d.precost * b.QTY * 0.65 as tot_amt_cost1, 0 as tot_amt_cost2,
               d.precost * b.QTY * 0.65 as tot_amtcost_diff
       from M_RETAIL a, M_RETAILITEM b, m_product d, c_store e
       where a.ID = b.M_RETAIL_ID and b.m_product_id = d.id and
             a.c_store_id = e.id and a.STATUS = 2 and b.qty > 0 AND
             a.c_store_id IN
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id in
                    (select a.id
                     from c_customer a, c_cusattribdef b, c_cusattribvalue c
                     where a.c_cusattrib1_id = c.id and b.id = c.c_cusattribdef_id and
                           c.dimflag = 'DIM1' and c.name = '老加盟'))

       union
       select b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate,
              b.ownerid, b.modifieddate, b.modifierid, a.BILLDATE, a.DOCNO,
              a.retailbilltype, a.c_customer_id, a.C_STORE_ID, a.DESCRIPTION,
              a.C_VIP_ID, b.SALESREP_ID, b.M_PRODUCT_ID,
              b.M_ATTRIBUTESETINSTANCE_ID, null as qtyrtl, -b.qty as qtyret,
              b.PRICELIST, 0 as tot_amtrtl_list, -b.TOT_AMT_LIST as tot_amtret_list,
              0 as tot_amtrtl_discount, b.PRICEACTUAL, 0 as tot_amtrtl_actual,
              -b.tot_amt_list * 0.65 as tot_amtret_actual,
              - (b.tot_amt_list - b.tot_amt_actual) as tot_amtret_discount, -b.qty,
              b.tot_amt_list AS tot_amt_list, b.tot_amt_actual,
              b.tot_amt_list * 0.65 AS tot_amt_actual1, 0 as tot_amt_actual2,
              (b.tot_amt_list * 0.65) as tot_amt_discount, 0 as rtldis,
              b.discount as retdis, d.precost as PERCOST, 0 as tot_amtrtl_cost,
              d.precost * (-b.QTY) as tot_amtret_cost,
              d.precost * (b.QTY) * 0.65 as tot_amt_cost1, 0 as tot_amt_cost2,
              d.precost * (b.QTY) * 0.65 as tot_amtcost_diff
       from M_RETAIL a, M_RETAILITEM b, m_product d, c_store e
       where a.ID = b.M_RETAIL_ID and b.m_product_id = d.id and
             a.c_store_id = e.id and a.STATUS = 2 and b.qty < 0 AND
             a.c_store_id IN
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id in
                    (select a.id
                     from c_customer a, c_cusattribdef b, c_cusattribvalue c
                     where a.c_cusattrib1_id = c.id and b.id = c.c_cusattribdef_id and
                           c.dimflag = 'DIM1' and c.name = '老加盟'))

       union
       --老加盟销售
       SELECT b.id, b.ad_client_id, b.ad_org_id, b.isactive, b.creationdate,
              b.ownerid, b.modifieddate, b.modifierid, a.dateout as billdate,
              a.docno, NULL AS retailbilltype, a.c_customer_id,
              a.c_dest_id AS c_store_id, a.description, NULL AS c_vip_id,
              NULL AS SALESREP_ID, b.m_product_id, b.m_attributesetinstance_id,
              NULL AS qtyrtl, NULL AS qtyret, b.pricelist,
              b.tot_amtout_list AS tot_amtrtl_list, 0 AS tot_amtret_list,
              b.tot_amtout_list - b.tot_amtout_actual AS tot_amtrtl_discount,
              b.priceactual, b.tot_amtout_actual AS tot_amtrtl_actual,
              0 AS tot_amtret_actual, 0 AS tot_amtret_discount, b.qtyout as qty,
              b.tot_amtout_list as tot_amt_list,
              b.tot_amtout_actual as tot_amt_actual, 0 as tot_amt_actual1,
              b.tot_amtout_actual as tot_amt_actual2,
              (-b.tot_amtout_actual) AS tot_amt_discount,
               --tot_amt_actual1-tot_amt_actual2
              b.discount AS rtldis, 0 AS retdis, d.precost AS percost,
              d.precost * b.qtyout AS tot_amtrtl_cost, 0 AS tot_amtret_cost,
              0 as tot_amt_cost1, d.precost * b.qtyout AS tot_amt_cost2,
              -d.precost * b.qtyout as tot_amtcost_diff
       FROM m_sale a, m_saleitem b, m_product d, c_store e
       WHERE a.id = b.m_sale_id AND b.m_product_id = d.id AND a.c_dest_id = e.id AND
             a.out_status = 2 AND
             a.c_dest_id IN
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id <>
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部')) AND
                    a.c_customerup_id =
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部'))) and
             a.c_dest_id in
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id in
                    (select a.id
                     from c_customer a, c_cusattribdef b, c_cusattribvalue c
                     where a.c_cusattrib1_id = c.id and b.id = c.c_cusattribdef_id and
                           c.dimflag = 'DIM1' and c.name = '老加盟'))
       UNION
       --老加盟销售退货
       SELECT b.id, b.ad_client_id, b.ad_org_id, b.isactive, b.creationdate,
              b.ownerid, b.modifieddate, b.modifierid, a.datein as billdate,
              a.docno, NULL AS retailbilltype, a.c_customer_id,
              a.c_orig_id AS c_store_id, a.description, NULL AS c_vip_id,
              NULL AS SALESREP_ID, b.m_product_id, b.m_attributesetinstance_id,
              NULL AS qtyrtl, b.qtyin AS qtyret, b.pricelist, 0 AS tot_amtrtl_list,
              b.tot_amtin_list AS tot_amtret_list, 0 AS tot_amtrtl_discount,
              b.priceactual, 0 AS tot_amtrtl_actual,
              b.tot_amtin_actual AS tot_amtret_actual,
              (b.tot_amtin_list - b.tot_amtin_actual) AS tot_amtret_discount,
              b.qtyin AS qty, -b.tot_amtin_list AS tot_amtin_list,
              -b.tot_amtin_actual as tot_amt_actual, 0 as tot_amt_actual1,
              -b.tot_amtin_actual AS tot_amt_actual2,
              b.tot_amtin_actual as tot_amt_discount, 0 AS rtldis,
              b.discount AS retdis, d.precost AS percost, 0 AS tot_amtrtl_cost,
              d.precost * (b.qtyin) AS tot_amtret_cost, 0 as tot_amt_cost1,
              d.precost * (-b.qtyin) AS tot_amt_cost2,
              d.precost * b.qtyin as tot_amtcost_diff
       FROM m_ret_sale a, m_ret_saleitem b, m_product d, c_store e
       WHERE a.id = b.m_ret_sale_id AND b.m_product_id = d.id AND
             a.c_orig_id = e.id AND a.in_status = 2 AND
             a.c_orig_id IN
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id <>
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部')) AND
                    a.c_customerup_id =
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部'))) and
             a.c_orig_id in
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id in
                    (select a.id
                     from c_customer a, c_cusattribdef b, c_cusattribvalue c
                     where a.c_cusattrib1_id = c.id and b.id = c.c_cusattribdef_id and
                           c.dimflag = 'DIM1' and c.name = '老加盟')))
with read only
/

