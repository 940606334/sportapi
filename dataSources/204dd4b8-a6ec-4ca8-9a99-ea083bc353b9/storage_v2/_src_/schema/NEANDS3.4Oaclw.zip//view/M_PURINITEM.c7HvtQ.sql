CREATE VIEW M_PURINITEM AS
  select b.id,	b.ad_client_id,  b.ad_org_id,  b.m_purnotice_id ,  b.m_productalias_id,
       b.m_product_id,  b.qty,  b.qtyin, b.qtyrem,b.qty_imped, b.ownerid,  b.modifierid,
       b.creationdate,  b.modifieddate,  b.isactive,  b.m_attributesetinstance_id,b.qtydiff,
       b.serviceno
from m_purnoticeitem b
/

