CREATE VIEW V_FA_STORAGE111 AS
  select a.ID,a.AD_CLIENT_ID,a.AD_ORG_ID,a.OWNERID,a.MODIFIERID,a.CREATIONDATE,a.MODIFIEDDATE,a.ISACTIVE,
a.c_store_id,a.m_product_id,a.m_attributesetinstance_id,a.qty,a.qtypreout,a.qtyprein,
(nvl(a.qty, 0) - nvl(a.qtypreout, 0) + nvl(a.qtyprein, 0)) as qtyvalid,
(case
   when nvl(a.qty,0)>= (nvl(a.qty,0)-nvl(a.qtypreout,0))
   then (nvl(a.qty,0)-nvl(a.qtypreout,0))
   else
   a.qty
   end) as qtycan,
b.pricelist,b.pricelist * a.qty as amt_priceqty,
b.pricelist * a.qtypreout as amt_priceqtypreout,
b.pricelist * a.qtyprein as amt_priceqtyprein,
b.pricelist * (nvl(a.qty, 0) - nvl(a.qtypreout, 0) + nvl(a.qtyprein, 0)) as amt_priceqtyvalid
from fa_storage a, m_product b
where a.m_product_id = b.id
with read only
/

