CREATE VIEW RP_V_SO AS
  select a.id,a.ad_client_id,a.ad_org_id,a.ownerid,a.modifierid,a.creationdate,a.modifieddate,a.isactive,a.docno,a.doctype
,a.billdate,a.description,a.salesrep_id,a.c_customerup_id,a.c_store_id,a.c_customer_id,a.c_dest_id,a.status,
a.statuserid,a.statustime,a.c_period_id,a.close_status,a.closerid,a.closetime,a.predateout,a.b_fair_id ,a.b_so_id,
a.orderno,
a.m_product_id,a.m_attributesetinstance_id,b.pricelist,a.qty,a.tot_amt_actual,a.qty *b.pricelist as tot_amt_list ,c.no
from v_so a,m_product b,M_PRODUCT_ALIAS c
where a.m_product_id=b.id and a.m_product_id=c.m_product_id and a.m_attributesetinstance_id=c.m_attributesetinstance_id
with read only
/

