CREATE VIEW RP_RETAILMARK01 AS
  select min(k.id) as id, min(k.ownerid) as ownerid,
              min(k.creationdate) as creationdate, min(k.modifierid) as modifierid,
              min(k.modifieddate) as modifieddate, k.ad_client_id, k.c_store_id,
              sum(nvl(k.tot_amt_actual, 0)) as month_amt, k.yearmonth,
              sum(nvl(k.tot_amt_mark, 0)) as tot_amt_mark
from (select min(t.id) as id, min(t.ownerid) as ownerid,
             min(t.creationdate) as creationdate,
             min(t.modifierid) as modifierid,
             min(t.modifieddate) as modifieddate, t.ad_client_id,
             t.c_store_id, sum(t.tot_amt_actual) as tot_amt_actual,
             to_number(SUBSTR(t.dateout, 1, 6)) as yearmonth,
             null as tot_amt_mark
      from m_retail t
      where t.status=2
      group by t.ad_client_id, t.c_store_id, SUBSTR(t.dateout, 1, 6)
      union all
      select g.id, g.ownerid, g.creationdate, g.modifierid, g.modifieddate,
             g.ad_client_id, g.c_store_id, 0 as tot_amt_actual,
             g.yearmonth, g.tot_amt_mark
      from c_storemark g
      where g.isactive = 'Y') k
group by ad_client_id, c_store_id, yearmonth
WITH READ ONLY
/

