CREATE VIEW Y_PUR_CHECKITEM AS
  SELECT id, ad_client_id, ad_org_id, y_purchase_id AS y_pur_check_id,
       y_material_id, y_color_id, fabric_width, fabric_weight, y_spec_id, qty,
       qtyin, purchase_unit_id, purchase_rate, use_unit_id, fprice, famount,
       famountin, m_product_id, loss_rate, more_rate, ownerid, modifierid,
       creationdate, modifieddate, isactive, tot_qty, amttoprice, pricecheck,
       pricemodify, famountin_pcheck, famountin_dec, famountin_fee,
       famountin_pchecktax, tax_dis, y_materialalias_id, good_qty, defect_qty,
       tax_amt, notax_amt, qtyinved, amtinved, isacc, isinv, fgood_qty,
       defectremark, deladvice, check_description
FROM y_purchase_item
/

