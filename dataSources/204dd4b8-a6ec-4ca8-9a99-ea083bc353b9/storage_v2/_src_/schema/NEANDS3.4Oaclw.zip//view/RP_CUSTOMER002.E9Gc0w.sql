CREATE VIEW RP_CUSTOMER002 AS
  select ID,AD_CLIENT_ID,AD_ORG_ID,OWNERID,MODIFIERID,CREATIONDATE,MODIFIEDDATE,ISACTIVE,C_CUSTOMER_ID,
feelsale,-FEELTAKE as feeltake,FEECHECKED,FEECHECKEDIN,-FEEREMAIN as FEEREMAIN,AMT_ODR_REMAIN,
-(FeeRemain - FeeChecked + FeeCheckedIn) AS FEEPRE,
FeeRemain - FeeChecked - FeeLSALE AS FEECANSALE,
(FeeRemain - FeeChecked  - FeeLTake-nvl((select sum(c.creditlimit)
                                                                      from c_creditlimit c
                                                                      where FA_CUSTOMER.C_CUSTOMER_ID = c.c_customer_id
                                                                      and to_number(to_char(sysdate,'YYYYMMDD')) <= c.dateend
                                                                      and to_number(to_char(sysdate,'YYYYMMDD')) >= c.datebegin
                                                                      and c.status = 2),0)) AS FEECANTAKE
FROM FA_CUSTOMER
WITH READ ONLY
/

