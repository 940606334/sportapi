CREATE VIEW V_BAS_MODEL AS
  SELECT max(t.id) as id,
        substr(t.name, 2, length(t.name) - 3) AS model_id,
       substr(t.name, 2, length(t.name) - 3) AS model,
       (SELECT ATTRIBcode FROM m_dim WHERE id = t.m_dim3_id) AS season, --季节
       (SELECT ATTRIBcode FROM m_dim WHERE id = t.m_dim5_id) AS sex, --性别
       t.m_sizegroup_id + 200 AS size_type, --配码类型
       (SELECT code FROM c_supplier WHERE id = t.c_supplier_id) AS vendorid,--生产产家
       (SELECT ATTRIBcode FROM m_dim WHERE id = t.m_dim7_id) AS ShoeKind,--鞋类
			 1 as Sale_Style,
			 (SELECT ATTRIBcode FROM m_dim WHERE id = t.m_dim8_id) AS Make_Style,--制造类别
       (SELECT ATTRIBcode FROM m_dim WHERE id = t.m_dim1_id) AS brand,0 as IMPORTED
FROM m_product t
WHERE--t.modifieddate>sysdate-7 AND
t.name !='123'
and  t.isactive = 'Y'
group by substr(t.name, 2, length(t.name) - 3),m_dim3_id,m_dim5_id,m_sizegroup_id,c_supplier_id,m_dim7_id,m_dim8_id,m_dim1_id
/

