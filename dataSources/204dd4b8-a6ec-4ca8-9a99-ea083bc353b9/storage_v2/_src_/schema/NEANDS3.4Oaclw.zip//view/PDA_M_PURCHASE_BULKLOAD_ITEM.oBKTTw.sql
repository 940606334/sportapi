CREATE VIEW PDA_M_PURCHASE_BULKLOAD_ITEM AS
  select a.m_purchase_bulkload_id,b.no,c.value name from M_PURCHASE_BULKLOADITEM a,M_PRODUCT_ALIAS b,m_product c
where a.m_productalias_id=b.id and a.m_product_id=c.id
--快捷散货入库显示表体用
/

