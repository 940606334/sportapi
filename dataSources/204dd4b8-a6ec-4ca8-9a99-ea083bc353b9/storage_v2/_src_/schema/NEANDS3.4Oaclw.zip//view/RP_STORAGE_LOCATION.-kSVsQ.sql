CREATE VIEW RP_STORAGE_LOCATION AS
  SELECT a.id,
       a.ad_client_id,
       a.ad_org_id,
       a.c_store_id,
       a.m_product_id,
       a.m_attributesetinstance_id,
       a.m_productalias_id,
       (SELECT MAX(b.C_STORE_LOCATION_ID)
        FROM m_store_location b, m_attributesetinstance c
        WHERE b.m_color_id = c.value1_id
        AND c.id = a.m_attributesetinstance_id
        AND b.m_product_id = a.m_product_id) AS location,
       a.qty,
       a.qtyprein,
       a.qtypreout,a.isactive
FROM fa_storage a
WHERE (a.qty <> 0 AND a.qtyprein <> 0 AND a.qtypreout <> 0)
WITH READ ONLY
/

