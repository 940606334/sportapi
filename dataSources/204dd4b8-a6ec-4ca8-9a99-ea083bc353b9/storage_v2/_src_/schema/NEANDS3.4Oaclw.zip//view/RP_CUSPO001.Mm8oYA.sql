CREATE VIEW RP_CUSPO001 AS
  SELECT f.id, f.ad_client_id, f.ad_org_id, f.isactive, f.creationdate, f.ownerid,
			 f.modifieddate, f.modifierid, f.c_store_id, f.c_dest_id, f.C_CUSTOMERUP_ID,
			 f.c_customer_id, f.DOCNO, /*e.M_SALENO  ,*/ f.billdate, f.m_product_id,
			 f.m_attributesetinstance_id, f.m_productalias_id, f.qty_so, f.priceactual_so,
			 nvl(f.qty_so, 0) * nvl(f.priceactual_so, 0) AMT_QTYSO, nvl(e.qtyin, 0) qty_in,
			 nvl(e.priceactual_in, 0) priceactual_in,
			 NVL(e.QTYIN, 0) * NVL(e.PRICEACTUAL_in, 0) AS amt_in,f.doctype
	FROM (SELECT a.id b_so_id, B.ID, B.AD_CLIENT_ID, B.AD_ORG_ID, B.ISACTIVE, B.CREATIONDATE,
								B.OWNERID, B.MODIFIEDDATE, B.MODIFIERID, A.C_STORE_ID, a.c_dest_id,
								a.C_CUSTOMERUP_ID, a.c_customer_id, A.DOCNO, A.BILLDATE, B.M_PRODUCT_ID,
								B.M_ATTRIBUTESETINSTANCE_ID, b.M_PRODUCTALIAS_ID, B.QTY AS qty_so,
								B.PRICEACTUAL AS PRICEACTUAL_so, st.c_customer_id AS c_customer_id1,
								se.c_customer_id AS c_customer_id2, a.doctype
					 FROM B_SO A, B_SOITEM B, c_store st, c_store se
					WHERE A.ID = B.B_SO_ID
						AND a.status = 2
						AND a.c_store_id = st.id
						AND a.c_dest_id = se.id) f
	LEFT JOIN (SELECT b_so_id, /* c.DOCNO M_SALENO,*/ d.M_PRODUCT_ID,
										d.m_attributesetinstance_id, SUM(d.qtyin) qtyin,
										AVG(d.priceactual) AS priceactual_in
							 FROM M_SALE C, M_SALEITEM D
							WHERE C.ID = D.M_SALE_ID
								AND c.b_so_id IS NOT NULL
							GROUP BY b_so_id, d.M_PRODUCT_ID, d.m_attributesetinstance_id) e ON f.b_so_id =
																																									e.b_so_id
																																							AND e.m_product_id =
																																									f.m_product_id
																																							AND e.m_attributesetinstance_id =
																																									f.m_attributesetinstance_id
 WHERE f.c_customer_id1 <> f.c_customer_id2
/

