CREATE VIEW RP_RETAIL012 AS
  select id, ad_client_id, ad_org_id, isactive, creationdate, ownerid,
       modifieddate, modifierid, billdate, docno, retailbilltype, c_customer_id,
       c_store_id, description, c_vip_id, salesrep_id, m_product_id,
       m_attributesetinstance_id, qtyrtl, qtyret, pricelist, qty,
       tot_amtrtl_list, tot_amtrtl_actual, tot_amtrtl_discount,
       tot_amtrtl_aftertax, tot_amtret_list, tot_amtret_actual,
       tot_amtret_discount, tot_amtret_aftertax, tot_amt_list, tot_amt_actual,
       tot_amt_discount, tot_amt_aftertax, rtldis, retdis, percost, c_store_type,
       tot_amtrtl_cost, tot_amtret_cost, tot_amt_cost,
       (select to_number(value, '0.9999')
         from ad_param
         where name = 'Kingdee.relatedcostratio') as relativecostratio,
       tot_amt_cost * (select to_number(value, '0.9999')
                        from ad_param
                        where name = 'Kingdee.relatedcostratio') as tot_amt_relativecost,
       brand, cuponamt
from (
       --自营店零售
       select b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate,
               b.ownerid, b.modifieddate, b.modifierid, a.BILLDATE, a.DOCNO,
               a.retailbilltype, a.c_customer_id, a.C_STORE_ID, a.DESCRIPTION,
               a.C_VIP_ID, b.SALESREP_ID, b.M_PRODUCT_ID,
               b.M_ATTRIBUTESETINSTANCE_ID, b.QTY as qtyrtl, null as qtyret,
               b.PRICELIST, b.TOT_AMT_LIST as tot_amtrtl_list, 0 as tot_amtret_list,
               b.tot_amt_list - b.tot_amt_actual as tot_amtrtl_discount,
                --add by ken for MKL report 20100327
               b.tot_amt_actual / (1 + NVL(e.taxrate, 0)) as tot_amtrtl_aftertax,
                --add by ken for MKL report 20100327
               b.PRICEACTUAL, b.TOT_AMT_ACTUAL as tot_amtrtl_actual,
               0 as tot_amtret_actual, 0 as tot_amtret_discount,
                --add by ken for MKL report 20100327
               0 as tot_amtret_aftertax,
                --add by ken for MKL report 20100327
               b.qty, b.tot_amt_list, b.tot_amt_actual,
               b.tot_amt_list - b.tot_amt_actual as tot_amt_discount,
                --add by ken for MKL report 20100327
               b.tot_amt_actual / (1 + NVL(e.taxrate, 0)) as tot_amt_aftertax,
                --add by ken for MKL report 20100327
               b.discount as rtldis, 0 as retdis, d.precost as PERCOST,
               d.precost * b.QTY as tot_amtrtl_cost, 0 as tot_amtret_cost,
               d.precost * b.QTY as tot_amt_cost, 'S' AS C_STORE_TYPE,
               d.m_dim1_id as brand,
               case
                   when nvl(a.tot_amt_actual, 0) = 0 then
                    (b.tot_amt_actual + 1) /
                    (select sum(1)
                     from m_retail aa, m_retailitem b
                     where aa.id = b.m_retail_id and aa.docno = a.docno) *
                    (select nvl(SUM(b.payamount), 0) as cuponamt
                     from m_retail aa, m_retailpayitem b, c_payway c
                     where aa.id = b.m_retail_id and aa.docno = a.docno and
                           b.c_payway_id = c.id and c.isreduce = 'Y'
                     --and c.name in ('5月门店礼券', '门店礼券')
                     group by m_retail_id)
                   else
                    b.tot_amt_actual / a.tot_amt_actual *
                    (select nvl(SUM(b.payamount), 0) as cuponamt
                     from m_retail aa, m_retailpayitem b, c_payway c
                     where aa.id = b.m_retail_id and aa.docno = a.docno and
                           b.c_payway_id = c.id and c.isreduce = 'Y'
                     --and c.name in ('5月门店礼券', '门店礼券')
                     group by m_retail_id)
               end as cuponamt
       /*b.tot_amt_actual/decode(nvl(a.tot_amt_actual,0),0,1,a.tot_amt_actual)*(select nvl(SUM(b.payamount),0)   as cuponamt
       from m_retail aa, m_retailpayitem b, c_payway c
       where aa.id=b.m_retail_id
       and aa.docno=a.docno
       and b.c_payway_id=c.id
       and c.isreduce='Y'
       --and c.name in ('5月门店礼券', '门店礼券')
       group by m_retail_id
       ) as cuponamt**/
       from M_RETAIL a, M_RETAILITEM b, m_product d, c_store e
       where a.ID = b.M_RETAIL_ID and b.m_product_id = d.id and
             a.c_store_id = e.id and a.STATUS = 2 and b.qty > 0 AND
             a.c_store_id IN
             (SELECT ID
              FROM c_store t
              WHERE t.c_customer_id =
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部')))

       union
       --自营店零售退货
       select b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate,
              b.ownerid, b.modifieddate, b.modifierid, a.BILLDATE, a.DOCNO,
              a.retailbilltype, a.c_customer_id, a.C_STORE_ID, a.DESCRIPTION,
              a.C_VIP_ID, b.SALESREP_ID, b.M_PRODUCT_ID,
              b.M_ATTRIBUTESETINSTANCE_ID, null as qtyrtl, -b.qty as qtyret,
              b.PRICELIST, 0 as tot_amtrtl_list, -b.TOT_AMT_LIST as tot_amtret_list,
              0 as tot_amtrtl_discount,
               --add by ken for MKL report 20100327
              0 as tot_amtrtl_aftertax,
               --add by ken for MKL report 20100327
              b.PRICEACTUAL, 0 as tot_amtrtl_actual,
              -b.TOT_AMT_ACTUAL as tot_amtret_actual,
              - (b.tot_amt_list - b.tot_amt_actual) as tot_amtret_discount,
               --add by ken for MKL report 20100327
              -b.tot_amt_actual / (1 + NVL(e.taxrate, 0)) as tot_amtret_aftertax,
               --add by ken for MKL report 20100327
              -b.qty, b.tot_amt_list AS tot_amt_list,
              b.tot_amt_actual AS tot_amt_actual,
              (b.tot_amt_list - b.tot_amt_actual) as tot_amt_discount,
               --add by ken for MKL report 20100327
              -b.tot_amt_actual / (1 + NVL(e.taxrate, 0)) as tot_amt_aftertax,
               --add by ken for MKL report 20100327
              0 as rtldis, b.discount as retdis, d.precost as PERCOST,
              0 as tot_amtrtl_cost, d.precost * (-b.QTY) as tot_amtret_cost,
              d.precost * (b.QTY) as tot_amt_cost, 'S' AS C_STORE_TYPE,
              d.m_dim1_id as brand,
              case
                  when nvl(a.tot_amt_actual, 0) = 0 then
                   (b.tot_amt_actual + 1) /
                   (select sum(1)
                    from m_retail aa, m_retailitem b
                    where aa.id = b.m_retail_id and aa.docno = a.docno) *
                   (select nvl(SUM(b.payamount), 0) as cuponamt
                    from m_retail aa, m_retailpayitem b, c_payway c
                    where aa.id = b.m_retail_id and aa.docno = a.docno and
                          b.c_payway_id = c.id and c.isreduce = 'Y'
                    --and c.name in ('5月门店礼券', '门店礼券')
                    group by m_retail_id)
                  else
                   b.tot_amt_actual / a.tot_amt_actual *
                   (select nvl(SUM(b.payamount), 0) as cuponamt
                    from m_retail aa, m_retailpayitem b, c_payway c
                    where aa.id = b.m_retail_id and aa.docno = a.docno and
                          b.c_payway_id = c.id and c.isreduce = 'Y'
                    --and c.name in ('5月门店礼券', '门店礼券')
                    group by m_retail_id)
              end as cuponamt
       /*b.tot_amt_actual/decode(nvl(a.tot_amt_actual,0),0,1,a.tot_amt_actual)*(select nvl(SUM(b.payamount),0)   as cuponamt
       from m_retail aa, m_retailpayitem b, c_payway c
       where aa.id=b.m_retail_id
       and aa.docno=a.docno
       and b.c_payway_id=c.id
       and c.isreduce='Y'
       --and c.name in ('5月门店礼券', '门店礼券')
       group by m_retail_id
       ) as cuponamt**/
       from M_RETAIL a, M_RETAILITEM b, m_product d, c_store e
       where a.ID = b.M_RETAIL_ID and b.m_product_id = d.id and
             a.c_store_id = e.id and a.STATUS = 2 and b.qty < 0 AND
             a.c_store_id IN
             (SELECT ID
              FROM c_store t
              WHERE t.c_customer_id =
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部')))
       --老加盟零售
       union
       select b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate,
              b.ownerid, b.modifieddate, b.modifierid, a.BILLDATE, a.DOCNO,
              a.retailbilltype, a.c_customer_id, a.C_STORE_ID, a.DESCRIPTION,
              a.C_VIP_ID, b.SALESREP_ID, b.M_PRODUCT_ID,
              b.M_ATTRIBUTESETINSTANCE_ID, b.QTY as qtyrtl, null as qtyret,
              b.PRICELIST, b.TOT_AMT_LIST as tot_amtrtl_list, 0 as tot_amtret_list,
              --b.tot_amt_list-b.tot_amt_actual as tot_amtrtl_discount,--add by ken for MKL report 20100327
              b.tot_amt_list * (select 1 - nvl(f.agtsaledis, 0)
                                 from C_CUSDISDEF f
                                 where f.c_customer_id = a.c_customer_id and
                                       f.m_dim1_id = d.m_dim1_id) as tot_amtrtl_discount,
               --add by ken for MKL report 20100327
              b.tot_amt_actual / (1 + NVL(e.taxrate, 0)) as tot_amtrtl_aftertax,
               --add by ken for MKL report 20100327
              b.PRICEACTUAL,
              b.tot_amt_list * (select nvl(f.agtsaledis, 0)
                                 from C_CUSDISDEF f
                                 where f.c_customer_id = a.c_customer_id and
                                       f.m_dim1_id = d.m_dim1_id) as tot_amtrtl_actual,
              0 as tot_amtret_actual, 0 as tot_amtret_discount,
               --add by ken for MKL report 20100327
              0 as tot_amtret_aftertax,
               --add by ken for MKL report 20100327
              b.qty, b.tot_amt_list, b.TOT_AMT_ACTUAL as tot_amt_actual,
              b.tot_amt_list * (select 1 - nvl(f.agtsaledis, 0)
                                 from C_CUSDISDEF f
                                 where f.c_customer_id = a.c_customer_id and
                                       f.m_dim1_id = d.m_dim1_id) as tot_amt_discount,
               --add by ken for MKL report 20100327
              b.tot_amt_actual / (1 + NVL(e.taxrate, 0)) as tot_amt_aftertax,
               --add by ken for MKL report 20100327
              b.discount as rtldis, 0 as retdis, d.precost as PERCOST,
              d.precost * b.QTY as tot_amtrtl_cost, 0 as tot_amtret_cost,
              d.precost * b.QTY as tot_amt_cost, 'C' AS C_STORE_TYPE,
              d.m_dim1_id as brand,
              case
                  when nvl(a.tot_amt_actual, 0) = 0 then
                   (b.tot_amt_actual + 1) /
                   (select sum(1)
                    from m_retail aa, m_retailitem b
                    where aa.id = b.m_retail_id and aa.docno = a.docno) *
                   (select nvl(SUM(b.payamount), 0) as cuponamt
                    from m_retail aa, m_retailpayitem b, c_payway c
                    where aa.id = b.m_retail_id and aa.docno = a.docno and
                          b.c_payway_id = c.id and c.isreduce = 'Y'
                    --and c.name in ('5月门店礼券', '门店礼券')
                    group by m_retail_id)
                  else
                   b.tot_amt_actual / a.tot_amt_actual *
                   (select nvl(SUM(b.payamount), 0) as cuponamt
                    from m_retail aa, m_retailpayitem b, c_payway c
                    where aa.id = b.m_retail_id and aa.docno = a.docno and
                          b.c_payway_id = c.id and c.isreduce = 'Y'
                    --and c.name in ('5月门店礼券', '门店礼券')
                    group by m_retail_id)
              end as cuponamt
       /*b.tot_amt_actual/decode(nvl(a.tot_amt_actual,0),0,1,a.tot_amt_actual)*(select nvl(SUM(b.payamount),0)   as cuponamt
       from m_retail aa, m_retailpayitem b, c_payway c
       where aa.id=b.m_retail_id
       and aa.docno=a.docno
       and b.c_payway_id=c.id
       and c.isreduce='Y'
       --and c.name in ('5月门店礼券', '门店礼券')
       group by m_retail_id
       ) as cuponamt*/
       from M_RETAIL a, M_RETAILITEM b, m_product d, c_store e
       where a.ID = b.M_RETAIL_ID and b.m_product_id = d.id and
             a.c_store_id = e.id and a.STATUS = 2 and b.qty > 0 AND
             a.c_store_id IN
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id in
                    (select a.id
                     from c_customer a, c_cusattribdef b, c_cusattribvalue c
                     where a.c_cusattrib1_id = c.id and b.id = c.c_cusattribdef_id and
                           c.dimflag = 'DIM1' and c.name = '老加盟'))

       union
       --老加盟零售退货
       select b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate,
              b.ownerid, b.modifieddate, b.modifierid, a.BILLDATE, a.DOCNO,
              a.retailbilltype, a.c_customer_id, a.C_STORE_ID, a.DESCRIPTION,
              a.C_VIP_ID, b.SALESREP_ID, b.M_PRODUCT_ID,
              b.M_ATTRIBUTESETINSTANCE_ID, null as qtyrtl, -b.qty as qtyret,
              b.PRICELIST, 0 as tot_amtrtl_list, -b.TOT_AMT_LIST as tot_amtret_list,
              0 as tot_amtrtl_discount,
               --add by ken for MKL report 20100327
              0 as tot_amtrtl_aftertax,
               --add by ken for MKL report 20100327
              b.PRICEACTUAL, 0 as tot_amtrtl_actual,
              -b.tot_amt_list *
               (select nvl(f.agtsaleretdis, 0)
                from C_CUSDISDEF f
                where f.c_customer_id = a.c_customer_id and
                      f.m_dim1_id = d.m_dim1_id) as tot_amtret_actual,
              - (b.tot_amt_list *
                (select 1 - nvl(f.agtsaledis, 0)
                 from C_CUSDISDEF f
                 where f.c_customer_id = a.c_customer_id and
                       f.m_dim1_id = d.m_dim1_id)) as tot_amtret_discount,
               --add by ken for MKL report 20100327
              -b.tot_amt_actual / (1 + NVL(e.taxrate, 0)) as tot_amtret_aftertax,
               --add by ken for MKL report 20100327
              -b.qty, b.tot_amt_list AS tot_amt_list,
              b.tot_amt_actual AS tot_amt_actual,
              (b.tot_amt_list *
               (select 1 - nvl(f.agtsaledis, 0)
                 from C_CUSDISDEF f
                 where f.c_customer_id = a.c_customer_id and
                       f.m_dim1_id = d.m_dim1_id)) as tot_amt_discount,
               --add by ken for MKL report 20100327
              -b.tot_amt_actual / (1 + NVL(e.taxrate, 0)) as tot_amt_aftertax,
               --add by ken for MKL report 20100327
              0 as rtldis, b.discount as retdis, d.precost as PERCOST,
              0 as tot_amtrtl_cost, d.precost * (-b.QTY) as tot_amtret_cost,
              d.precost * (b.QTY) as tot_amt_cost, 'C' AS C_STORE_TYPE,
              d.m_dim1_id as brand,
              case
                  when nvl(a.tot_amt_actual, 0) = 0 then
                   (b.tot_amt_actual + 1) /
                   (select sum(1)
                    from m_retail aa, m_retailitem b
                    where aa.id = b.m_retail_id and aa.docno = a.docno) *
                   (select nvl(SUM(b.payamount), 0) as cuponamt
                    from m_retail aa, m_retailpayitem b, c_payway c
                    where aa.id = b.m_retail_id and aa.docno = a.docno and
                          b.c_payway_id = c.id and c.isreduce = 'Y'
                    --and c.name in ('5月门店礼券', '门店礼券')
                    group by m_retail_id)
                  else
                   b.tot_amt_actual / a.tot_amt_actual *
                   (select nvl(SUM(b.payamount), 0) as cuponamt
                    from m_retail aa, m_retailpayitem b, c_payway c
                    where aa.id = b.m_retail_id and aa.docno = a.docno and
                          b.c_payway_id = c.id and c.isreduce = 'Y'
                    --and c.name in ('5月门店礼券', '门店礼券')
                    group by m_retail_id)
              end as cuponamt
       /*b.tot_amt_actual/decode(nvl(a.tot_amt_actual,0),0,1,a.tot_amt_actual)*(select nvl(SUM(b.payamount),0)   as cuponamt
       from m_retail aa, m_retailpayitem b, c_payway c
       where aa.id=b.m_retail_id
       and aa.docno=a.docno
       and b.c_payway_id=c.id
       and c.isreduce='Y'
       --and c.name in ('5月门店礼券', '门店礼券')
       group by m_retail_id
       ) as cuponamt*/
       from M_RETAIL a, M_RETAILITEM b, m_product d, c_store e
       where a.ID = b.M_RETAIL_ID and b.m_product_id = d.id and
             a.c_store_id = e.id and a.STATUS = 2 and b.qty < 0 AND
             a.c_store_id IN
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id in
                    (select a.id
                     from c_customer a, c_cusattribdef b, c_cusattribvalue c
                     where a.c_cusattrib1_id = c.id and b.id = c.c_cusattribdef_id and
                           c.dimflag = 'DIM1' and c.name = '老加盟'))
       UNION
       --新加盟销售
       SELECT b.id, b.ad_client_id, b.ad_org_id, b.isactive, b.creationdate,
              b.ownerid, b.modifieddate, b.modifierid, a.dateout as billdate,
              a.docno, NULL AS retailbilltype, a.c_customer_id,
              a.c_dest_id AS c_store_id, a.description, NULL AS c_vip_id,
              NULL AS SALESREP_ID, b.m_product_id, b.m_attributesetinstance_id,
              NULL AS qtyrtl, NULL AS qtyret, b.pricelist,
              b.tot_amtout_list AS tot_amtrtl_list, 0 AS tot_amtret_list,
              b.tot_amtout_list - b.tot_amtout_actual AS tot_amtrtl_discount,
              b.tot_amtout_actual / (1 + nvl(e.taxrate, 0)) AS tot_amtrtl_aftertax,
              b.priceactual, b.tot_amtout_actual AS tot_amtrtl_actual,
              0 AS tot_amtret_actual, 0 AS tot_amtret_discount,
              0 AS tot_amtret_aftertax, b.qtyout as qty,
              b.tot_amtout_list as tot_amt_list,
              b.tot_amtout_actual as tot_amt_actual,
              (b.tot_amtout_list - b.tot_amtout_actual) AS tot_amt_discount,
              b.tot_amtout_actual / (1 + nvl(e.taxrate, 0)) AS tot_amt_aftertax,
              b.discount AS rtldis, 0 AS retdis, d.precost AS percost,
              d.precost * b.qtyout AS tot_amtrtl_cost, 0 AS tot_amtret_cost,
              d.precost * b.qtyout AS tot_amt_cost, 'C' AS c_store_type,
              d.m_dim1_id as brand, 0 as cuponamt
       FROM m_sale a, m_saleitem b, m_product d, c_store e
       WHERE a.id = b.m_sale_id AND b.m_product_id = d.id AND a.c_dest_id = e.id AND
             a.out_status = 2 AND
             a.c_dest_id IN
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id <>
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部')) AND
                    a.c_customerup_id =
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部'))) and
             a.c_dest_id not in
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id in
                    (select a.id
                     from c_customer a, c_cusattribdef b, c_cusattribvalue c
                     where a.c_cusattrib1_id = c.id and b.id = c.c_cusattribdef_id and
                           c.dimflag = 'DIM1' and c.name = '老加盟'))

       UNION
       --新加盟销售退货
       SELECT b.id, b.ad_client_id, b.ad_org_id, b.isactive, b.creationdate,
              b.ownerid, b.modifieddate, b.modifierid, a.datein as billdate,
              a.docno, NULL AS retailbilltype, a.c_customer_id,
              a.c_orig_id AS c_store_id, a.description, NULL AS c_vip_id,
              NULL AS SALESREP_ID, b.m_product_id, b.m_attributesetinstance_id,
              NULL AS qtyrtl, b.qtyin AS qtyret, b.pricelist, 0 AS tot_amtrtl_list,
              b.tot_amtin_list AS tot_amtret_list, 0 AS tot_amtrtl_discount,
              0 AS tot_amtrtl_aftertax, b.priceactual, 0 AS tot_amtrtl_actual,
              b.tot_amtin_actual AS tot_amtret_actual,
              (b.tot_amtin_list - b.tot_amtin_actual) AS tot_amtret_discount,
              b.tot_amtin_actual / (1 + nvl(e.taxrate, 0)) AS tot_amtret_aftertax,
              b.qtyin AS qty, -b.tot_amtin_list AS tot_amtin_list,
              -b.tot_amtin_actual AS tot_amt_actual,
              - (b.tot_amtin_list - b.tot_amtin_actual) AS tot_amt_discount,
              b.tot_amtin_actual / (1 + nvl(e.taxrate, 0)) AS tot_amt_aftertax,
              0 AS rtldis, b.discount AS retdis, d.precost AS percost,
              0 AS tot_amtrtl_cost, d.precost * (b.qtyin) AS tot_amtret_cost,
              d.precost * (-b.qtyin) AS tot_amt_cost, 'C' AS c_store_type,
              d.m_dim1_id as brand, 0 as cuponamt
       FROM m_ret_sale a, m_ret_saleitem b, m_product d, c_store e
       WHERE a.id = b.m_ret_sale_id AND b.m_product_id = d.id AND
             a.c_orig_id = e.id AND a.in_status = 2 AND
             a.c_orig_id IN
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id <>
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部')) AND
                    a.c_customerup_id =
                    (select ID
                     from C_CUSTOMER
                     where c_cusrank_id =
                           (select ID from c_cusrank where name = '总部'))) and
             a.c_orig_id not in
             (SELECT a.id
              FROM c_store a
              WHERE a.c_customer_id in
                    (select a.id
                     from c_customer a, c_cusattribdef b, c_cusattribvalue c
                     where a.c_cusattrib1_id = c.id and b.id = c.c_cusattribdef_id and
                           c.dimflag = 'DIM1' and c.name = '老加盟')))
with read only
/

