CREATE VIEW RP_RETAIL007 AS
  select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.BILLDATE,a.DOCNO,a.retailbilltype,a.c_customer_id,a.C_STORE_ID,a.DESCRIPTION,b.C_VIP_ID,b.SALESREP_ID,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,b.QTY as qtyrtl,null as qtyret,b.PRICELIST,
b.TOT_AMT_LIST as tot_amtrtl_list,null as tot_amtret_list,
b.PRICEACTUAL,b.TOT_AMT_ACTUAL as tot_amtrtl_actual, null as tot_amtret_actual,
b.qty,b.tot_amt_list,b.tot_amt_actual,
b.discount as rtldis, 0 as retdis,nvl(c.PERCOST,(select nvl(d.precost,0) from m_product d where d.id=b.m_product_id)) as PERCOST,
nvl(c.PERCOST,(select nvl(d.precost,0) from m_product d where d.id=b.m_product_id))*b.QTY as tot_amtrtl_cost,null as tot_amtret_cost,
nvl(c.PERCOST,(select nvl(d.precost,0) from m_product d where d.id=b.m_product_id))*b.QTY as tot_amt_cost,b.m_productalias_id as m_product_alias_id,b.type,a.STATUSERID as USERS_ID
from M_RETAIL a,M_RETAILITEM b,FA_PRODUCT_COST c--,m_product d--,m_product_alias s
where a.ID=b.M_RETAIL_ID
and b.m_product_id=c.m_product_id (+)
--and b.m_product_id = d.id
--and b.m_product_id=s.m_product_id(+)
--and b.m_attributesetinstance_id=s.m_attributesetinstance_id(+)
and a.STATUS=2
and b.qty > 0
union all
select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
a.BILLDATE,a.DOCNO,a.retailbilltype,a.c_customer_id,a.C_STORE_ID,a.DESCRIPTION,b.C_VIP_ID,b.SALESREP_ID,b.M_PRODUCT_ID,
b.M_ATTRIBUTESETINSTANCE_ID,null as qtyrtl,-b.qty as qtyret,b.PRICELIST,
null as tot_amtrtl_list,-b.TOT_AMT_LIST as tot_amtret_list,
b.PRICEACTUAL,null as tot_amtrtl_actual, -b.TOT_AMT_ACTUAL as tot_amtret_actual,
b.qty,b.tot_amt_list,b.tot_amt_actual,
0 as rtldis,b.discount as retdis,nvl(c.PERCOST,(select nvl(d.precost,0) from m_product d where d.id=b.m_product_id)) as PERCOST,
null as tot_amtrtl_cost,nvl(c.PERCOST,(select nvl(d.precost,0) from m_product d where d.id=b.m_product_id))*(-b.QTY) as tot_amtret_cost,
nvl(c.PERCOST,(select nvl(d.precost,0) from m_product d where d.id=b.m_product_id))*b.QTY as tot_amt_cost,b.m_productalias_id as m_product_alias_id,b.type,a.STATUSERID as USERS_ID
from M_RETAIL a,M_RETAILITEM b,FA_PRODUCT_COST c--,m_product d--,m_product_alias s
where a.ID=b.M_RETAIL_ID
and b.m_product_id=c.m_product_id (+)
--and b.m_product_id = d.id
--and b.m_product_id=s.m_product_id(+)
--and b.m_attributesetinstance_id=s.m_attributesetinstance_id(+)
--and s.m_product_id=
and a.STATUS=2
and b.qty < 0
with read only
/

