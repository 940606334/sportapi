CREATE VIEW B_PO_SUB_PRINTBOXNO AS
  select b. B_PO_BOXNO_ID,b.B_SO_ID,b.M_PRODUCT_ID,a.VALUE2_CODE as isize,suM(qty) qty,
ROW_NUMBER() OVER(PARTITION by b. B_PO_BOXNO_ID, b.M_PRODUCT_ID order by b. B_PO_BOXNO_ID, b.M_PRODUCT_ID, a.VALUE2_CODE) AS code_id
from b_po_boxitem b, M_ATTRIBUTESETINSTANCE a
where a.id = b.M_ATTRIBUTESETINSTANCE_id
group by b.b_po_boxno_id,b.b_so_id,b.m_product_id,a.value2_code
/

