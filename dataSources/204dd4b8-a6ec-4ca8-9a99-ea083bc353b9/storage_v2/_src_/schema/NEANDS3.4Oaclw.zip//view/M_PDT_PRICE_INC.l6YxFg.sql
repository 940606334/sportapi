CREATE VIEW M_PDT_PRICE_INC AS
  select 'AREA' as c_pricearea_id,t.id as m_product_id,t.name as pdtname,t.pricelist,t.creationdate,t.m_dim2_id
from m_product t,m_dim d
where t.m_dim2_id=d.id
and d.attribcode=to_char(sysdate,'yyyy')

/

