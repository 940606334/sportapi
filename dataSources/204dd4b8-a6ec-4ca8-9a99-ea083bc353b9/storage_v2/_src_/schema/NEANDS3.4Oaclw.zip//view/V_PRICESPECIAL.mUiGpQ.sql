CREATE VIEW V_PRICESPECIAL AS
  select b.id,37 as ad_client_id,27 as ad_org_id,a.docno,a.begindate,a.enddate,a.c_customer_id as c_customerup_id,
       a.description,b.m_product_id,b.price,c.c_salearea_id,null as c_customer_id,a.ownerid,a.creationdate,
       a.modifierid,a.modifieddate,a.isactive
from B_PRICESPECIAL a,B_PRICESPECIAL_MPT b,B_PRICESPECIAL_AREA c
where a.id=b.b_pricespecial_id
and a.id=c.b_pricespecial_id
and a.status=2
union all
select b.id,37 as ad_client_id,27 as ad_org_id,a.docno,a.begindate,a.enddate,a.c_customer_id as c_customerup_id,
       a.description,b.m_product_id,b.price,null,c.c_customer_id,a.ownerid,a.creationdate,
       a.modifierid,a.modifieddate,a.isactive
from B_PRICESPECIAL a,B_PRICESPECIAL_MPT b,B_PRICESPECIAL_CUS c
where a.id=b.b_pricespecial_id
and a.id=c.b_pricespecial_id
and a.status=2
/

