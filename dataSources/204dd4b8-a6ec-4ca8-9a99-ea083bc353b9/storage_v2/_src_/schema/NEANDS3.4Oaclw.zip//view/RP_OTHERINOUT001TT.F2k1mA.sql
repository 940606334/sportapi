CREATE VIEW RP_OTHERINOUT001TT AS
  select b.ID,
       b.AD_CLIENT_ID,
       b.AD_ORG_ID,
       a.BILLDATE,
       a.DOCNO,
       a.C_STORE_ID,
       a.DESCRIPTION,
       c.id C_OTHER_INOUTTYPE_ID,
       a.OTHERBILLTYPE OTHERBILLTYPE,
       b.M_PRODUCT_ID,
       b.M_ATTRIBUTESETINSTANCE_ID,
       b.QTY,
       b.PRICELIST,
       b.TOT_AMT_LIST,
       s.id as m_product_alias_id
  from M_OTHER_INOUT     a,
       M_OTHER_INOUTITEM b,
       m_product_alias   s,
       C_OTHER_INOUTTYPE c
 where a.ID = b.M_OTHER_INOUT_ID
   and b.m_product_id = s.m_product_id(+)
   and b.m_attributesetinstance_id = s.m_attributesetinstance_id(+)
   and a.c_other_inouttype_id = c.id(+)
   and a.STATUS = 2
with read only
/

