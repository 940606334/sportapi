CREATE VIEW RP_ANALYSIS077 AS
  select a.id ,a.ad_client_id,a.ad_org_id, a.ownerid,a.modifierid,
       a.creationdate,a.modifieddate,a.isactive,a.dateout as billdate,
       a.c_store_id,b.m_product_id,b.m_productalias_id,
       b.m_attributesetinstance_id,b.qty as qty_retail , b.tot_amt_actual as amt_retail,
       t.qty as qty_storage , t.qty*r.pricelist as amt_storage,
       decode(b.qty,0,0,t.qty/b.qty) as qtyrate1
from  m_retail a
      join m_retailitem b on a.id=b.m_retail_id
      join m_product r on b.m_product_id=r.id
      left join fa_storage t on (a.c_store_id=t.c_store_id and b.m_product_id=t.m_product_id and
                b.m_attributesetinstance_id=t.m_attributesetinstance_id)
where a.status=2
/

