CREATE VIEW M_EXCEL_STORAGE AS
  select c.name,b.value,a.value1,t.qty,c.m_sizegroup_id from fa_storage t,c_store g,c_customer f,c_cusrank d
,m_product c,m_attributesetinstance a
,m_attributevalue b,m_attributeinstance k
where t.c_store_id=g.id and g.c_customer_id=f.id and g.isfairorig='Y' and t.m_product_id=c.id and t.m_attributesetinstance_id=a.id
and k.m_attributesetinstance_id=a.id and k.m_attributevalue_id=b.id and c.m_sizegroup_id=b.m_attribute_id
and f.c_cusrank_id=d.id and d.name='总部'
/

