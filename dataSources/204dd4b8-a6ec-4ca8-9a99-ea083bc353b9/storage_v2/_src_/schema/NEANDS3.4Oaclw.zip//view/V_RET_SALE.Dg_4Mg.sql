CREATE VIEW V_RET_SALE AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.doctype,a.billdate,a.salesrep_id,a.c_store_id,a.c_customer_id,a.c_customerup_id,a.description,
a.status,a.statuserid,a.statustime,a.tot_lines,a.tot_qty,a.tot_qtyout,a.tot_qtyin,a.in_status,a.out_status,
a.inerid,a.intime,a.outerid,a.outtime,a.diffreason,a.dateout,a.datein,a.retsaletype,a.c_ret_saletype_id,
a.box_status,a.c_tranway_jz_id,a.tranwayno,a.c_orig_id,
b.m_ret_sale_id,b.orderno,b.m_product_id,b.m_attributesetinstance_id,b.qty,b.qtyout,b.qtyin,b.qtydiff,
b.pricelist,b.priceactual,b.discount,b.tot_amt_list,b.tot_amt_actual,b.tot_amtout_list,b.tot_amtout_actual,
b.tot_amtin_list,b.tot_amtin_actual,b.prorate,b.M_PRODUCTALIAS_ID
from m_ret_sale a, m_ret_saleitem b
where a.id = b.m_ret_sale_id
order by docno desc
--with read only
/

