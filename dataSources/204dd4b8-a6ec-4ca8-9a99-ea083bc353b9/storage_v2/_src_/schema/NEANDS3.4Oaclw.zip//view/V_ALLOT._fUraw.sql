CREATE VIEW V_ALLOT AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.doctype,a.c_customerup_id,a.c_orig_id,a.workdate,a.description,a.status,a.p_status,a.redocno,a.storename,a.destname,
b.c_dest_id,b.b_so_id,b.m_product_id,b.m_attributesetinstance_id,
b.qty_allot,b.qtycan,b.qtyrem,b.qty_so from m_allot a, m_allotitem b
where a.id = b.m_allot_id
/

