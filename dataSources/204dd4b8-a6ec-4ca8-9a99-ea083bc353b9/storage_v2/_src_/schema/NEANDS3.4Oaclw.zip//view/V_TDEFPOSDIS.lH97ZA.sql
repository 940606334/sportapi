CREATE VIEW V_TDEFPOSDIS AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.DISTYPE,a.posdisname,a.DATEBEGIN,a.DATEEND,a.CONDITIONDES,a.EXETYPE ,a.EXECONTENT,a.MESSAGE ,a.DESCRIBE ,
a.NOVIPDISC ,a.ISREPEAT,b.store,b.abolished,b.checked,b.abolished1,b.checked1
from tdefposdis a,tdefposdisrel b
where a.id = b.flowno
/

