CREATE VIEW Y_V_COMPLETSER AS
  SELECT t.id, t.ad_client_id, t.ad_org_id, t.isactive, t.modifierid,
       t.creationdate, t.modifieddate, t.ownerid, t.y_inform_id, t.m_product_id,
       t.qty, t.qtycomplete, s.y_workproce_id, s.noqty
FROM (SELECT c.id, c.ad_client_id, c.ad_org_id, c.isactive, c.modifierid,
              c.creationdate, c.modifieddate, c.ownerid, d.y_inform_id,
              d.m_product_id, SUM(d.qty) AS qty, SUM(d.qtycomplete) AS qtycomplete
       FROM y_inform c, y_inform_item d
       WHERE c.id = d.y_inform_id
       AND c.status = 2
       GROUP BY c.id, c.ad_client_id, c.ad_org_id, c.isactive, c.modifierid,
                c.creationdate, c.modifieddate, c.ownerid, d.y_inform_id,
                d.m_product_id) t,
     (SELECT e.y_inform_id, f.y_workproce_id, nvl(SUM(f.qty), 0) AS noqty
       FROM y_completser e, y_completser_item f
       WHERE e.id = f.y_completser_id
       and e.status=2
       GROUP BY e.y_inform_id, f.y_workproce_id) s
WHERE t.id = s.y_inform_id(+)
/

