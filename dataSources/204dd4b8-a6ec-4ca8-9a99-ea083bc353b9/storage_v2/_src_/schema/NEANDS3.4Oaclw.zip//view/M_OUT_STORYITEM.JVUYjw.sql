CREATE VIEW M_OUT_STORYITEM AS
  select TO_NUMBER(a.id||ascii('A')) as id,a.id as real_id,a.ad_client_id,a.ad_org_id,a.isactive,a.creationdate,a.ownerid,a.modifieddate,a.modifierid,
       TO_NUMBER(a.m_sale_id||ascii('A')) as m_out_id,a.m_product_id,a.m_attributesetinstance_id,a.c_store_location_id,
       a.qtyout qty,a.m_productalias_id,'A' as billtype
from m_saleoutstoryitem a
union all
select TO_NUMBER(b.id||ascii('B')) as id,b.id as real_id,b.ad_client_id,b.ad_org_id,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,
       TO_NUMBER(b.m_ret_sale_id||ascii('B')) as m_out_id,b.m_product_id,b.m_attributesetinstance_id,b.c_store_location_id,
       b.qtyout qty,b.m_productalias_id,'B' as billtype
from m_ret_saleoutstoryitem b
union all
select TO_NUMBER(c.id||ascii('C')) as id,c.id as real_id,c.ad_client_id,c.ad_org_id,c.isactive,c.creationdate,c.ownerid,c.modifieddate,c.modifierid,
       TO_NUMBER(c.m_transfer_id||ascii('C')) as m_out_id,c.m_product_id,c.m_attributesetinstance_id,c.c_store_location_id,
       c.qtyout qty,c.m_productalias_id,'C' as billtype
from m_transferoutstoryitem c
union all
select TO_NUMBER(d.id||ascii('D')) as id,d.id as real_id,d.ad_client_id,d.ad_org_id,d.isactive,d.creationdate,d.ownerid,d.modifieddate,d.modifierid,
       TO_NUMBER(d.m_ret_sale_id||ascii('D')) as m_out_id,d.m_product_id,d.m_attributesetinstance_id,d.c_store_location_id,
       d.qtyout qty,d.m_productalias_id,'D' as billtype
from m_ret_saleoutstoryitem d
union all
select TO_NUMBER(e.id||ascii('E')) as id,e.id as real_id,e.ad_client_id,e.ad_org_id,e.isactive,e.creationdate,e.ownerid,e.modifieddate,e.modifierid,
       TO_NUMBER(e.m_ret_pur_id||ascii('E')) as m_out_id,e.m_product_id,e.m_attributesetinstance_id,e.c_store_location_id,
       e.qty,e.m_productalias_id,'E' as billtype
from m_ret_purstoryitem e
/

