CREATE VIEW V_Y_FA_STORAGE AS
  SELECT id, ad_client_id, ad_org_id, y_warehouse_id, y_material_id, y_color_id,
       fabric_width, fabric_weight, y_spec_id, unit_id, m_product_id, qty,
       qtypreout, qtyprein, ownerid, modifierid, creationdate, modifieddate,
       isactive, y_materialalias_id,
       (nvl(qty, 0) - nvl(qtypreout, 0) + nvl(qtyprein, 0)) AS qtyvalid
FROM y_fa_storage
WHERE (qty <> 0 OR qtypreout <> 0 OR qtyprein <> 0)
/

