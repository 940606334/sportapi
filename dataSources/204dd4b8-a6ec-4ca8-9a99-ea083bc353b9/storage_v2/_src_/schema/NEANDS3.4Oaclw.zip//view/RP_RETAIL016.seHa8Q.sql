CREATE VIEW RP_RETAIL016 AS
  select b1.id,
b1.ad_client_id,
b1.ad_org_id,
b1.ownerid,
b1.modifierid,
b1.creationdate,
b1.modifieddate,
b1.isactive,
b1.c_store_id,
b1.billdate,
b1.docno,
b2.salesrep_id,
b2.tot_amt_actual,
b1.c_customer_id,
b2.m_product_id,
b2.m_attributesetinstance_id,
b2.pricelist,
b2.priceactual,
b2.qty,
(select b3.acost from m_product b3 where b3.id=b2.m_product_id) as acost,
(select b3.acost from m_product b3 where b3.id=b2.m_product_id)*b2.qty as PRICEACOST,
b2.tot_amt_actual-(select b3.acost from m_product b3 where b3.id=b2.m_product_id)*b2.qty as PREGROSS,
decode(b2.tot_amt_actual,0,0,round(((b2.tot_amt_actual-(select b3.acost from m_product b3 where b3.id=b2.m_product_id)*b2.qty)/b2.tot_amt_actual),2)) as PREGROSSRATE,
decode(b2.tot_amt_list,0,0,b2.tot_amt_actual/b2.tot_amt_list) as discount,
b2.m_productalias_id,
b2.tot_amt_list,
b2.type
from M_RETAIL b1,M_RETAILITEM b2
where b2.m_retail_id=b1.id  and b1.status=2
with read only
/

