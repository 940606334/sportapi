CREATE VIEW M_V_AREAPICKOCCUPYITEM AS
  SELECT t.id, t.ad_client_id, t.ad_org_id, t.ownerid, t.modifierid,
       t.creationdate, t.modifieddate, t.isactive, t.m_productalias_id,
       t.m_product_id, t.c_store_location_id, t.qty_suggest, t.m_areapick_id,
       0 AS orderno, 0 AS qty, 0 AS qtydiff, ' ' AS remark, ' ' AS stock_state
FROM m_areapick_occupyitem t, m_areapick b
WHERE t.m_areapick_id = b.id AND b.status = 1 and b.isactive='Y'
/

