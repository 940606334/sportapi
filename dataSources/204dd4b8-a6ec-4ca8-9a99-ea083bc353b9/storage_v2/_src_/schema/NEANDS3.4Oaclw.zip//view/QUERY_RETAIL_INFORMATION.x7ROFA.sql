CREATE VIEW QUERY_RETAIL_INFORMATION AS
  select a.id,
       a.ad_client_id,
       a.ad_org_id,
       a.ownerid,
       a.modifierid,
       a.creationdate,
       a.modifieddate,
       a.isactive,
       a.dateout,
       decode(a.in_status, 2, a.datein, null) as datein,
       a.docno,
       a.b_so_id,
       a.c_dest_id,
       a.doctype,
       a.shipping_remark,
       a.description,
       b.m_product_id,
       b.m_attributesetinstance_id,
       b.qtyout,
       b.tot_amtout_actual,
       b.tot_amtout_list
  from m_sale a, m_saleitem b
 where a.id = b.m_sale_id
   and a.out_status = 2
/

