CREATE VIEW V_RET_PUR AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.doctype,a.billdate,a.datein,a.c_store_id,a.c_supplier_id,a.description,a.tot_qty,a.tot_qtyout,
a.status,a.out_status,a.statuserid,a.statustime,a.outtime,a.outerid,a.inerid,a.intime,
b.m_product_id,b.m_attributesetinstance_id,b.orderno,b.qty,b.qtyout,b.qtydiff,b.pricelist,b.priceactual,
b.discount,b.tot_amt_list,b.tot_amt_actual,b.tot_amtout_list,b.tot_amtout_actual,b.M_PRODUCTALIAS_ID
from m_ret_pur a, m_ret_puritem b
where a.id = b.m_ret_pur_id
order by docno desc
--with read only
/

