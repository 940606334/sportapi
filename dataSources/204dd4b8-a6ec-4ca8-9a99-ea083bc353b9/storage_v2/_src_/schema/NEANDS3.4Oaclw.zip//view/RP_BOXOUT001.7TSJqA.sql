CREATE VIEW RP_BOXOUT001 AS
  SELECT b.id, b.y_boxout_id, a.billdate, a.trainnumber,e.b_so_id,e.b_po_box_id,e.c_customer_id,e.m_product_id,e.m_matchsize_id,b.b_po_boxno_id,c.m_purchase_quick_id,d.m_sale_quick_id,1 as qty
FROM y_boxout a, y_boxoutitem b,M_PURCHASE_QUICKitem c,M_SALE_QUICKitem d,b_po_boxno e
WHERE a.id = b.y_boxout_id
and b.b_po_boxno_id=e.id
and b.b_po_boxno_id=c.b_po_boxno_id(+)
and b.b_po_boxno_id=d.b_po_boxno_id(+)
AND a.status = 2
WITH READ ONLY
/

