CREATE VIEW RP_SALE004 AS
  select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,a.salebilltype,
a.dateout as BILLDATE,a.DOCNO,a.DOCTYPE,a.B_SO_ID,a.C_CUSTOMER_ID,a.c_dest_id as C_STORE_ID,
a.DESCRIPTION,b.M_PRODUCT_ID,b.M_ATTRIBUTESETINSTANCE_ID,c.tot_amt_actual as amtso,
c.QTY as QTYORDERED,nvl(b.qty,0)QTYOCCU,(nvl(b.qty,0)-nvl(b.qtyout,0))*c.priceactual as amtsooccu,(nvl(b.qty,0)-nvl(b.qtyout,0))*b.pricelist as amtlistsooccu ,nvl(b.QTY,0) as QTYSALE,nvl(b.QTYOUT,0) as QTYSALEOUT,0 as QTYRETSALE,0 as QTYRETSALEIN,NVL(b.PRICELIST,0)PRICELIST,
b.TOT_AMT_LIST as AMTLISTSALE,b.TOT_AMTOUT_LIST as AMTLISTSALEOUT,0 as AMTLISTRETSALE,0 as AMTLISTRETSALEIN,
b.PRICEACTUAL,b.TOT_AMT_ACTUAL as AMTSALE,b.TOT_AMTOUT_ACTUAL as AMTSALEOUT,0 as AMTRETSALE,0 as AMTRETSALEIN,
b.DISCOUNT as DISCOUNTSALE,0 as DISCOUNTRETSALE,a.OUTERID ,0 as inerid,decode(b.pricelist,0,0, b.PRICEACTUAL /b.pricelist )as DISCOUNTOUT,nvl(b.TOT_AMTOUT_ACTUAL,0) as fap,nvl(b.TOT_AMTOUT_ACTUAL/1.17,0) as un_fap
from M_SALE a
inner join M_SALEITEM b on  a.ID=b.M_SALE_ID
left join B_SOITEM c on a.B_SO_ID=c.B_SO_ID and b.M_PRODUCT_ID=c.M_PRODUCT_ID and b.M_ATTRIBUTESETINSTANCE_ID=c.M_ATTRIBUTESETINSTANCE_ID
where a.OUT_STATUS=2
union all
select b.ID,b.AD_CLIENT_ID,b.AD_ORG_ID,b.isactive,b.creationdate,b.ownerid,b.modifieddate,b.modifierid,null as salebilltype,
a.datein as BILLDATE,a.DOCNO,a.DOCTYPE,0 as B_SO_ID,a.C_CUSTOMER_ID ,a.c_orig_id as C_STORE_ID,
a.DESCRIPTION,b.M_PRODUCT_ID,b.M_ATTRIBUTESETINSTANCE_ID,0 as amtso,
0 as QTYORDERED,0 as qtyoccu,0 as amtsoooccu,0 as amtlistsoooccu ,0 as QTYSALE,0 as QTYSALEOUT,b.QTY as QTYRETSALE,b.QTYIN as QTYRETSALEIN,b.PRICELIST,
0 as AMTLISTSALE,0 as AMTLISTSALEOUT,b.TOT_AMT_LIST as AMTLISTRETSALE,b.TOT_AMTIN_LIST as AMTLISTRETSALEIN,
b.PRICEACTUAL,0 as AMTSALE,0 as AMTSALEOUT,b.TOT_AMT_ACTUAL as AMTRETSALE,b.TOT_AMTIN_ACTUAL as AMTRETSALEIN,
 0 as DISCOUNTSALE,b.DISCOUNT as DISCOUNTRETSALE,0 AS OUTERID,a.INerid, 0 as DISCOUNTOUT, nvl(-b.TOT_AMTIN_ACTUAL,0)  as fap,nvl(-b.TOT_AMTIN_ACTUAL/1.17,0) as un_fap
from M_RET_SALE a,M_RET_SALEITEM b
where a.ID=b.M_RET_SALE_ID
and a.IN_STATUS=2
with read only
/

