CREATE VIEW TDEFOSTYLE AS
  select style,stylename,Dprice,Marketdate,UNIT,Remark,Sizegid,
attrib1,attrib2,attrib3,attrib4,attrib5,attrib6,attrib7,attrib8,attrib9,attrib10,
attrib11,attrib12,attrib13,attrib14,attrib15,attrib16,attrib17,attrib18,attrib19,attrib20,attrib21,PRICE_sug as PRICE
from
(
select to_char(c.name) as style, to_char(c.value) as stylename,
       c.pricelist as dprice, c.creationdate as marketdate,c.unit,
       to_char(c.documentnote) as remark,
       (select to_char(t.name)
         from (select b.name as sname, a.name, a.description
                from M_ATTRIBUTE a, M_PRODUCT b
                where a.CLRSIZE = 2 and a.id = b.M_SIZEGROUP_ID) t
         where t.sname = c.name) as Sizegid,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM1' and b.M_DIM1_id = a.id) t
         where t.name = c.name) as attrib1,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM2' and b.M_DIM2_id = a.id) t
         where t.name = c.name) as attrib2,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM3' and b.M_DIM3_id = a.id) t
         where t.name = c.name) as attrib3,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM4' and b.M_DIM4_id = a.id) t
         where t.name = c.name) as attrib4,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM5' and b.M_DIM5_id = a.id) t
         where t.name = c.name) as attrib5,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM6' and b.M_DIM6_id = a.id) t
         where t.name = c.name) as attrib6,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM7' and b.M_DIM7_id = a.id) t
         where t.name = c.name) as attrib7,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM8' and b.M_DIM8_id = a.id) t
         where t.name = c.name) as attrib8,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM9' and b.M_DIM9_id = a.id) t
         where t.name = c.name) as attrib9,
       (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM10' and b.M_DIM10_id = a.id) t
         where t.name = c.name) as attrib10,
         (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM11' and b.M_DIM11_id = a.id) t
         where t.name = c.name) as attrib11,
         (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM12' and b.M_DIM12_id = a.id) t
         where t.name = c.name) as attrib12,
         (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM13' and b.M_DIM13_id = a.id) t
         where t.name = c.name) as attrib13,
         (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM14' and b.M_DIM14_id = a.id) t
         where t.name = c.name) as attrib14,
         (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM15' and b.M_DIM15_id = a.id) t
         where t.name = c.name) as attrib15,
          (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM16' and b.M_DIM16_id = a.id) t
         where t.name = c.name) as attrib16,
          (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM17' and b.M_DIM17_id = a.id) t
         where t.name = c.name) as attrib17,
          (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM18' and b.M_DIM18_id = a.id) t
         where t.name = c.name) as attrib18,
          (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM19' and b.M_DIM19_id = a.id) t
         where t.name = c.name) as attrib19,
          (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM20' and b.M_DIM20_id = a.id) t
         where t.name = c.name) as attrib20,
              (select to_char(t.ATTRIBCODE)
         from (select b.name, a.ATTRIBCODE, a.ATTRIBNAME
                from M_DIM a, M_PRODUCT b
                where a.dimflag = 'DIM21' and b.M_DIM21_id = a.id) t
         where t.name = c.name) as attrib21,PRICE_sug
from M_PRODUCT c, B_FAIR a,B_FAIRITEM b
where c.id(+)=b.M_PRODUCT_ID and a.id(+)=b.b_fair_id
and  to_char(sysdate, 'yyyymmdd')> = to_char(to_date(a.DATESTART,'yyyymmdd'),'YYYYMMDD')
and  to_char(sysdate, 'yyyymmdd') <= to_char(to_date(a.DATEEND,'yyyymmdd'),'YYYYMMDD')
)
group by style,stylename,Dprice,Marketdate,UNIT,Remark,Sizegid,
attrib1,attrib2,attrib3,attrib4,attrib5,attrib6,attrib7,attrib8,attrib9,attrib10,
attrib11,attrib12,attrib13,attrib14,attrib15,attrib16,attrib17,attrib18,attrib19,attrib20,attrib21,PRICE_sug
/

