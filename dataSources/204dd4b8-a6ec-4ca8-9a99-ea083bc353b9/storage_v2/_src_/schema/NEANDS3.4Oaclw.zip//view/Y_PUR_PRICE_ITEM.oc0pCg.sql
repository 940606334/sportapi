CREATE VIEW Y_PUR_PRICE_ITEM AS
  SELECT id, ad_client_id, ad_org_id, isactive, creationdate, ownerid,
       modifieddate, modifierid, y_purchase_id, y_material_id, y_color_id,
       fabric_width, fabric_weight, y_spec_id, qty, qtyin, purchase_unit_id,
       purchase_rate, use_unit_id, fprice, tax_dis, famount, famountin,
       m_product_id, pricecheck, famountin_pcheck, pricemodify, famountin_dec,
       famountin_fee, famountin_pchecktax, y_materialalias_id, tax_amt,
       a.notax_amt, a.notax_price
FROM y_purchase_item a
WHERE in_status = 2
/

