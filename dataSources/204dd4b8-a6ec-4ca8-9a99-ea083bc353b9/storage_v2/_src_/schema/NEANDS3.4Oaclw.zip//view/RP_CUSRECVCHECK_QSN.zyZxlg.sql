CREATE VIEW RP_CUSRECVCHECK_QSN AS
  select h."ID",h."AD_CLIENT_ID",h."AD_ORG_ID",h."OWNERID",h."CREATIONDATE",h."ISACTIVE", h.MODIFIEDDATE,h."MODIFIERID",h."DOCNO",h."DOCTYPE",h."BILLDATE",h."C_CUSTOMER_ID",h."DESCRIPTION",
h."M_SALE_ID",h."M_RET_SALE_ID",h."TOT_AMT_ACTUAL",h."C_FEETYPE_ID",h."OTHER_DAMT",h."OTHER_CAMT",LAG("TOTAL",1,NULL)
  OVER (partition by c_customer_id
        ORDER BY billdate,MODIFIEDDATE) last_hire,
h."COLLECT_AMT",h."DEDUCT_AMT",h."TOTAL"
from
(select k.*,

SUM(k.tot_amt_actual)
    OVER (partition by c_customer_id
          ORDER BY billdate,MODIFIEDDATE
          ROWS 10000000 PRECEDING) as "TOTAL"

from (select
       g.id,g.ad_client_id,g.ad_org_id,
       g.docno,
       g.doctype,
       g.billdate,
       g.c_customer_id,
       g.description,
       g.status,
       null as m_sale_id,
       null as m_ret_sale_id,
       g.tot_amt_actual,
       g.c_feetype_id,
       decode(e.ftype,'S',0,g.tot_amt_actual)  as collect_amt,
       0 as deduct_amt,
       g.ownerid,
       g.creationdate,
       g.isactive,
       to_char(g.modifieddate,'yyyy-mm-dd hh24:mi:ss')modifieddate,
       g.modifierid,
       decode(e.ftype,'S',g.tot_amt_actual,0) as other_camt,

       0 as other_damt
     from  b_receive g,c_feetype e where g.status =2 and g.c_feetype_id =e.id

     union
select
       t.id,t.ad_client_id,t.ad_org_id,
       t.docno,
       t.doctype,
       t.billdate,
       t.c_customer_id,
       t.description,
       t.status,
       t.m_sale_id,
       t.m_ret_sale_id,
       -t.tot_amt_actual as tot_amt_actual,
       t.c_feetype_id,
       0 as collect_amt,
       decode(e.ftype,'C',0,t.tot_amt_actual) as deduct_amt,
       t.ownerid,
       t.creationdate,
       t.isactive,
       to_char(t.modifieddate,'yyyy-mm-dd hh24:mi:ss')modifieddate,
       t.modifierid,
       0 as other_camt,
       decode(e.ftype,'C',t.tot_amt_actual,0) as other_damt

     from  b_receivable t,c_feetype e where t.status =2 and t.c_feetype_id =e.id )k where exists (select 1 from dual where k.c_customer_id=c_customer_id)
  ) h
  order by  billdate,modifieddate
/

