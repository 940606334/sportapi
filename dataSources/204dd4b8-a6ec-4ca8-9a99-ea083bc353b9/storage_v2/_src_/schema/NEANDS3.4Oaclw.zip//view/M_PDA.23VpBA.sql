CREATE VIEW M_PDA AS
  SELECT t.id, g.id AS m_product_id, t.no, g.NAME, g.VALUE, t.forcode, e.value1,
       e.value1_code, e.value2, e.value2_code, g.pricelist,
       decode(g.is_retail, 'Y', 'N', t.isactive) AS isactive, t.intscode,
       t.bind_proalias01, t.bind_proalias02
FROM m_product_alias t, m_product g, m_attributesetinstance e
WHERE t.m_attributesetinstance_id = e.id
AND t.m_product_id = g.id
and t.isactive='Y'
and g.isactive='Y'/* edit by Selina 2017/11/3 22:37:49 */

