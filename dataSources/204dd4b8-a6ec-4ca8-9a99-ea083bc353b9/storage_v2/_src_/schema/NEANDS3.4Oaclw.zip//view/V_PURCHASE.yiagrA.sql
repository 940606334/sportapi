CREATE VIEW V_PURCHASE AS
  select b.id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.creationdate,b.modifieddate,a.isactive,
a.docno,a.doctype,a.b_po_id,a.billdate,a.datein,a.c_customer_id,a.c_store_id,a.c_supplier_id,
a.c_purchasetype_id,a.description,a.status,a.in_status,a.pck_status,a.statuserid,a.statustime,a.inerid,a.intime,
b.m_product_id,b.m_attributesetinstance_id,b.orderno,b.qty,b.qtyin,b.qtydiff,b.pricelist,b.priceactual,b.pricecheck,
b.discount,b.tot_amt_list,b.tot_amt_actual,b.tot_amtin_list,b.tot_amtin_actual,b.tot_amtin_pcheck,b.M_PRODUCTALIAS_ID
from m_purchase a, m_purchaseitem b
where a.id = b.m_purchase_id
order by docno desc
--with read only
/

