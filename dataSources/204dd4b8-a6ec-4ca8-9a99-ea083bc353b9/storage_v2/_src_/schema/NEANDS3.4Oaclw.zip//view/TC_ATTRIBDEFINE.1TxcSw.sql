CREATE VIEW TC_ATTRIBDEFINE AS
  select t.id  ,t.name as attrib_name,substr(t.dimflag,4) as attrib from m_dimdef t
/

