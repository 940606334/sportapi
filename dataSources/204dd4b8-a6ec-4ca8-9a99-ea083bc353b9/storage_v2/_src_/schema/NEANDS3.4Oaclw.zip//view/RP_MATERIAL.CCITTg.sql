CREATE VIEW RP_MATERIAL AS
  select max(b.id) as id,b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,max(b.creationdate) as creationdate,
       max(b.modifieddate) as modifieddate,b.isactive,
       a.docno,a.billdate,a.c_store_id,a.c_supplier_id,b.c_material_id,a.dateout,b.spec,b.unit_text,
       sum(b.pricelist) as pricelist,sum(b.priceactual) as priceactual,sum(b.qty) as qty,
       sum(b.tot_amt_list) as tot_amt_list,sum(b.tot_amt_actual) as tot_amt_actual,
       decode(a.acc_status,1,decode(a.agr_status,1,decode(a.in_status,1,decode(a.out_status,1,decode(a.status,1,'未申请',2,'已申请')
       ,2,'已出货'),2,'已收货'),2,'已同意结算'),2,'已结算') as status
from C_MATERIALAPPLY a,C_MATERIALAPPLYITEM b
where a.id = b.C_MATERIALAPPLY_ID
group by b.ad_client_id,b.ad_org_id,b.ownerid,b.modifierid,b.isactive,
         a.docno,a.billdate,a.c_store_id,a.c_supplier_id,b.c_material_id,a.dateout,b.spec,
         b.unit_text,b.qty_text,a.ACC_STATUS,a.agr_status,a.status,a.out_status,a.in_status
order by a.docno
/

