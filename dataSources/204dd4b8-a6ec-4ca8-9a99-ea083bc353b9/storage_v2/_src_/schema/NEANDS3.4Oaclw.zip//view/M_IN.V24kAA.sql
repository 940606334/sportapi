CREATE VIEW M_IN AS
  SELECT to_number(a.id || ascii('H')) AS id, a.id AS real_id, a.ad_client_id,
       a.ad_org_id, a.ownerid, a.modifierid, a.creationdate, a.modifieddate,
       a.isactive, 'M_SALEIN' AS billtype, a.docno, a.doctype, a.billdate,
       a.c_customerup_id, a.c_customer_id, b.NAME AS origname, a.c_dest_id,
       a.description, a.diffreason, a.box_status, a.in_status AS status,
       a.in_au_state AS au_state, a.in_au_pi_id AS au_pi_id, a.avg_discount,
       a.tot_lines, a.tot_qtyout, a.tot_amtout_list, a.tot_amtout_actual,
       a.tot_qtyin, a.tot_amtin_list, a.tot_amtin_actual, a.dateout, a.datein,
       a.statuserid, a.statustime, a.outerid, a.outtime, a.inerid, a.intime,
       a.c_saletype_id AS type_id, a.saletype AS dealtype, a.operatoerid,
       a.oper_status, a.tot_amt_precost, a.tot_amtin_precost, NULL AS imageurl,
       a.tot_qtyout - a.tot_qtyin AS tot_qtydiff, NULL AS qtydiff,
       a.c_cargointype_id AS c_cargotype_id,
       (CASE
            WHEN substr(a.dateout, 5, 2) = substr(a.datein, 5, 2) THEN
             'Y'
            ELSE
             'N'
        END) AS issamemonth, a.c_store_location_id, a.printintimes AS printtimes,
       'N' AS scanstate, a.realdate, NULL AS if_goodsarr, b.code AS origcode,
       NULL AS check_status, NULL AS checkerid, NULL AS checktime,
       NULL AS datewh, NULL AS c_crosstore_id1, NULL AS c_crosstore_id2,
       0 AS tot_fgood_qty, 0 AS tot_good_qty, 0 AS tot_defect_qty,'N' as IS_TOWMS,a.in_many_status,8 as TRAINNUMBER,
       a.description2,nvl(a.tot_box,0) as tot_box,a.c_store_id,a.tot_boxout,null as TRANWAY_PAYDEST,A.PICKERID
FROM m_sale a, c_store b
WHERE a.c_store_id = b.id
AND a.status = 2
AND a.out_status = 2 --and a.in_status = 1
and a.m_crosale_id is null
UNION ALL
SELECT to_number(a.id || ascii('I')) AS id, a.id AS real_id, a.ad_client_id,
       a.ad_org_id, a.ownerid, a.modifierid, a.creationdate, a.modifieddate,
       a.isactive, 'M_RET_SALEIN' AS billtype, a.docno, a.doctype, a.billdate,
       a.c_customer_id, a.c_customerup_id, b.NAME AS origname,
       a.c_store_id AS c_dest_id, a.description, a.diffreason, a.box_status,
       a.in_status AS status, a.in_au_state AS au_state,
       a.in_au_pi_id AS au_pi_id, a.avg_discount, a.tot_lines, a.tot_qtyout,
       a.tot_amtout_list, a.tot_amtout_actual, a.tot_qtyin, a.tot_amtin_list,
       a.tot_amtin_actual, a.dateout, a.datein, a.statuserid, a.statustime,
       a.outerid, a.outtime, a.inerid, a.intime, a.c_ret_saletype_id AS type_id,
       a.retsaletype AS dealtype, a.operatoerid, a.oper_status,
       a.tot_amt_precost, a.tot_amtin_precost, a.imageurl AS imageurl,
       a.tot_qtyout - a.tot_qtyin AS tot_qtydiff, NULL AS qtydiff,
       a.c_cargointype_id AS c_cargotype_id,
       (CASE
            WHEN substr(a.dateout, 5, 2) = substr(a.datein, 5, 2) THEN
             'Y'
            ELSE
             'N'
        END) AS issamemonth, a.c_store_location_id, a.printintimes AS printtimes,
       a.scanstate, a.realdate, NULL AS if_goodsarr, b.code AS origcode,
       NULL AS check_status, NULL AS checkerid, NULL AS checktime,
       NULL AS datewh, NULL AS c_crosstore_id1, NULL AS c_crosstore_id20,
       0 AS tot_fgood_qty, 0 AS tot_good_qty, 0 AS tot_defect_qty,A.IS_TOWMS,2,8 as TRAINNUMBER,
       a.description2,nvl(a.tot_box,0) as tot_box,a.C_ORIG_ID,a.tot_boxout,null,A.PICKERID
FROM m_ret_sale a, c_store b
WHERE a.c_orig_id = b.id
AND a.status = 2
AND a.out_status = 2 --and a.in_status = 1
and a.m_croretsale_id is null
UNION ALL
SELECT to_number(a.id || ascii('J')) AS id, a.id AS real_id, a.ad_client_id,
       a.ad_org_id, a.ownerid, a.modifierid, a.creationdate, a.modifieddate,
       a.isactive, 'M_TRANSFERIN' AS billtype, a.docno, a.doctype, a.billdate,
       a.c_customer_id AS c_customerup_id, a.c_customer_id, b.NAME AS origname,
       a.c_dest_id, a.description, a.diffreason, a.box_status,
       a.in_status AS status, a.in_au_state AS au_state,
       a.in_au_pi_id AS au_pi_id, NULL AS avg_discount, a.tot_lines,
       a.tot_qtyout, a.tot_amtout_list, NULL AS tot_amtout_actual, a.tot_qtyin,
       a.tot_amtin_list, NULL AS tot_amtin_actual, a.dateout, a.datein,
       a.statuserid, a.statustime, a.outerid, a.outtime, a.inerid, a.intime,
       a.c_transfertype_id AS type_id, a.transfertype AS dealtype, a.operatoerid,
       a.oper_status, a.tot_amt_precost, a.tot_amtin_precost, NULL AS imageurl,
       a.tot_qtyout - a.tot_qtyin AS tot_qtydiff, NULL AS qtydiff,
       a.c_cargointype_id AS c_cargotype_id,
       (CASE
            WHEN substr(a.dateout, 5, 2) = substr(a.datein, 5, 2) THEN
             'Y'
            ELSE
             'N'
        END) AS issamemonth, a.c_store_location_id, a.printintimes AS printtimes,
       a.scanstate, a.realdate, NULL AS if_goodsarr, b.code AS origcode,
       NULL AS check_status, NULL AS checkerid, NULL AS checktime,
       NULL AS datewh, NULL AS c_crosstore_id1, NULL AS c_crosstore_id2,
       0 AS tot_fgood_qty, 0 AS tot_good_qty, 0 AS tot_defect_qty,A.IS_TOWMS,2,8 as TRAINNUMBER,
       a.description2,nvl(a.tot_box,0) as tot_box,a.C_ORIG_ID,a.tot_boxout,a.TRANWAY_PAYDEST,A.PICKERID
FROM m_transfer a, c_store b
WHERE a.c_orig_id = b.id
AND a.status = 2
AND a.out_status = 2 --and a.in_status = 1
UNION ALL
SELECT to_number(a.id || ascii('K')) AS id, a.id AS real_id, a.ad_client_id,
       a.ad_org_id, a.ownerid, a.modifierid, a.creationdate, a.modifieddate,
       a.isactive, 'M_V_CUSPURIN' AS billtype, a.docno, a.doctype, a.billdate,
       a.c_customerup_id, a.c_customer_id, b.NAME AS origname, a.c_dest_id,
       a.description, a.diffreason, a.box_status, a.in_status AS status,
       a.in_au_state AS au_state, a.in_au_pi_id AS au_pi_id, a.avg_discount,
       a.tot_lines, a.tot_qtyout, a.tot_amtout_list, a.tot_amtout_actual,
       a.tot_qtyin, a.tot_amtin_list, a.tot_amtin_actual, a.dateout, a.datein,
       a.statuserid, a.statustime, a.outerid, a.outtime, a.inerid, a.intime,
       a.c_saletype_id AS type_id, a.saletype AS dealtype, a.operatoerid,
       a.oper_status, a.tot_amt_precost, a.tot_amtin_precost, NULL AS imageurl,
       a.tot_qtyout - a.tot_qtyin AS tot_qtydiff, NULL AS qtydiff,
       a.c_cargointype_id AS c_cargotype_id,
       (CASE
            WHEN substr(a.dateout, 5, 2) = substr(a.datein, 5, 2) THEN
             'Y'
            ELSE
             'N'
        END) AS issamemonth, a.c_store_location_id, a.printintimes AS printtimes,
       'N' AS scanstate, a.realdate, NULL AS if_goodsarr, b.code AS origcode,
       NULL AS check_status, NULL AS checkerid, NULL AS checktime,
       NULL AS datewh, NULL AS c_crosstore_id1, NULL AS c_crosstore_id2,
       0 AS tot_fgood_qty, 0 AS tot_good_qty, 0 AS tot_defect_qty,'N' as is_towms,a.in_many_status,8 as TRAINNUMBER,
       a.description2,nvl(a.tot_box,0) as tot_box,a.c_store_id,a.tot_boxout,null,A.PICKERID
FROM m_sale a, c_store b
WHERE a.c_store_id = b.id
AND a.status = 2
AND a.out_status = 2 --and a.in_status = 1
and a.m_crosale_id is null
UNION ALL
SELECT to_number(a.id || ascii('L')) AS id, a.id AS real_id, a.ad_client_id,
       a.ad_org_id, a.ownerid, a.modifierid, a.creationdate, a.modifieddate,
       a.isactive, 'M_PURCHASEIN' AS billtype, a.docno, a.doctype, a.billdate,
       c_customer_id AS c_customerup_id, c_customer_id, b.NAME AS origname,
       a.c_store_id AS c_dest_id, a.description, a.diffreason, 1 AS box_status,
       a.in_status AS status, a.in_au_state AS au_state,
       a.in_au_pi_id AS au_pi_id, a.avg_discount, a.tot_lines,
       a.tot_qty AS tot_qtyout, a.tot_amt_list AS tot_amtout_list,
       a.tot_amt_actual AS tot_amtout_actual, a.tot_qtyin, a.tot_amtin_list,
       a.tot_amtin_actual, a.dateout, a.datein, a.statuserid, a.statustime,
       NULL AS outerid, NULL AS outtime, a.inerid, a.intime, NULL AS type_id,
       NULL AS dealtype, a.operatoerid, a.oper_status, a.tot_amt_precost,
       a.tot_amtin_precost, NULL AS imageurl,
       a.tot_qty - a.tot_qtyin AS tot_qtydiff,
       (SELECT SUM(abs(a1.qtydiff))
         FROM m_purchaseitem a1
         WHERE a.id = a1.m_purchase_id) AS qtydiff,
       a.c_cargointype_id AS c_cargotype_id, 'N' AS issamemonth,
       a.c_store_location_id, a.printintimes AS printtimes, 'N' AS scanstate,
       a.realdate, a.if_goodsarr, b.code AS origcode, a.check_status,
       a.checkerid, a.checktime, a.datewh, NULL AS c_crosstore_id1,
       NULL AS c_crosstore_id2, a.tot_fgood_qty, a.tot_good_qty,
       a.tot_defect_qty,a.is_towms,2,a.TRAINNUMBER,a.description2,nvl(a.tot_box,0) as tot_box,null,nvl(a.tot_box,0)  as tot_boxout,null,A.PICKERID
FROM m_purchase a, c_supplier b
WHERE a.c_supplier_id = b.id
AND a.status = 2 --and a.in_status = 1
UNION ALL
SELECT to_number(a.id || ascii('M')) AS id, a.id AS real_id, a.ad_client_id,
       a.ad_org_id, a.ownerid, a.modifierid, a.creationdate, a.modifieddate,
       a.isactive, 'CRO_SALEIN' AS billtype, a.docno, NULL AS doctype,
       a.billdate, NULL AS c_customerup_id, NULL AS c_customer_id,
       b.NAME AS origname, a.c_dest_id, description1 AS description,
       diff_reason AS diffreason, NULL AS box_status, a.in_status AS status,
       NULL AS au_state, NULL AS au_pi_id, NULL AS avg_discount,
       NULL AS tot_lines, a.tot_qtyout AS tot_qtyout,
       a.tot_amtout_list AS tot_amtout_list,
       decode(a.CROSS_TYPE,'C1',a.tot_amtout_actual1,A.tot_amtout_actual2) AS tot_amtout_actual,
        a.tot_qtyin AS tot_qtyin, a.tot_amtin_list AS tot_amtin_list,
        decode(a.CROSS_TYPE,'C1',a.tot_amtin_actual2,a.tot_amtin_actual3) AS tot_amtin_actual,
        a.dateout AS dateout, a.datein AS datein, a.statuserid, a.statustime,a.outerid AS outerid,
       A.OUTTIME AS outtime, A.INERID AS inerid, A.INTIME AS intime, NULL AS type_id,
       a.saletype1 AS dealtype, NULL AS operatoerid, NULL AS oper_status,
       0 tot_amt_precost, 0 AS tot_amtin_precost, NULL AS imageurl,
       A.tot_qtydiff AS tot_qtydiff, 0 AS qtydiff, NULL AS c_cargotype_id,
       (CASE
            WHEN substr(a.dateout, 5, 2) = substr(a.datein, 5, 2) THEN
             'Y'
            ELSE
             'N'
        END) AS issamemonth, NULL AS c_store_location_id, 0 AS printtimes,
       'N' AS scanstate, NULL AS realdate, NULL AS if_goodsarr,
       b.code AS origcode, NULL AS check_status, NULL AS checkerid,
       NULL AS checktime, NULL AS datewh, c_transtore_id1 AS c_crosstore_id1,
       c_transtore_id2 AS c_crosstore_id2, 0 AS tot_fgood_qty, 0 AS tot_good_qty,
       0 AS tot_defect_qty,a.is_towms,2,8 as TRAINNUMBER,null as description2,0 as tot_box,null,0 as tot_Boxout,null,A.PICKERID
FROM m_cro_sale a, c_store b
WHERE a.c_store_id = b.id
AND a.status = 2
AND a.out_status = 2 --and a.in_status = 1
UNION ALL
SELECT to_number(a.id || ascii('N')) AS id, a.id AS real_id, a.ad_client_id,
       a.ad_org_id, a.ownerid, a.modifierid, a.creationdate, a.modifieddate,
       a.isactive, 'CRO_RETSALEIN' AS billtype, a.docno, NULL AS doctype,
       a.billdate, NULL AS c_customerup_id, NULL AS c_customer_id,
       b.NAME AS origname, a.c_dest_id, description1 AS description,
       diff_reason AS diffreason, NULL AS box_status, a.in_status AS status,
       NULL AS au_state, NULL AS au_pi_id, 0 AS avg_discount,
       a.tot_lines AS tot_lines, a.tot_qtyout AS tot_qtyout,
       a.tot_amtout_list AS tot_amtout_list,
       a.tot_amtout_actual1 AS tot_amtout_actual, a.tot_qtyin AS tot_qtyin,
       a.tot_amtin_list AS tot_amtin_list,
       decode(a.cross_type,'C1',a.tot_amtin_actual2,a.tot_amtin_actual3) AS tot_amtin_actual,
       a.dateout AS dateout,
       a.datein AS datein, a.statuserid, a.statustime, outerid AS outerid,
       outtime AS outtime, inerid AS inerid, intime AS intime, NULL AS type_id,
       a.retsaletype1 AS dealtype, NULL AS operatoerid, NULL AS oper_status,
       0 AS tot_amt_precost, 0 AS tot_amtin_precost, NULL AS imageurl,
       0 AS tot_qtydiff, 0 AS qtydiff, NULL AS c_cargotype_id,
       (CASE
            WHEN substr(a.dateout, 5, 2) = substr(a.datein, 5, 2) THEN
             'Y'
            ELSE
             'N'
        END) AS issamemonth, NULL AS c_store_location_id, 0 AS printtimes,
       'N' AS scanstate, NULL AS realdate, NULL AS if_goodsarr,
       b.code AS origcode, NULL AS check_status, NULL AS checkerid,
       NULL AS checktime, NULL AS datewh, c_transtore_id1 AS c_crosstore_id1,
       c_transtore_id2 AS c_crosstore_id2, 0 AS tot_fgood_qty, 0 AS tot_good_qty,
       0 AS tot_defect_qty,a.is_towms,2,8 as TRAINNUMBER,null as description2,0 as tot_box,null,0 as tot_boxout,null,A.PICKERID
FROM m_cro_retsale a, c_store b
WHERE a.c_store_id = b.id
AND a.status = 2
AND a.out_status = 2 --and a.in_status = 1
/

