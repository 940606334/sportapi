CREATE VIEW RP_ANALYSIS033 AS
  select a.id ,a.ad_client_id,a.ad_org_id, a.ownerid,a.modifierid,
a.creationdate,a.modifieddate,a.isactive,a.datein as billdate,a.docno,
a.c_orig_id as c_store_id ,a.c_dest_id,a.description,b.m_product_id,b.m_productalias_id m_product_alias_id,
b.m_attributesetinstance_id,b.qtyin,b.tot_amtin_list,0 as qtyout,
0 as tot_amtout_actual ,0 as qty, 0 as qtyprice
from m_transfer a,m_transferitem b
where a.id=b.m_transfer_id
and a.out_status=2
and a.in_status=2
union all
select a.id ,a.ad_client_id,a.ad_org_id, a.ownerid,a.modifierid,
a.creationdate,a.modifieddate,a.isactive,a.dateout as billdate,a.docno,
a.c_store_id,a.c_store_id as c_dest_id,a.description,b.m_product_id,b.m_productalias_id as m_product_alias_id,
b.m_attributesetinstance_id,0 as qtyin,0 as tot_amtin_list,b.qty as qtyout,
b.tot_amt_actual as tot_amtout_actual,t.qty, t.qty*r.pricelist as qtyprice
from  m_retail a join m_retailitem  b on a.id=b.m_retail_id
join m_product r on b.m_product_id=r.id
left join fa_storage t on a.c_store_id=t.c_store_id and b.m_product_id=t.m_product_id and b.m_attributesetinstance_id=t.m_attributesetinstance_id
where status=2
/

