CREATE VIEW TDEFOBUYER AS
  select a.CODE as buyerid,to_char(a.NAME) as Buyername,
  (case  when   k.name='总部' then '00000' else  b.code end ) as Buyerup,
 a.FIRSALEDIS as Discount ,  a.SALEDIS as Supdiscount , 0 as Targetqty,TRUNC(0.00,2) as Targetfamount
 from  C_CUSTOMER a,C_CUSTOMERUP b,c_cusrank k
 where a.isstop='N' and (b.id(+)=a.C_CUSTOMERUP_id) and a.isactive='Y'
 and a.c_cusrank_id =k.id
/

