CREATE VIEW C_V_TDEFTICKET AS
  select id,ad_client_id,ad_org_id,ownerid,modifierid,creationdate,modifieddate, isactive,
TicketNo ,CheckNo ,DateBeg,DateEnd,ParValue ,Remark ,
(case when to_number(to_char(SYSDATE,'YYYYMMDD')) >=DateBeg and to_number(to_char(SYSDATE,'YYYYMMDD')) <= DateEnd and Verifyed='N'
   then 'Y'
   else
   'N'
   end) as Valided,Verifyed ,Verifyer ,VerifyDate, store
from TdefTicket
/

