CREATE VIEW RP_SALE008 AS
  SELECT b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate, b.ownerid,
			 b.modifieddate, b.modifierid, a.salebilltype, a.dateout AS BILLDATE, a.DOCNO,
			 a.DOCTYPE, a.B_SO_ID, a.C_CUSTOMERUP_ID, a.C_STORE_ID, a.C_CUSTOMER_ID, a.c_dest_id,
			 a.DESCRIPTION, b.M_PRODUCT_ID, b.M_ATTRIBUTESETINSTANCE_ID,
			 (SELECT c.tot_amt_actual
					 FROM b_soitem c
					WHERE c.b_so_id = a.b_so_id
						AND c.m_product_id = b.m_product_id
						AND c.m_attributesetinstance_id = b.m_attributesetinstance_id) AS amtso,
			 (SELECT c.qty
					 FROM b_soitem c
					WHERE c.b_so_id = a.b_so_id
						AND c.m_product_id = b.m_product_id
						AND c.m_attributesetinstance_id = b.m_attributesetinstance_id) AS QTYORDERED,
			 b.QTY AS QTYSALE, b.QTYOUT AS QTYSALEOUT, 0 AS QTYRETSALE, 0 AS QTYRETSALEIN,
			 b.PRICELIST, b.TOT_AMT_LIST AS AMTLISTSALE, b.TOT_AMTOUT_LIST AS AMTLISTSALEOUT,
			 0 AS AMTLISTRETSALE, 0 AS AMTLISTRETSALEIN, b.PRICEACTUAL,
			 b.TOT_AMT_ACTUAL AS AMTSALE, b.TOT_AMTOUT_ACTUAL AS AMTSALEOUT, 0 AS AMTRETSALE,
			 0 AS AMTRETSALEIN, b.DISCOUNT AS DISCOUNTSALE, 0 AS DISCOUNTRETSALE, a.OUTERID,
			 NULL AS inerid,
			b.m_productalias_id AS m_product_alias_id,
			 a.C_SALEDISTYPE_ID,
			 (SELECT nvl(d.acost, 0) FROM m_product d WHERE d.id = b.m_product_id) AS acost,
			 b.qty * (SELECT nvl(d.acost, 0) FROM m_product d WHERE d.id = b.m_product_id) AS t_qtycost,
			 PERCOST_ANALYSE(SUBSTR(A.DATEOUT, 1, 6), A.C_STORE_ID, B.M_PRODUCT_ID) AS PERCOST,
			 PERCOST_ANALYSE(SUBSTR(A.DATEOUT, 1, 6), A.C_STORE_ID, B.M_PRODUCT_ID) * B.QTYOUT AS AMT_COST,
			 a.out_status AS OUTIN_STATUS
	FROM M_SALE a, M_SALEITEM b
 WHERE a.ID = b.M_SALE_ID
	 AND a.STATUS = 2
	 AND a.OUT_STATUS = 2
UNION ALL
SELECT b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate, b.ownerid,
			 b.modifieddate, b.modifierid, a.salebilltype, a.billdate AS BILLDATE, a.DOCNO,
			 a.DOCTYPE, a.B_SO_ID, a.C_CUSTOMERUP_ID, a.C_STORE_ID, a.C_CUSTOMER_ID, a.c_dest_id,
			 a.DESCRIPTION, b.M_PRODUCT_ID, b.M_ATTRIBUTESETINSTANCE_ID,
			 (SELECT c.tot_amt_actual
					 FROM b_soitem c
					WHERE c.b_so_id = a.b_so_id
						AND c.m_product_id = b.m_product_id
						AND c.m_attributesetinstance_id = b.m_attributesetinstance_id) AS amtso,
			 (SELECT c.qty
					 FROM b_soitem c
					WHERE c.b_so_id = a.b_so_id
						AND c.m_product_id = b.m_product_id
						AND c.m_attributesetinstance_id = b.m_attributesetinstance_id) AS QTYORDERED,
			 b.QTY AS QTYSALE, 0 AS QTYSALEOUT, 0 AS QTYRETSALE, 0 AS QTYRETSALEIN, b.PRICELIST,
			 b.TOT_AMT_LIST AS AMTLISTSALE, b.TOT_AMTOUT_LIST * 0 AS AMTLISTSALEOUT,
			 0 AS AMTLISTRETSALE, 0 AS AMTLISTRETSALEIN, b.PRICEACTUAL,
			 b.TOT_AMT_ACTUAL * 0 AS AMTSALE, b.TOT_AMTOUT_ACTUAL * 0 AS AMTSALEOUT,
			 0 AS AMTRETSALE, 0 AS AMTRETSALEIN, b.DISCOUNT AS DISCOUNTSALE,
			 0 AS DISCOUNTRETSALE, a.OUTERID, NULL AS inerid,
			b.m_productalias_id AS m_product_alias_id,
			 a.C_SALEDISTYPE_ID,
			 (SELECT nvl(d.acost, 0) FROM m_product d WHERE d.id = b.m_product_id) AS acost,
			 b.qty * (SELECT nvl(d.acost, 0) FROM m_product d WHERE d.id = b.m_product_id) AS t_qtycost,
			 PERCOST_ANALYSE(SUBSTR(A.Billdate, 1, 6), A.C_STORE_ID, B.M_PRODUCT_ID) AS PERCOST,
			 PERCOST_ANALYSE(SUBSTR(A.Billdate, 1, 6), A.C_STORE_ID, B.M_PRODUCT_ID) * B.QTYOUT * 0 AS AMT_COST,
			 a.out_status AS OUTIN_STATUS
	FROM M_SALE a, M_SALEITEM b
 WHERE a.ID = b.M_SALE_ID
	 AND a.STATUS = 2
	 AND a.OUT_STATUS = 1
UNION ALL
SELECT b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate, b.ownerid,
			 b.modifieddate, b.modifierid, NULL AS salebilltype, a.datein AS BILLDATE, a.DOCNO,
			 a.DOCTYPE, NULL AS B_SO_ID, a.C_CUSTOMERUP_ID, a.c_orig_id AS C_STORE_ID,
			 a.C_CUSTOMER_ID, a.c_store_id AS c_dest_id, a.DESCRIPTION, b.M_PRODUCT_ID,
			 b.M_ATTRIBUTESETINSTANCE_ID, 0 AS amtso, 0 AS QTYORDERED, 0 AS QTYSALE,
			 0 AS QTYSALEOUT, b.qtyout AS QTYRETSALE, b.QTYIN AS QTYRETSALEIN, b.PRICELIST,
			 0 AS AMTLISTSALE, 0 AS AMTLISTSALEOUT, b.TOT_AMT_LIST AS AMTLISTRETSALE,
			 b.TOT_AMTIN_LIST AS AMTLISTRETSALEIN, b.PRICEACTUAL, 0 AS AMTSALE, 0 AS AMTSALEOUT,
			 b.TOT_AMT_ACTUAL AS AMTRETSALE, b.TOT_AMTIN_ACTUAL AS AMTRETSALEIN,
			 0 AS DISCOUNTSALE, b.DISCOUNT AS DISCOUNTRETSALE, NULL AS OUTERID, a.INerid,
			 b.m_productalias_id AS m_product_alias_id,
			 a.C_SALEDISTYPE_ID,
			 (SELECT nvl(d.acost, 0) FROM m_product d WHERE d.id = b.m_product_id) AS acost,
			 0 AS t_qtycost,
			 PERCOST_ANALYSE(SUBSTR(A.Datein, 1, 6), A.C_STORE_ID, B.M_PRODUCT_ID) AS PERCOST,
			 -PERCOST_ANALYSE(SUBSTR(A.Datein, 1, 6), A.C_STORE_ID, B.M_PRODUCT_ID) * B.Qtyin AS AMT_COST,
			 a.in_status AS OUTIN_STATUS
	FROM M_RET_SALE a, M_RET_SALEITEM b
 WHERE a.ID = b.M_RET_SALE_ID
	 AND a.STATUS = 2
   and a.out_status=2
	 AND a.IN_STATUS = 2
UNION ALL
SELECT b.ID, b.AD_CLIENT_ID, b.AD_ORG_ID, b.isactive, b.creationdate, b.ownerid,
			 b.modifieddate, b.modifierid, NULL AS salebilltype, a.dateout AS BILLDATE, a.DOCNO,
			 a.DOCTYPE, NULL AS B_SO_ID, a.C_CUSTOMERUP_ID, a.c_orig_id AS C_STORE_ID,
			 a.C_CUSTOMER_ID, a.c_store_id AS c_dest_id, a.DESCRIPTION, b.M_PRODUCT_ID,
			 b.M_ATTRIBUTESETINSTANCE_ID, 0 AS amtso, 0 AS QTYORDERED, 0 AS QTYSALE,
			 0 AS QTYSALEOUT, b.qtyout AS QTYRETSALE, 0 AS QTYRETSALEIN, b.PRICELIST,
			 0 AS AMTLISTSALE, 0 AS AMTLISTSALEOUT, b.TOT_AMT_LIST AS AMTLISTRETSALE,
			 b.TOT_AMTIN_LIST * 0 AS AMTLISTRETSALEIN, b.PRICEACTUAL, 0 AS AMTSALE,
			 0 AS AMTSALEOUT, b.TOT_AMT_ACTUAL * 0 AS AMTRETSALE,
			 b.TOT_AMTIN_ACTUAL * 0 AS AMTRETSALEIN, 0 AS DISCOUNTSALE,
			 b.DISCOUNT AS DISCOUNTRETSALE, NULL AS OUTERID, a.INerid,
			b.m_productalias_id AS m_product_alias_id,
			 a.C_SALEDISTYPE_ID,
			 (SELECT nvl(d.acost, 0) FROM m_product d WHERE d.id = b.m_product_id) AS acost,
			 0 AS t_qtycost,
			 PERCOST_ANALYSE(SUBSTR(A.Dateout, 1, 6), A.C_STORE_ID, B.M_PRODUCT_ID) AS PERCOST,
			 -PERCOST_ANALYSE(SUBSTR(A.Dateout, 1, 6), A.C_STORE_ID, B.M_PRODUCT_ID) * B.Qtyin * 0 AS AMT_COST,
			 a.in_status AS OUTIN_STATUS
	FROM M_RET_SALE a, M_RET_SALEITEM b
 WHERE a.ID = b.M_RET_SALE_ID
	 AND a.STATUS = 2
   and a.out_status=2
	 AND a.IN_STATUS = 1 WITH READ ONLY
/

